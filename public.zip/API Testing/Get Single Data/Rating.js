// Rating
const Rating={
    "data": {
      "entityMetadata": {
        "canHaveEpisodes": false,
        "castPageTitle": {
          "edges": [
            {
              "node": {
                "name": {
                  "id": "nm0897201",
                  "nameText": {
                    "text": "Joseph Vijay"
                  }
                }
              }
            },
            {
              "node": {
                "name": {
                  "id": "nm0004569",
                  "nameText": {
                    "text": "Sanjay Dutt"
                  }
                }
              }
            },
            {
              "node": {
                "name": {
                  "id": "nm0440604",
                  "nameText": {
                    "text": "Anurag Kashyap"
                  }
                }
              }
            },
            {
              "node": {
                "name": {
                  "id": "nm0352032",
                  "nameText": {
                    "text": "Kamal Haasan"
                  }
                }
              }
            }
          ]
        },
        "certificate": null,
        "countriesOfOrigin": {
          "countries": [
            {
              "id": "IN"
            }
          ]
        },
        "creatorsPageTitle": [],
        "directorsPageTitle": [
          {
            "credits": [
              {
                "name": {
                  "id": "nm7992231",
                  "nameText": {
                    "text": "Lokesh Kanagaraj"
                  }
                }
              }
            ]
          }
        ],
        "id": "tt15654328",
        "meta": {
          "canonicalId": "tt15654328",
          "publicationStatus": "PUBLISHED"
        },
        "originalTitleText": {
          "text": "Leo"
        },
        "plot": {
          "plotText": {
            "plainText": "Parthiban is a mild-mannered cafe owner in Kashmir, who fends off a gang of murderous thugs and gains attention from a drug cartel claiming he was once a part of them."
          }
        },
        "primaryImage": {
          "caption": {
            "plainText": "Joseph Vijay in Leo (2023)"
          },
          "height": 1633,
          "url": "https://m.media-amazon.com/images/M/MV5BMmFiOGYyZjQtZmZmNC00ZTgzLWI5ZjktMTRiYzc5NjAzODRkXkEyXkFqcGdeQXVyMTYyNDkzNzgz._V1_.jpg",
          "width": 1080
        },
        "productionStatus": {
          "currentProductionStage": {
            "id": "released"
          },
          "restriction": null
        },
        "ratingsSummary": {
          "aggregateRating": 7.2
        },
        "releaseYear": {
          "endYear": null,
          "year": 2023
        },
        "runtime": {
          "seconds": 9840
        },
        "series": null,
        "subNavCredits": {
          "total": 197
        },
        "subNavFaqs": {
          "total": 0
        },
        "subNavReviews": {
          "total": 414
        },
        "subNavTopQuestions": {
          "total": 14
        },
        "subNavTrivia": {
          "total": 10
        },
        "titleGenres": {
          "genres": [
            {
              "genre": {
                "text": "Action"
              }
            },
            {
              "genre": {
                "text": "Crime"
              }
            },
            {
              "genre": {
                "text": "Drama"
              }
            }
          ]
        },
        "titleText": {
          "text": "Leo"
        },
        "titleType": {
          "canHaveEpisodes": false,
          "id": "movie",
          "isEpisode": false,
          "isSeries": false,
          "text": "Movie"
        }
      },
      "heatmapData": {
        "episodeData": [],
        "seasonData": {
          "cursor": "",
          "missedInitialSeasons": {}
        },
        "seasons": 0,
        "totalEpisodes": 0
      },
      "histogramData": {
        "aggregateRating": 7.2,
        "countryData": [
          {
            "aggregateRating": 7.4,
            "countryCode": "IN",
            "displayText": "India",
            "totalVoteCount": 40523
          },
          {
            "aggregateRating": 6.8,
            "countryCode": "US",
            "displayText": "United States",
            "totalVoteCount": 3794
          },
          {
            "aggregateRating": 7.1,
            "countryCode": "GB",
            "displayText": "United Kingdom",
            "totalVoteCount": 2463
          },
          {
            "aggregateRating": 7.1,
            "countryCode": "BD",
            "displayText": "Bangladesh",
            "totalVoteCount": 2065
          },
          {
            "aggregateRating": 7.7,
            "countryCode": "LK",
            "displayText": "Sri Lanka",
            "totalVoteCount": 1454
          }
        ],
        "histogramValues": [
          {
            "formattedVoteCount": "3.1K",
            "rating": 1,
            "voteCount": 3110
          },
          {
            "formattedVoteCount": "505",
            "rating": 2,
            "voteCount": 505
          },
          {
            "formattedVoteCount": "554",
            "rating": 3,
            "voteCount": 554
          },
          {
            "formattedVoteCount": "820",
            "rating": 4,
            "voteCount": 820
          },
          {
            "formattedVoteCount": "1.7K",
            "rating": 5,
            "voteCount": 1705
          },
          {
            "formattedVoteCount": "3.2K",
            "rating": 6,
            "voteCount": 3205
          },
          {
            "formattedVoteCount": "5.2K",
            "rating": 7,
            "voteCount": 5154
          },
          {
            "formattedVoteCount": "5.3K",
            "rating": 8,
            "voteCount": 5315
          },
          {
            "formattedVoteCount": "4.5K",
            "rating": 9,
            "voteCount": 4479
          },
          {
            "formattedVoteCount": "32K",
            "rating": 10,
            "voteCount": 32062
          }
        ],
        "titleId": "tt15654328",
        "totalVoteCount": 56909
      },
      "isRatable": true,
      "parentDisplayText": "Leo",
      "posterData": {
        "constId": "tt15654328",
        "image": {
          "caption": "Leo",
          "maxHeight": 1633,
          "maxWidth": 1080,
          "url": "https://m.media-amazon.com/images/M/MV5BMmFiOGYyZjQtZmZmNC00ZTgzLWI5ZjktMTRiYzc5NjAzODRkXkEyXkFqcGdeQXVyMTYyNDkzNzgz._V1_.jpg"
        },
        "type": "movie"
      },
      "sidebarProps": {
        "titleSidebarProps": {
          "countriesOfOrigin": {
            "__typename": "CountriesOfOrigin",
            "countries": [
              {
                "__typename": "CountryOfOrigin",
                "id": "IN"
              }
            ]
          },
          "productionStatus": {
            "__typename": "ProductionStatusDetails",
            "currentProductionStage": {
              "__typename": "ProductionStage",
              "id": "released"
            },
            "restriction": null
          }
        }
      },
      "titleText": "Leo"
    },
    "message": "Successful",
    "status": true
  }




  // ________________Casting Data {ID,name}______________________


//   two thing important histogramData,histogramValues [Optional]
const TempRating = Rating.data.histogramData;
const TempRating = Rating.data.histogramValues;


