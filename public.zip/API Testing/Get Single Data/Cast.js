// only have ID , name

const cast={
    "data": [
      {
        "id": "nm0897201",
        "name": "Joseph Vijay"
      },
      {
        "id": "nm0004569",
        "name": "Sanjay Dutt"
      },
      {
        "id": "nm0440604",
        "name": "Anurag Kashyap"
      },
      {
        "id": "nm0352032",
        "name": "Kamal Haasan"
      },
      {
        "id": "nm1375534",
        "name": "Trisha Krishnan"
      },
      {
        "id": "nm10464357",
        "name": "Mathew Thomas"
      },
      {
        "id": "nm1069826",
        "name": "Gautham Vasudev Menon"
      },
      {
        "id": "nm7371790",
        "name": "Madonna Sebastian"
      },
      {
        "id": "nm0035018",
        "name": "Arjun Sarja"
      },
      {
        "id": "nm3591550",
        "name": "Priya Anand"
      },
      {
        "id": "nm4199426",
        "name": "Mysskin"
      },
      {
        "id": "nm12304446",
        "name": "Santhi Mayadevi"
      },
      {
        "id": "nm1184326",
        "name": "Babu Antony"
      },
      {
        "id": "nm1336722",
        "name": "Denzil Smith"
      },
      {
        "id": "nm8842905",
        "name": "Sandy Master"
      },
      {
        "id": "nm9306232",
        "name": "Maya S. Krishnan"
      },
      {
        "id": "nm5157126",
        "name": "Madhusudhan Rao"
      },
      {
        "id": "nm1658967",
        "name": "Mansoor Ali Khan"
      },
      {
        "id": "nm6998719",
        "name": "George Maryan"
      },
      {
        "id": "nm3606877",
        "name": "Mukhtar Khan"
      },
      {
        "id": "nm9788791",
        "name": "Punya Elizabeth"
      },
      {
        "id": "nm14126970",
        "name": "Janany Kunaseelan"
      },
      {
        "id": "nm7118554",
        "name": "Leela Samson"
      },
      {
        "id": "nm1473802",
        "name": "Dinesh Lamba"
      },
      {
        "id": "nm10363181",
        "name": "Rj Umar Nisar"
      },
      {
        "id": "nm5046880",
        "name": "Dinesh"
      },
      {
        "id": "nm14875225",
        "name": "Pooja Fiya"
      },
      {
        "id": "nm1765552",
        "name": "Ramakrishnan"
      },
      {
        "id": "nm1234717",
        "name": "Vaiyapuri"
      },
      {
        "id": "nm15526531",
        "name": "Shanthi Master"
      },
      {
        "id": "nm9717083",
        "name": "Sachin Mani"
      },
      {
        "id": "nm11172546",
        "name": "Maneksha"
      },
      {
        "id": "nm15526532",
        "name": "Salem Parthiban"
      },
      {
        "id": "nm15526530",
        "name": "Thavasi Master"
      },
      {
        "id": "nm12557047",
        "name": "Shanthipriya Ray"
      },
      {
        "id": "nm15526533",
        "name": "Kavitha Suresh"
      },
      {
        "id": "nm10878624",
        "name": "Muthu Krishnan"
      },
      {
        "id": "nm7971528",
        "name": "Dinesh Master"
      },
      {
        "id": "nm14906406",
        "name": "Jawahar"
      },
      {
        "id": "nm10949928",
        "name": "Mahalakshmi"
      },
      {
        "id": "nm15526535",
        "name": "Tajamul Gani"
      },
      {
        "id": "nm11915559",
        "name": "Maya Krishnan"
      },
      {
        "id": "nm11423314",
        "name": "Moosa"
      }
    ],
    "message": "Successful",
    "status": true
  }


  const AllCastArray=[];
 const TempALlCast= cast.data
 TempALlCast.map((singleCast)=>{
  let castData={
    id:singleCast.id,
    name:singleCast.name
  }

  AllCastArray.push(castData);
 })
 console.log(AllCastArray)