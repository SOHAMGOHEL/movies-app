const Ottinformation ={
    "result": {
      "type": "movie",
      "title": "Salaar: Part 1 - Ceasefir",
      "overview": "In the crime-infested Khansaar, Prince Varadha sets to ascend the throne. But a coup d'état is planned! And there’s only one man to help reclaim power: Deva.",
      "streamingInfo": {
        "ae": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052530
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754780/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053636
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754782/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707644175
          }
        ],
        "ar": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052907
          }
        ],
        "at": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706049950
          }
        ],
        "au": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81727155/",
            "videoLink": "https://www.netflix.com/watch/81727155",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052826
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707772177
          }
        ],
        "az": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706665463
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754779/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053552
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754782/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1708026473
          }
        ],
        "be": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053616
          }
        ],
        "bg": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707744810
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81727155/",
            "videoLink": "https://www.netflix.com/watch/81727155",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053639
          }
        ],
        "br": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052798
          }
        ],
        "ca": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707646731
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053234
          },
          {
            "service": "hotstar",
            "streamingType": "subscription",
            "link": "https://www.hotstar.com/ca/movies/salaar-part-1-ceasefire/1260170331",
            "videoLink": "https://www.hotstar.com/ca/movies/salaar-part-1-ceasefire/1260170331/watch",
            "audios": [
              {
                "language": "hin",
                "region": ""
              }
            ],
            "subtitles": [
              {
                "locale": {
                  "language": "adh",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "ara",
                  "region": "SYR"
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "ben",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "bih",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "cat",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "dug",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "eng",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "fun",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "guj",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "hin",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "isl",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "kan",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mal",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mar",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mni",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "moh",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mri",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "ori",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "pan",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "raj",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "spa",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tam",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tel",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tgl",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tts",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "wuu",
                  "region": ""
                },
                "closedCaptions": false
              }
            ],
            "leaving": 1928946599,
            "availableSince": 1708362055
          }
        ],
        "ch": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706725600
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053392
          }
        ],
        "cl": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052733
          }
        ],
        "co": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706749604
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053586
          }
        ],
        "cy": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706669026
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053527
          }
        ],
        "cz": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053148
          }
        ],
        "de": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053574
          }
        ],
        "dk": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052378
          }
        ],
        "ec": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053588
          }
        ],
        "ee": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706771637
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707647220
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053025
          }
        ],
        "es": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052545
          }
        ],
        "fi": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053069
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707646049
          }
        ],
        "gb": [
          {
            "service": "hotstar",
            "streamingType": "subscription",
            "link": "https://www.hotstar.com/gb/movies/salaar-part-1-ceasefire/1260170331",
            "videoLink": "https://www.hotstar.com/gb/movies/salaar-part-1-ceasefire/1260170331/watch",
            "audios": [
              {
                "language": "hin",
                "region": ""
              }
            ],
            "subtitles": [
              {
                "locale": {
                  "language": "ara",
                  "region": "SYR"
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "ben",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "bih",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "cat",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "dug",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "eng",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "fun",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "guj",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "hin",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "isl",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "kan",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mal",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mar",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mni",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "moh",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mri",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "ori",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "pan",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "raj",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "spa",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tam",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tel",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tgl",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tts",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "wuu",
                  "region": ""
                },
                "closedCaptions": false
              }
            ],
            "leaving": 1928946599,
            "availableSince": 1708126464
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706588900
          }
        ],
        "gr": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053312
          }
        ],
        "hk": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052874
          }
        ],
        "hr": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053074
          }
        ],
        "hu": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706738609
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053132
          }
        ],
        "id": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706710659
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052793
          }
        ],
        "ie": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706692877
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052984
          }
        ],
        "il": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052611
          }
        ],
        "in": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053296
          },
          {
            "service": "hotstar",
            "streamingType": "subscription",
            "link": "https://www.hotstar.com/in/movies/salaar-part-1-ceasefire/1260170331",
            "videoLink": "https://www.hotstar.com/in/movies/salaar-part-1-ceasefire/1260170331/watch",
            "audios": [
              {
                "language": "hin",
                "region": ""
              }
            ],
            "subtitles": [],
            "availableSince": 1708677919
          }
        ],
        "is": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81727155/",
            "videoLink": "https://www.netflix.com/watch/81727155",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052621
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707642707
          }
        ],
        "it": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052584
          }
        ],
        "jp": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053404
          }
        ],
        "kr": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053680
          }
        ],
        "lt": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707646530
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052751
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706598279
          }
        ],
        "md": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706685808
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754780/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052805
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754782/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707646019
          }
        ],
        "mk": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754779/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706681637
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053657
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754782/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707647238
          }
        ],
        "mx": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053208
          }
        ],
        "my": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053016
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81727155/",
            "videoLink": "https://www.netflix.com/watch/81727155",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707646437
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754780/",
            "videoLink": "https://www.netflix.com/watch/81754780",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707114995
          }
        ],
        "nl": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052775
          }
        ],
        "no": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053253
          }
        ],
        "nz": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81727155/",
            "videoLink": "https://www.netflix.com/watch/81727155",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053143
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707645378
          }
        ],
        "pa": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707115749
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052922
          }
        ],
        "pe": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053196
          }
        ],
        "ph": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754781/",
            "videoLink": "https://www.netflix.com/watch/81754781",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053523
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053675
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707646875
          }
        ],
        "pl": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052422
          }
        ],
        "pt": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053264
          }
        ],
        "ro": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053470
          }
        ],
        "rs": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052793
          }
        ],
        "se": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81727155/",
            "videoLink": "https://www.netflix.com/watch/81727155",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053175
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754782/",
            "videoLink": "https://www.netflix.com/watch/81754782",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707818656
          }
        ],
        "sg": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754779/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052526
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81727155/",
            "videoLink": "https://www.netflix.com/watch/81727155",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707646223
          },
          {
            "service": "hotstar",
            "streamingType": "subscription",
            "link": "https://www.hotstar.com/sg/movies/salaar-part-1-ceasefire/1260170331",
            "videoLink": "https://www.hotstar.com/sg/movies/salaar-part-1-ceasefire/1260170331/watch",
            "audios": [
              {
                "language": "hin",
                "region": ""
              }
            ],
            "subtitles": [
              {
                "locale": {
                  "language": "adh",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "ara",
                  "region": "SYR"
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "ben",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "bih",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "cat",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "dug",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "eng",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "fun",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "guj",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "hin",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "isl",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "kan",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mal",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mar",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mni",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "moh",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "mri",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "ori",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "pan",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "raj",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "spa",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tam",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tel",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tgl",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "tts",
                  "region": ""
                },
                "closedCaptions": false
              },
              {
                "locale": {
                  "language": "wuu",
                  "region": ""
                },
                "closedCaptions": false
              }
            ],
            "leaving": 1928946599,
            "availableSince": 1708178903
          }
        ],
        "th": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "quality": "uhd",
            "link": "https://www.netflix.com/title/81754779/",
            "videoLink": "https://www.netflix.com/watch/81754779",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053520
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706736377
          }
        ],
        "tr": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754782/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707115865
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754779/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053621
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053209
          }
        ],
        "ua": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053487
          }
        ],
        "us": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706052970
          }
        ],
        "vn": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053025
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754782/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707993416
          }
        ],
        "za": [
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81727155/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1706053608
          },
          {
            "service": "netflix",
            "streamingType": "subscription",
            "link": "https://www.netflix.com/title/81754782/",
            "audios": [],
            "subtitles": [],
            "availableSince": 1707646254
          }
        ]
      },
      "cast": [
        "Prabhas",
        "Prithviraj Sukumaran",
        "Shruti Haasan",
        "Easwari Rao",
        "Jagapati Babu",
        "Bobby Simha",
        "Sriya Reddy"
      ],
      "year": 2023,
      "imdbId": "tt13927994",
      "tmdbId": 770906,
      "originalTitle": "eసలార్ పార్ట్‌ 1 – సీజ్‌ఫైర్‌",
      "genres": [
        {
          "id": 28,
          "name": "Action"
        },
        {
          "id": 80,
          "name": "Crime"
        }
      ],
      "directors": [
        "Prashanth Neel"
      ]
    }
  }

    const TempOTTinformation =Ottinformation.result.streamingInfo.in
    TempOTTinformation.map((SingleOTTinformation)=>{
    // console.log(SingleOTTinformation)
    console.log(SingleOTTinformation.audios)
    console.log(SingleOTTinformation.link)
    console.log(SingleOTTinformation.service)
    console.log(SingleOTTinformation.streamingType)

})

