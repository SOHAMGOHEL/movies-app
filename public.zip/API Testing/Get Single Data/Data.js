// Details   500

const Details={
  "data": {
    "aboveTheFoldData": {
      "__typename": "Title",
      "canHaveEpisodes": false,
      "canRate": {
        "__typename": "CanRate",
        "isRatable": true
      },
      "castPageTitle": {
        "__typename": "CreditConnection",
        "edges": [
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "name": {
                "__typename": "Name",
                "id": "nm0897201",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Joseph Vijay"
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "name": {
                "__typename": "Name",
                "id": "nm0004569",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Sanjay Dutt"
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "name": {
                "__typename": "Name",
                "id": "nm0440604",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Anurag Kashyap"
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "name": {
                "__typename": "Name",
                "id": "nm0352032",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Kamal Haasan"
                }
              }
            }
          }
        ]
      },
      "certificate": null,
      "countriesOfOrigin": {
        "__typename": "CountriesOfOrigin",
        "countries": [
          {
            "__typename": "CountryOfOrigin",
            "id": "IN"
          }
        ]
      },
      "creatorsPageTitle": [],
      "credits": {
        "__typename": "CreditConnection",
        "total": 197
      },
      "criticReviewsTotal": {
        "__typename": "ExternalLinkConnection",
        "total": 23
      },
      "directorsPageTitle": [
        {
          "__typename": "PrincipalCreditsForCategory",
          "credits": [
            {
              "__typename": "Crew",
              "name": {
                "__typename": "Name",
                "id": "nm7992231",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Lokesh Kanagaraj"
                }
              }
            }
          ]
        }
      ],
      "engagementStatistics": {
        "__typename": "EngagementStatistics",
        "watchlistStatistics": {
          "__typename": "WatchlistStatistics",
          "displayableCount": {
            "__typename": "LocalizedDisplayableCount",
            "text": "Added by 27.8K users"
          }
        }
      },
      "externalLinks": {
        "__typename": "ExternalLinkConnection",
        "total": 46
      },
      "featuredReviews": {
        "__typename": "ReviewsConnection",
        "edges": [
          {
            "__typename": "ReviewEdge",
            "node": {
              "__typename": "Review",
              "author": {
                "__typename": "UserProfile",
                "nickName": "abhilashsv-67775"
              },
              "authorRating": 8,
              "submissionDate": "2023-10-20",
              "summary": {
                "__typename": "ReviewSummary",
                "originalText": "LEO - A Good Standalone Movie"
              },
              "text": {
                "__typename": "ReviewText",
                "originalText": {
                  "__typename": "Markdown",
                  "plainText": "LEO- Most anticipated movie has finally arrived, and it certainly doesn't disappoint and lives upto the Hype it was Given.\n\nThe first half was SUPERB.\n\nSome best solo action where his fights has some more good class than hitting a 50 guys like typical.\n\nIt is not a TYPICAL Vijay film, where his style and Mass entry and saving everyone is not here. There is literally No Mass Intro scene , No Super hero stuffs and all. Just a guy trying to save his family, till the first half.\n\nIts one of the Best acting by Vijay in his career.\n\nSecond Half is a bit laggy feel but its good.\n\nSome CGI work was very bad it looked like NFS Car Chase at some points.\n\nFinal Fight sequence was over crowded with villans it doesn't do much good, But solo fight at last was awesome.\n\nOverall its a Good Movie and a must watch in Theatre.\n\nDon't go with the mindset of Vikram, its not as much good. But its Very much Enjoyable and a nice Vijay Film..."
                }
              }
            }
          }
        ]
      },
      "genres": {
        "__typename": "Genres",
        "genres": [
          {
            "__typename": "Genre",
            "id": "Action",
            "text": "Action"
          },
          {
            "__typename": "Genre",
            "id": "Crime",
            "text": "Crime"
          },
          {
            "__typename": "Genre",
            "id": "Drama",
            "text": "Drama"
          },
          {
            "__typename": "Genre",
            "id": "Thriller",
            "text": "Thriller"
          }
        ]
      },
      "id": "tt15654328",
      "images": {
        "__typename": "ImageConnection",
        "edges": [
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "id": "rm854806785"
            }
          }
        ],
        "total": 95
      },
      "keywords": {
        "__typename": "TitleKeywordConnection",
        "edges": [
          {
            "__typename": "TitleKeywordEdge",
            "node": {
              "__typename": "TitleKeyword",
              "text": "action hero"
            }
          },
          {
            "__typename": "TitleKeywordEdge",
            "node": {
              "__typename": "TitleKeyword",
              "text": "one word title"
            }
          },
          {
            "__typename": "TitleKeywordEdge",
            "node": {
              "__typename": "TitleKeyword",
              "text": "intermission"
            }
          },
          {
            "__typename": "TitleKeywordEdge",
            "node": {
              "__typename": "TitleKeyword",
              "text": "violence"
            }
          },
          {
            "__typename": "TitleKeywordEdge",
            "node": {
              "__typename": "TitleKeyword",
              "text": "extreme violence"
            }
          }
        ],
        "total": 36
      },
      "meta": {
        "__typename": "TitleMeta",
        "canonicalId": "tt15654328",
        "publicationStatus": "PUBLISHED"
      },
      "metacritic": null,
      "meterRanking": {
        "__typename": "TitleMeterRanking",
        "currentRank": 1395,
        "rankChange": {
          "__typename": "MeterRankChange",
          "changeDirection": "DOWN",
          "difference": 49
        }
      },
      "originalTitleText": {
        "__typename": "TitleText",
        "text": "Leo"
      },
      "plot": {
        "__typename": "Plot",
        "language": {
          "__typename": "DisplayableLanguage",
          "id": "en-US"
        },
        "plotText": {
          "__typename": "Markdown",
          "plainText": "Parthiban is a mild-mannered cafe owner in Kashmir, who fends off a gang of murderous thugs and gains attention from a drug cartel claiming he was once a part of them."
        }
      },
      "plotContributionLink": {
        "__typename": "ContributionLink",
        "url": "https://contribute.imdb.com/updates?update=tt15654328:outlines.add.1.locale~en-US"
      },
      "primaryImage": {
        "__typename": "Image",
        "caption": {
          "__typename": "Markdown",
          "plainText": "Joseph Vijay in Leo (2023)"
        },
        "height": 1633,
        "id": "rm2551271425",
        "url": "https://m.media-amazon.com/images/M/MV5BMmFiOGYyZjQtZmZmNC00ZTgzLWI5ZjktMTRiYzc5NjAzODRkXkEyXkFqcGdeQXVyMTYyNDkzNzgz._V1_.jpg",
        "width": 1080
      },
      "primaryVideos": {
        "__typename": "VideoConnection",
        "edges": [
          {
            "__typename": "VideoEdge",
            "node": {
              "__typename": "Video",
              "contentType": {
                "__typename": "VideoContentType",
                "displayName": {
                  "__typename": "LocalizedString",
                  "value": "Trailer"
                },
                "id": "amzn1.imdb.video.contenttype.trailer"
              },
              "createdDate": "2023-11-20T15:50:21.751Z",
              "description": {
                "__typename": "LocalizedString",
                "language": "ta",
                "value": "Parthiban is a mild-mannered cafe owner in Kashmir, who fends off a gang of murderous thugs and gains attention from a drug cartel claiming he was once a part of them."
              },
              "id": "vi3073296153",
              "isMature": false,
              "name": {
                "__typename": "LocalizedString",
                "language": "ta",
                "value": "Official Trailer"
              },
              "playbackURLs": [
                {
                  "__typename": "PlaybackURL",
                  "displayName": {
                    "__typename": "LocalizedString",
                    "language": "en-US",
                    "value": "480p"
                  },
                  "url": "https://imdb-video.media-imdb.com/vi3073296153/1434659607842-pgv4ql-1700495422057.mp4?Expires=1708782771&Signature=qCZql6Lg2sJHKf67b4MBy12VYnR8YjQlL5pRmeTNaPlO4niqUvx52oDgrYASZ6ISEaXobHaEgRjGRMiJt5fOaHgNOX3sPi4iNj7P8les5M0sV5LkwvQT5LrlrOAX-4R9083mJvazW1fqT8Y6ZT51Cd2i-ItA7rDtqhA20xi-B9Vb1Gz0OTZ1smEem5kFfulPNUXGhTFyTTIl~dZ3f8cl4kEz4myI~lBJg9ByvjgkS3hbNbXD5JONxM2TCTl4yK3RU0N0HYnaGFrYQSVMWfVOOhkAgkYtVQFAMd8pzTEiO17eWtIPCi1gxZ3YrgzlyswQHYK~x48JeIp06sCuKf5Faw__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  "videoDefinition": "DEF_480p",
                  "videoMimeType": "MP4"
                },
                {
                  "__typename": "PlaybackURL",
                  "displayName": {
                    "__typename": "LocalizedString",
                    "language": "en-US",
                    "value": "SD"
                  },
                  "url": "https://imdb-video.media-imdb.com/vi3073296153/1434659454657-dx9ykf-1700495422057.mp4?Expires=1708782771&Signature=pvOpKfWZf933TZiNv3KFGdFp6hiPpCfom8WVpA1cvd1GxUZtkXrhGOcRBHwaASiDSvApPJ~W5dX-g1B7IZ5ONAtckt9zi4uREYyBpqu3f05g2FnZq~f~y87V05Zpb8Ve1XXEAAlmKE6uS0wleuuOrUwPGLr--9SZRcU8WqNPrmNs47x31M~Mbpck-T-dAuKopwOk7Qc429tZb2m~w2NHWwAsPH0ve2RHInLdYl3Elqm7d2SL5EUOT1SwUKW1iCD1QxeJgrXvcxHkvCRj8hUq2j~89STRDvfprOXuzsNXYmqC~RF5BYvxSfLyVx~4UOSyt7~YexzO1hJkGsCGXst49Q__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  "videoDefinition": "DEF_SD",
                  "videoMimeType": "MP4"
                }
              ],
              "previewURLs": [
                {
                  "__typename": "PlaybackURL",
                  "displayName": {
                    "__typename": "LocalizedString",
                    "language": "en-US",
                    "value": "AUTO"
                  },
                  "url": "https://imdb-video.media-imdb.com/vi3073296153/hls-preview-51812303-ca59-4bc7-9b0f-97157dcd9f74.m3u8?Expires=1708782771&Signature=h1IS22X-Izv2~MJ3qTKuRw7WTLmRj2QoOaqEGMaWPPUOTKFh7PMPWd42aCoLuhr5CMtka-l3vM19214kD7WAqZA~ZS6JVVJ~tHatxh2k2hhVuHJkCzcej5QIKi3m24f-7~wwhXsxM2TrcUcM3gupWv~Gt7ZIRb0Gt-3o4X7kFIKERA5f~uBJhsPfyti-g51Tw4Z5KmRG4joDE37Cwi9kwtgbNK3Jzyqm~QaUlnHmcylHZ-zbIL0tLWpYtBbOID4tdbLZvXJit8cnTzFyEx6uOd4GKM-NHiercowvCB9LiSj2xeHwbAMGm1SZdEzDc8ttuKlSY7TI8Z7ZRymIhfMwww__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  "videoDefinition": "DEF_AUTO",
                  "videoMimeType": "M3U8"
                }
              ],
              "primaryTitle": {
                "__typename": "Title",
                "id": "tt15654328",
                "originalTitleText": {
                  "__typename": "TitleText",
                  "text": "Leo"
                },
                "releaseYear": {
                  "__typename": "YearRange",
                  "year": 2023
                },
                "titleText": {
                  "__typename": "TitleText",
                  "text": "Leo"
                }
              },
              "recommendedTimedTextTrack": null,
              "runtime": {
                "__typename": "VideoRuntime",
                "value": 141
              },
              "thumbnail": {
                "__typename": "Thumbnail",
                "height": 1080,
                "url": "https://m.media-amazon.com/images/M/MV5BYjY1YjliNjQtOTU4NC00M2JlLWEwY2MtMmI2YjlmNThkMmY3XkEyXkFqcGdeQWpvc2FyYw@@._V1_.jpg",
                "width": 1920
              },
              "timedTextTracks": []
            }
          },
          {
            "__typename": "VideoEdge",
            "node": {
              "__typename": "Video",
              "contentType": {
                "__typename": "VideoContentType",
                "displayName": {
                  "__typename": "LocalizedString",
                  "value": "Trailer"
                },
                "id": "amzn1.imdb.video.contenttype.trailer"
              },
              "createdDate": "2023-10-05T13:43:45.730Z",
              "description": {
                "__typename": "LocalizedString",
                "language": "ta",
                "value": ""
              },
              "id": "vi2111686425",
              "isMature": false,
              "name": {
                "__typename": "LocalizedString",
                "language": "ta",
                "value": "Leo - Official Trailer"
              },
              "playbackURLs": [
                {
                  "__typename": "PlaybackURL",
                  "displayName": {
                    "__typename": "LocalizedString",
                    "language": "en-US",
                    "value": "480p"
                  },
                  "url": "https://imdb-video.media-imdb.com/vi2111686425/1434659607842-pgv4ql-1696513425958.mp4?Expires=1708782771&Signature=nNr5eqfC0Tpvdl02DDiGvV3cST98FEIYIQ0slValzRW~2wH2YybkW63dT6s~pZWbR-9v2wedjfS~UmZ2C7AwYRp3fYHkUaRrf4FWt~iotXHAsV9Nf9yESYUVm8G74JBpadxli3ftVY-XEWDAZlXjEsN87np4XL7TfFdCmy3AJCrdAWcMRu0fvpshqurG440T7FMXjwxePyG4BRrpcklxZYi8gb7yYKhN7XDc2DN0FovT9ntsFatJuYcIAUDXXBUWH9blXGMMzJATjrXLb2pj5LVBlVQ~xuPveft4LG6x6o6g0nPVkSgd900IQAAkn9MKoXtjqbvq9tse2hCaV74pkQ__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  "videoDefinition": "DEF_480p",
                  "videoMimeType": "MP4"
                },
                {
                  "__typename": "PlaybackURL",
                  "displayName": {
                    "__typename": "LocalizedString",
                    "language": "en-US",
                    "value": "SD"
                  },
                  "url": "https://imdb-video.media-imdb.com/vi2111686425/1434659454657-dx9ykf-1696513425958.mp4?Expires=1708782771&Signature=hroIUmMGrImds~TGrt2MBHC9Bd-wFA9GnTniwolaynhNqRi-9b~tIAqBx6HTo7IUP2HIZPXSfNB5hh1mJWdD~tQP13NU~DAS9eNOieE4gdxrfbywrmniyZbWQoSxbQvV88kRDjT1BtRjGlqZHfpVyeRM-zKIC3eqf8oly-5X6I-Cw4LtoL6LscGkrnnIP07FYYKn7lzODy7tPVe759K~6SsjI2OkRaV5XGvfEsg64lII1WUxMaUkFyZCm9XPrGR8P7mk70GqVVb45IvUUd8tJN~J6BCDRAgIkc-7uzF8Td3DSpmWgHm0SjIX~6SVSvKTIhViSOUo~EJuZF71Cqga2g__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  "videoDefinition": "DEF_SD",
                  "videoMimeType": "MP4"
                }
              ],
              "previewURLs": [
                {
                  "__typename": "PlaybackURL",
                  "displayName": {
                    "__typename": "LocalizedString",
                    "language": "en-US",
                    "value": "AUTO"
                  },
                  "url": "https://imdb-video.media-imdb.com/vi2111686425/hls-preview-ff03a1c1-6f91-43aa-9188-bbd82194b4c1.m3u8?Expires=1708782771&Signature=sAIQdAmS24vfzWizzKql~MzfKUnam7n9-z6CVG7PFjr8~XHfwWSkyPQsqww~mbGgO4cTVpJ~MNAXyicocnkjqUawPjBIlDlMVbKdeisMfnKdPKBDnZMo5YwsorFAxp0Xokz~~nxY1hgPk4ZtLpPxweoIDZopt6jzovDCTYh9J~idCNxO1yWvm5d5Tbd4bxKfBdoa~u-j1yh1BBQu1Lef6AD31rQKxGfNQM6hrNJGS0nsHNi7EihjNaDbGE-UdTBA2NJiTuOQ70CSi9tNQ0UU7uQNfdQTfbP8B13pkP1uf61VnHsUHG1Lojplz1ClRrTxVzm1qentpf-c6s2hDFdURg__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  "videoDefinition": "DEF_AUTO",
                  "videoMimeType": "M3U8"
                }
              ],
              "primaryTitle": {
                "__typename": "Title",
                "id": "tt15654328",
                "originalTitleText": {
                  "__typename": "TitleText",
                  "text": "Leo"
                },
                "releaseYear": {
                  "__typename": "YearRange",
                  "year": 2023
                },
                "titleText": {
                  "__typename": "TitleText",
                  "text": "Leo"
                }
              },
              "recommendedTimedTextTrack": null,
              "runtime": {
                "__typename": "VideoRuntime",
                "value": 162
              },
              "thumbnail": {
                "__typename": "Thumbnail",
                "height": 775,
                "url": "https://m.media-amazon.com/images/M/MV5BYmUwNzIyYWUtOGEzNi00ZTQzLTg1NjEtY2ViYjAyNzAzNzg5XkEyXkFqcGdeQWthc2hpa2F4._V1_.jpg",
                "width": 1378
              },
              "timedTextTracks": []
            }
          }
        ]
      },
      "principalCredits": [
        {
          "__typename": "PrincipalCreditsForCategory",
          "category": {
            "__typename": "CreditCategory",
            "id": "director",
            "text": "Director"
          },
          "credits": [
            {
              "__typename": "Crew",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm7992231",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Lokesh Kanagaraj"
                }
              }
            }
          ],
          "totalCredits": 1
        },
        {
          "__typename": "PrincipalCreditsForCategory",
          "category": {
            "__typename": "CreditCategory",
            "id": "writer",
            "text": "Writers"
          },
          "credits": [
            {
              "__typename": "Crew",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm7992231",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Lokesh Kanagaraj"
                }
              }
            },
            {
              "__typename": "Crew",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm7188712",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Rathna Kumar"
                }
              }
            },
            {
              "__typename": "Crew",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm5338753",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Deeraj Vaidy"
                }
              }
            }
          ],
          "totalCredits": 3
        },
        {
          "__typename": "PrincipalCreditsForCategory",
          "category": {
            "__typename": "CreditCategory",
            "id": "cast",
            "text": "Stars"
          },
          "credits": [
            {
              "__typename": "Cast",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm0897201",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Joseph Vijay"
                }
              }
            },
            {
              "__typename": "Cast",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm0004569",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Sanjay Dutt"
                }
              }
            },
            {
              "__typename": "Cast",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm0440604",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Anurag Kashyap"
                }
              }
            }
          ],
          "totalCredits": 43
        }
      ],
      "production": {
        "__typename": "CompanyCreditConnection",
        "edges": [
          {
            "__typename": "CompanyCreditEdge",
            "node": {
              "__typename": "CompanyCredit",
              "company": {
                "__typename": "Company",
                "companyText": {
                  "__typename": "CompanyText",
                  "text": "Seven Screen Studio"
                },
                "id": "co0733661"
              }
            }
          },
          {
            "__typename": "CompanyCreditEdge",
            "node": {
              "__typename": "CompanyCredit",
              "company": {
                "__typename": "Company",
                "companyText": {
                  "__typename": "CompanyText",
                  "text": "The Route"
                },
                "id": "co0946109"
              }
            }
          }
        ]
      },
      "productionStatus": {
        "__typename": "ProductionStatusDetails",
        "currentProductionStage": {
          "__typename": "ProductionStage",
          "id": "released",
          "text": "Released"
        },
        "productionStatusHistory": [
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "development_unknown",
              "text": "Development Unknown"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "production_unknown",
              "text": "Production Unknown"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "production_unknown",
              "text": "Production Unknown"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "filming",
              "text": "Filming"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "filming",
              "text": "Filming"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "filming",
              "text": "Filming"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "post_production",
              "text": "Post-production"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "completed",
              "text": "Completed"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "released",
              "text": "Released"
            }
          }
        ],
        "restriction": null
      },
      "ratingsSummary": {
        "__typename": "RatingsSummary",
        "aggregateRating": 7.2,
        "voteCount": 56909
      },
      "releaseDate": {
        "__typename": "ReleaseDate",
        "day": 21,
        "month": 11,
        "year": 2023
      },
      "releaseYear": {
        "__typename": "YearRange",
        "endYear": null,
        "year": 2023
      },
      "reviews": {
        "__typename": "ReviewsConnection",
        "total": 414
      },
      "runtime": {
        "__typename": "Runtime",
        "displayableProperty": {
          "__typename": "DisplayableTitleRuntimeProperty",
          "value": {
            "__typename": "Markdown",
            "plainText": "2h 44m"
          }
        },
        "seconds": 9840
      },
      "series": null,
      "subNavCredits": {
        "__typename": "CreditConnection",
        "total": 197
      },
      "subNavFaqs": {
        "__typename": "FaqConnection",
        "total": 0
      },
      "subNavReviews": {
        "__typename": "ReviewsConnection",
        "total": 414
      },
      "subNavTopQuestions": {
        "__typename": "AlexaQuestionConnection",
        "total": 14
      },
      "subNavTrivia": {
        "__typename": "TriviaConnection",
        "total": 10
      },
      "titleGenres": {
        "__typename": "TitleGenres",
        "genres": [
          {
            "__typename": "TitleGenre",
            "genre": {
              "__typename": "GenreItem",
              "text": "Action"
            }
          },
          {
            "__typename": "TitleGenre",
            "genre": {
              "__typename": "GenreItem",
              "text": "Crime"
            }
          },
          {
            "__typename": "TitleGenre",
            "genre": {
              "__typename": "GenreItem",
              "text": "Drama"
            }
          }
        ]
      },
      "titleText": {
        "__typename": "TitleText",
        "text": "Leo"
      },
      "titleType": {
        "__typename": "TitleType",
        "canHaveEpisodes": false,
        "categories": [
          {
            "__typename": "TitleTypeCategory",
            "value": "movie"
          }
        ],
        "displayableProperty": {
          "__typename": "DisplayableTitleTypeProperty",
          "value": {
            "__typename": "Markdown",
            "plainText": ""
          }
        },
        "id": "movie",
        "isEpisode": false,
        "isSeries": false,
        "text": "Movie"
      },
      "triviaTotal": {
        "__typename": "TriviaConnection",
        "total": 10
      },
      "videos": {
        "__typename": "TitleRelatedVideosConnection",
        "total": 5
      }
    },
    "mainColumnData": {
      "__typename": "Title",
      "akas": {
        "__typename": "AkaConnection",
        "edges": [
          {
            "__typename": "AkaEdge",
            "node": {
              "__typename": "Aka",
              "text": "Лео"
            }
          }
        ]
      },
      "alternateVersions": {
        "__typename": "AlternateVersionConnection",
        "edges": [
          {
            "__typename": "AlternateVersionEdge",
            "node": {
              "__typename": "AlternateVersion",
              "text": {
                "__typename": "Markdown",
                "plaidHtml": "The UK release was cut, the distributor chose to make cuts to scenes of strong bloody violence in order to obtain a 15 classification. An uncut 18 classification was available."
              }
            }
          }
        ],
        "total": 2
      },
      "canHaveEpisodes": false,
      "canRate": {
        "__typename": "CanRate",
        "isRatable": true
      },
      "cast": {
        "__typename": "CreditConnection",
        "edges": [
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Leo Das"
                },
                {
                  "__typename": "Character",
                  "name": "Parthiban"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm0897201",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Joseph Vijay"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 955,
                  "url": "https://m.media-amazon.com/images/M/MV5BZWJlODhlMzctOTU0Yi00MTUwLTkxODYtMDNjNTQxYTI2YTE1XkEyXkFqcGdeQXVyMTEzNzg0Mjkx._V1_.jpg",
                  "width": 790
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Antony Das"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm0004569",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Sanjay Dutt"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 1365,
                  "url": "https://m.media-amazon.com/images/M/MV5BNzU2NTgwNzY1OF5BMl5BanBnXkFtZTcwMjQxNzcxOA@@._V1_.jpg",
                  "width": 2048
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Daniel"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm0440604",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Anurag Kashyap"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 2048,
                  "url": "https://m.media-amazon.com/images/M/MV5BMjExOTEyNDcwMl5BMl5BanBnXkFtZTgwMjM3NzM0OTE@._V1_.jpg",
                  "width": 1365
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": [
                {
                  "__typename": "MiscellaneousCreditAttribute",
                  "text": "voice"
                }
              ],
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Agent Vikram"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm0352032",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Kamal Haasan"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 1050,
                  "url": "https://m.media-amazon.com/images/M/MV5BYmUxNTY0MWItODQ2My00YWMyLWFmODgtNTY1MTQ2ZjEwYzdlXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  "width": 833
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actress"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Sathya"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm1375534",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Trisha Krishnan"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 1495,
                  "url": "https://m.media-amazon.com/images/M/MV5BNGZjMGM1MTgtZTAwMy00NmEwLTg5NTMtOGJlYjI3Y2UzMzVlXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  "width": 1024
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Siddharth"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm10464357",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Mathew Thomas"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 6000,
                  "url": "https://m.media-amazon.com/images/M/MV5BZGViYWRjMTQtNmQxMi00MGVjLWFhYTktYmZjZmMyMzY4MGQzXkEyXkFqcGdeQXVyMTU0MjgwMTUw._V1_.jpg",
                  "width": 4500
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Joshy Andrews"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm1069826",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Gautham Vasudev Menon"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 929,
                  "url": "https://m.media-amazon.com/images/M/MV5BNzAwNTM3Y2ItZmViZS00NWNiLWI3YmEtZWE1NWFlNWRkNzljXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  "width": 575
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actress"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Elisa Das"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm7371790",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Madonna Sebastian"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 740,
                  "url": "https://m.media-amazon.com/images/M/MV5BZjM4MzQ1ZjgtNjJkZS00YjkyLTk3YTEtMzRkMmUzMzk1Mjg2XkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_.jpg",
                  "width": 500
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Harold Das"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm0035018",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Arjun Sarja"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 750,
                  "url": "https://m.media-amazon.com/images/M/MV5BYTFjNjNkYTMtNjQ4My00OGI4LWJjNDMtNTViYzY5ZmYxYzhmXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  "width": 536
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actress"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Priya Andrews"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm3591550",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Priya Anand"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 1423,
                  "url": "https://m.media-amazon.com/images/M/MV5BOWVhNWJlNGYtYTIzNC00ZDM2LTk3MzktMTMwNjlhNDk0ODMwXkEyXkFqcGdeQXVyMTMxODA4Njgx._V1_.jpg",
                  "width": 800
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Shanmugam"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm4199426",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Mysskin"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 1271,
                  "url": "https://m.media-amazon.com/images/M/MV5BYmJhZGNkMGItNjc4MS00NzIxLWE0MTktZDcxMzAwZWUzZGFmXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  "width": 835
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": [
                {
                  "__typename": "CreditedAsCreditAttribute",
                  "text": "as Santhi Priya"
                }
              ],
              "category": {
                "__typename": "CreditCategory",
                "id": "actress"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Advocate"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm12304446",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Santhi Mayadevi"
                },
                "primaryImage": null
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Antony's henchman"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm1184326",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Babu Antony"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 4608,
                  "url": "https://m.media-amazon.com/images/M/MV5BZmRjZmFhYWItNTE2YS00ZTQ0LWEyYmUtZGViNGUxMWIxNDA1XkEyXkFqcGdeQXVyNTIzODM1MDc@._V1_.jpg",
                  "width": 2834
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Judge"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm1336722",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Denzil Smith"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 960,
                  "url": "https://m.media-amazon.com/images/M/MV5BMTUyNjUzNzU2N15BMl5BanBnXkFtZTgwNTQ2ODQzMzE@._V1_.jpg",
                  "width": 805
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "A robber in Shanmugam's gang"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm8842905",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Sandy Master"
                },
                "primaryImage": null
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actress"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "An escort"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm9306232",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Maya S. Krishnan"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 900,
                  "url": "https://m.media-amazon.com/images/M/MV5BMWY3MDg5OTgtZjAzYi00YjZmLTlkMzEtNzk3ODZiNzM0YjRkXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  "width": 720
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Shanmugam's brother-in-law"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm5157126",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Madhusudhan Rao"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 700,
                  "url": "https://m.media-amazon.com/images/M/MV5BZDNiY2ZhNjgtNmE4Zi00ZmYyLThjMzAtMzk4NzhjZmRlM2E3XkEyXkFqcGdeQXVyNDc2NzU1MTA@._V1_.jpg",
                  "width": 500
                }
              }
            }
          },
          {
            "__typename": "CreditEdge",
            "node": {
              "__typename": "Cast",
              "attributes": null,
              "category": {
                "__typename": "CreditCategory",
                "id": "actor"
              },
              "characters": [
                {
                  "__typename": "Character",
                  "name": "Hridayaraj D'Souza"
                }
              ],
              "episodeCredits": {
                "__typename": "EpisodeCastConnection",
                "total": 0,
                "yearRange": null
              },
              "name": {
                "__typename": "Name",
                "id": "nm1658967",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Mansoor Ali Khan"
                },
                "primaryImage": {
                  "__typename": "Image",
                  "height": 1500,
                  "url": "https://m.media-amazon.com/images/M/MV5BZTQ0N2U0NGMtZWY0Yy00YzE4LWIwN2ItZjc4NTYwMDk1MTAwXkEyXkFqcGdeQXVyMzYxOTQ3MDg@._V1_.jpg",
                  "width": 1090
                }
              }
            }
          }
        ]
      },
      "companies": {
        "__typename": "CompanyCreditConnection",
        "total": 14
      },
      "connections": {
        "__typename": "TitleConnectionConnection",
        "edges": [
          {
            "__typename": "TitleConnectionEdge",
            "node": {
              "__typename": "TitleConnection",
              "associatedTitle": {
                "__typename": "Title",
                "id": "tt1176176",
                "originalTitleText": {
                  "__typename": "TitleText",
                  "text": "Polladhavan"
                },
                "releaseYear": {
                  "__typename": "YearRange",
                  "year": 1980
                },
                "series": null,
                "titleText": {
                  "__typename": "TitleText",
                  "text": "Polladhavan"
                }
              },
              "category": {
                "__typename": "TitleConnectionCategory",
                "text": "Features"
              }
            }
          }
        ]
      },
      "contributionQuestions": {
        "__typename": "QuestionConnection",
        "contributionLink": {
          "__typename": "ContributionQuestionsLink",
          "url": "https://contribute.imdb.com/answers"
        },
        "edges": [
          {
            "__typename": "QuestionEdge",
            "node": {
              "__typename": "Question",
              "contributionLink": {
                "__typename": "ContributionQuestionsLink",
                "url": "https://contribute.imdb.com/answers?pinnedQuestion=tt15654328.certificate.IN"
              },
              "entity": {
                "__typename": "Title",
                "primaryImage": {
                  "__typename": "Image",
                  "caption": {
                    "__typename": "Markdown",
                    "plainText": "Joseph Vijay in Leo (2023)"
                  },
                  "height": 1633,
                  "url": "https://m.media-amazon.com/images/M/MV5BMmFiOGYyZjQtZmZmNC00ZTgzLWI5ZjktMTRiYzc5NjAzODRkXkEyXkFqcGdeQXVyMTYyNDkzNzgz._V1_.jpg",
                  "width": 1080
                }
              },
              "questionId": "tt15654328.certificate.IN",
              "questionText": {
                "__typename": "Markdown",
                "plainText": "What was the official certification given to Leo (2023) in India?"
              }
            }
          }
        ]
      },
      "countriesOfOrigin": {
        "__typename": "CountriesOfOrigin",
        "countries": [
          {
            "__typename": "CountryOfOrigin",
            "id": "IN",
            "text": "India"
          }
        ]
      },
      "crazyCredits": {
        "__typename": "CrazyCreditConnection",
        "edges": []
      },
      "creators": [],
      "detailsExternalLinks": {
        "__typename": "ExternalLinkConnection",
        "edges": [],
        "total": 0
      },
      "directors": [
        {
          "__typename": "PrincipalCreditsForCategory",
          "category": {
            "__typename": "CreditCategory",
            "text": "Director"
          },
          "credits": [
            {
              "__typename": "Crew",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm7992231",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Lokesh Kanagaraj"
                }
              }
            }
          ],
          "totalCredits": 1
        }
      ],
      "episodes": null,
      "faqs": {
        "__typename": "FaqConnection",
        "edges": [],
        "total": 0
      },
      "featuredReviews": {
        "__typename": "ReviewsConnection",
        "edges": [
          {
            "__typename": "ReviewEdge",
            "node": {
              "__typename": "Review",
              "author": {
                "__typename": "UserProfile",
                "nickName": "arungeorge13",
                "userId": "ur30872044"
              },
              "authorRating": 6,
              "helpfulness": {
                "__typename": "ReviewHelpfulness",
                "downVotes": 40,
                "upVotes": 76
              },
              "id": "rw9384546",
              "submissionDate": "2023-10-19",
              "summary": {
                "__typename": "ReviewSummary",
                "originalText": "Would've worked fine as a standalone piece, if you ask me! [+62%]"
              },
              "text": {
                "__typename": "ReviewText",
                "originalText": {
                  "__typename": "Markdown",
                  "plaidHtml": "On the bright side, we get..<br/><br/><ul><li>One of Vijay&#39;s finest performances (not as a star, but as an actor): The first half is replete with moments where Vijay showcases emotions as a doting father, husband, cafe owner, and animal lover.</li></ul><br/><br/><ul><li>The writing in the first half: Superb, even when it&#39;s A History of Violence contextualized for Tamil sensibilities. Every scene carries a decent tempo, and the developments make you sit up. The whole hyena angle is beautifully executed, and its payoff in the climax is wonderful. The title card placement is a nice creative touch on Lokesh&#39;s part.</li></ul><br/><br/><ul><li>Brilliant cinematography: Manoj Paramahamsa&#39;s frames wonderfully capture the Kashmiri locales (even though the film is &quot;set&quot; in Theog, Himachal Pradesh) with Parthipan&#39;s (Vijay) cafe looking remarkably aesthetic in that first fight sequence. When the film gets action-heavy, the use of the mocobot camera is put to fine effect.</li></ul><br/><br/><ul><li>A pretty solid supporting cast: Whether it be Trisha (who looks absolutely dashing), Gautham Menon, Arjun Sarja, Sanjay Dutt, or Mathew Thomas, they deliver what the writing expects them to. It&#39;s just that the antagonists (Dutt, Sarja) lack sufficient fleshing out for us to care about their motives.</li></ul><br/><br/><ul><li>Anirudh&#39;s music: While I feel he overdid the score a bit in the film, the elevation points (particularly a 10-15 minute pre-interval stretch) are fabulous, courtesy of his compositions. Badass Ma is the clear standout, but Naa Ready also worked thanks to the choreography. The English bits in the score were tremendous, and I can&#39;t wait to blast them on Spotify for my workouts once the OST is uploaded.</li></ul><br/><br/>On the not-so-bright side, we get..<br/><br/><ul><li>A lackluster second half: The whole flashback segment suffers from tepid writing. A key character is introduced only to be killed off just a few minutes later. The writing doesn&#39;t give us any time to register this character, let alone connect emotionally. This then becomes the driving force for the protagonist&#39;s subsequent actions. The whole &quot;identity crisis&quot; aspect also wears out, because there&#39;s only so much you can do with it. In totality, this is a 75% Lokesh, 25% Vijay film.</li></ul><br/><br/><ul><li>Some tacky CGI: While this doesn&#39;t hamper the viewing experience overall, you&#39;ll come across not-so-great CG work in certain parts. This is especially the case in a car chase sequence.</li></ul><br/><br/><ul><li>The LCU connect: Felt somewhat inorganic and forced. Given the film takes place geographically far away from the proceedings of the LCU, I felt it stood a better chance as a standalone piece. There are some interesting cameos yes, but nothing that gives you the wowness of Vikram, or even Kaithi for that matter. Lokesh definitely reserved his best for Aandavar.</li></ul><br/><br/>Middle-of-the-road aspect: Anbariv masters are quite well-known for their innovative set pieces. I loved the first set piece (at the cafe) - it felt raw and real, with fantastic cuts and zero slo-mo. There are plenty more in various locations, but only the climactic showdown (which also includes a 1v1 between Vijay and Arjun) lingers in my mind after leaving the cinema hall.<br/><br/>P. S. - I enjoyed Loki&#39;s tribute to Sly Stallone. If you know, you know."
                }
              }
            }
          }
        ]
      },
      "filmingLocations": {
        "__typename": "FilmingLocationConnection",
        "edges": [
          {
            "__typename": "FilmingLocationEdge",
            "node": {
              "__typename": "FilmingLocation",
              "attributes": [
                {
                  "__typename": "DisplayableAttribute",
                  "text": "Filming City"
                }
              ],
              "location": "Kashmir, India",
              "text": "Kashmir, India"
            }
          }
        ],
        "total": 7
      },
      "goofs": {
        "__typename": "GoofConnection",
        "edges": [
          {
            "__typename": "GoofEdge",
            "node": {
              "__typename": "Goof",
              "text": {
                "__typename": "Markdown",
                "plaidHtml": "While Parthiban is dropping Siddhu to school, he gets the call from Joshy to tame the hyena, he makes Siddhu promise to not tell his mother he was late and then they both go to tame the hyena, but after taming the hyena Parthiban just goes home and Siddhu just magically teleports to school while also leaving the car behind."
              }
            }
          }
        ]
      },
      "goofsTotal": {
        "__typename": "GoofConnection",
        "total": 1
      },
      "id": "tt15654328",
      "iframeAddReviewLink": {
        "__typename": "ContributionLink",
        "url": "https://contribute.imdb.com/review/tt15654328/add?bus=imdb&return_url=https%3A%2F%2Fwww.imdb.com%2Fclose_me&site=web"
      },
      "imageUploadLink": {
        "__typename": "ContributionLink",
        "url": "https://contribute.imdb.com/image/tt15654328/add?bus=imdb&return_url=https%3A%2F%2Fwww.imdb.com%2Fclose_me&site=web"
      },
      "isAdult": false,
      "lifetimeGross": null,
      "moreLikeThisTitles": {
        "__typename": "MoreLikeThisConnection",
        "edges": [
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": {
                "__typename": "Certificate",
                "rating": "Not Rated"
              },
              "id": "tt11663228",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "Jailer"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Jackie Shroff, Ramya Krishnan, Mohanlal, Rajinikanth, Mirnaa, Tamannaah Bhatia, Vinayakan, Shivarajkumar, and Yogi Babu in Jailer (2023)"
                },
                "height": 2048,
                "id": "rm353982465",
                "url": "https://m.media-amazon.com/images/M/MV5BNzFkNmZkMTctYjRhMS00ODZiLWFlNjQtZmZmN2IzMDJlNmVkXkEyXkFqcGdeQXVyMTY1MzAyNjU4._V1_.jpg",
                "width": 1313
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 7.1,
                "voteCount": 33575
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2023
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 10080
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Comedy"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Crime"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "Jailer"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": {
                "__typename": "Certificate",
                "rating": "Not Rated"
              },
              "id": "tt15354916",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "Jawan"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Sanjay Dutt, Priyamani, Nayanthara, and Deepika Padukone in Jawan (2023)"
                },
                "height": 1350,
                "id": "rm4279328001",
                "url": "https://m.media-amazon.com/images/M/MV5BOWI5NmU3NTUtOTZiMS00YzA1LThlYTktNDJjYTU5NDFiMDUxXkEyXkFqcGdeQXVyMTUzNjEwNjM2._V1_.jpg",
                "width": 1080
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 7,
                "voteCount": 91964
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2023
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 10140
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Drama"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Musical"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "Jawan"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": null,
              "id": "tt9179430",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "Vikram"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Kamal Haasan in Vikram (2022)"
                },
                "height": 1920,
                "id": "rm1740833281",
                "url": "https://m.media-amazon.com/images/M/MV5BMDRiOWNjYjUtMDI0ZC00MDMyLTkwZDItNTU5NWQ1NjEyNGYxXkEyXkFqcGdeQXVyMTIyNzY0NTMx._V1_.jpg",
                "width": 1080
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 8.3,
                "voteCount": 73468
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2022
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 10500
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Crime"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Thriller"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "Vikram"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": {
                "__typename": "Certificate",
                "rating": "Not Rated"
              },
              "id": "tt10698680",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "K.G.F: Chapter 2"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Sanjay Dutt, Prakash Raj, Easwari Rao, Raveena Tandon, Rao Ramesh, Yash, Achyuth Kumar, and Srinidhi Shetty in K.G.F: Chapter 2 (2022)"
                },
                "height": 1350,
                "id": "rm2414604801",
                "url": "https://m.media-amazon.com/images/M/MV5BMjI2Njg2Y2EtZjgwMC00ZGVkLWJmMWYtYjVhYjk2ZTkwNWE1XkEyXkFqcGdeQXVyMTMxMjA5NDU1._V1_.jpg",
                "width": 1080
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 8.3,
                "voteCount": 149169
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2022
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 9960
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Crime"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Drama"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "K.G.F: Chapter 2"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": {
                "__typename": "Certificate",
                "rating": "Not Rated"
              },
              "id": "tt9900782",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "Kaithi"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Arjun Das, Narain, and Karthi in Kaithi (2019)"
                },
                "height": 916,
                "id": "rm1211903233",
                "url": "https://m.media-amazon.com/images/M/MV5BZTVlNGY2YTEtNTlmYy00NzY0LWE1NWUtOGJiNTgxZGM4ZmMzXkEyXkFqcGdeQXVyMTY1MzAyNjU4._V1_.jpg",
                "width": 685
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 8.4,
                "voteCount": 41887
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2019
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 8700
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Crime"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Thriller"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "Kaithi"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": {
                "__typename": "Certificate",
                "rating": "Not Rated"
              },
              "id": "tt13751694",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "Animal"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Bobby Deol, Anil Kapoor, Ranbir Kapoor, Saloni Batra, Rashmika Mandanna, and Anshul Chauhan in Animal (2023)"
                },
                "height": 1348,
                "id": "rm3809102337",
                "url": "https://m.media-amazon.com/images/M/MV5BNGViM2M4NmUtMmNkNy00MTQ5LTk5MDYtNmNhODAzODkwOTJlXkEyXkFqcGdeQXVyMTY1NDY4NTIw._V1_.jpg",
                "width": 1078
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 6.3,
                "voteCount": 81601
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2023
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 12240
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Crime"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Drama"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "Animal"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": null,
              "id": "tt13927994",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "Salaar: Cease Fire - Part 1"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Prabhas in Salaar (2023)"
                },
                "height": 1500,
                "id": "rm2712555009",
                "url": "https://m.media-amazon.com/images/M/MV5BMmU4ZTM0MTctZTQ3Ny00YjZmLWFhNzEtOGYzMDk0ZjcyNmYzXkEyXkFqcGdeQXVyMTUyNjIwMDEw._V1_.jpg",
                "width": 1200
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 6.5,
                "voteCount": 60108
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2023
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 10500
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Crime"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Drama"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "Salaar"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": null,
              "id": "tt15732324",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "OMG 2"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Akshay Kumar and Pankaj Tripathi in OMG 2 (2023)"
                },
                "height": 1707,
                "id": "rm3878836225",
                "url": "https://m.media-amazon.com/images/M/MV5BNmQ3MThkOWEtNTA0NC00YzI2LWIxZjEtZjdlZTVmNzQ2ZGViXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg",
                "width": 1280
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 7.6,
                "voteCount": 39474
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2023
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 9360
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Comedy"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Drama"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "OMG 2"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": {
                "__typename": "Certificate",
                "rating": "Not Rated"
              },
              "id": "tt18411490",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "Tiger 3"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Salman Khan, Katrina Kaif, and Emraan Hashmi in Tiger 3 (2023)"
                },
                "height": 400,
                "id": "rm2346995969",
                "url": "https://m.media-amazon.com/images/M/MV5BYzQwMGZlYTUtODUwNi00ZjQxLWEzODAtZGU3Zjc0MmNhMzhkXkEyXkFqcGdeQXVyNTkzNDQ4ODc@._V1_.jpg",
                "width": 300
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 5.8,
                "voteCount": 52060
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2023
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 9300
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Adventure"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Thriller"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "Tiger 3"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": {
                "__typename": "Certificate",
                "rating": "Not Rated"
              },
              "id": "tt8178634",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "RRR (Rise Roar Revolt)"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Ajay Devgn, Alia Bhatt, Olivia Morris, N.T. Rama Rao Jr., and Ram Charan in RRR: Naatu Naatu (2021)"
                },
                "height": 1000,
                "id": "rm535173377",
                "url": "https://m.media-amazon.com/images/M/MV5BODUwNDNjYzctODUxNy00ZTA2LWIyYTEtMDc5Y2E5ZjBmNTMzXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg",
                "width": 750
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 7.8,
                "voteCount": 165260
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2022
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 11220
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Drama"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "RRR"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": {
                "__typename": "Certificate",
                "rating": "Not Rated"
              },
              "id": "tt10579952",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "Master"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Joseph Vijay in Master (2021)"
                },
                "height": 1867,
                "id": "rm1559593217",
                "url": "https://m.media-amazon.com/images/M/MV5BODNiYjExMjgtYTc1ZC00YTlhLWFkZTEtY2JmM2JiMTIwMGRjXkEyXkFqcGdeQXVyOTk3NTc2MzE@._V1_.jpg",
                "width": 1400
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 7.4,
                "voteCount": 82973
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2021
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 10740
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Crime"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Thriller"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "Master"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          },
          {
            "__typename": "MoreLikeThisEdge",
            "node": {
              "__typename": "Title",
              "canHaveEpisodes": false,
              "canRate": {
                "__typename": "CanRate",
                "isRatable": true
              },
              "certificate": {
                "__typename": "Certificate",
                "rating": "Not Rated"
              },
              "id": "tt9389998",
              "originalTitleText": {
                "__typename": "TitleText",
                "text": "Pushpa: The Rise - Part 1"
              },
              "primaryImage": {
                "__typename": "Image",
                "caption": {
                  "__typename": "Markdown",
                  "plainText": "Allu Arjun in Pushpa: The Rise - Part 1 (2021)"
                },
                "height": 1200,
                "id": "rm3160735489",
                "url": "https://m.media-amazon.com/images/M/MV5BMmQ4YmM3NjgtNTExNC00ZTZhLWEwZTctYjdhOWI4ZWFlMDk2XkEyXkFqcGdeQXVyMTI1NDEyNTM5._V1_.jpg",
                "width": 800
              },
              "ratingsSummary": {
                "__typename": "RatingsSummary",
                "aggregateRating": 7.6,
                "voteCount": 86695
              },
              "releaseYear": {
                "__typename": "YearRange",
                "endYear": null,
                "year": 2021
              },
              "runtime": {
                "__typename": "Runtime",
                "seconds": 10740
              },
              "titleGenres": {
                "__typename": "TitleGenres",
                "genres": [
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Action"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Crime"
                    }
                  },
                  {
                    "__typename": "TitleGenre",
                    "genre": {
                      "__typename": "GenreItem",
                      "text": "Drama"
                    }
                  }
                ]
              },
              "titleText": {
                "__typename": "TitleText",
                "text": "Pushpa: The Rise - Part 1"
              },
              "titleType": {
                "__typename": "TitleType",
                "canHaveEpisodes": false,
                "displayableProperty": {
                  "__typename": "DisplayableTitleTypeProperty",
                  "value": {
                    "__typename": "Markdown",
                    "plainText": ""
                  }
                },
                "id": "movie",
                "text": "Movie"
              }
            }
          }
        ]
      },
      "nominations": {
        "__typename": "AwardNominationConnection",
        "total": 4
      },
      "openingWeekendGross": null,
      "originalTitleText": {
        "__typename": "TitleText",
        "text": "Leo"
      },
      "prestigiousAwardSummary": null,
      "primaryImage": {
        "__typename": "Image",
        "id": "rm2551271425"
      },
      "production": {
        "__typename": "CompanyCreditConnection",
        "edges": [
          {
            "__typename": "CompanyCreditEdge",
            "node": {
              "__typename": "CompanyCredit",
              "company": {
                "__typename": "Company",
                "companyText": {
                  "__typename": "CompanyText",
                  "text": "Seven Screen Studio"
                },
                "id": "co0733661"
              }
            }
          },
          {
            "__typename": "CompanyCreditEdge",
            "node": {
              "__typename": "CompanyCredit",
              "company": {
                "__typename": "Company",
                "companyText": {
                  "__typename": "CompanyText",
                  "text": "The Route"
                },
                "id": "co0946109"
              }
            }
          }
        ]
      },
      "productionBudget": null,
      "productionStatus": {
        "__typename": "ProductionStatusDetails",
        "currentProductionStage": {
          "__typename": "ProductionStage",
          "id": "released",
          "text": "Released"
        },
        "productionStatusHistory": [
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "development_unknown",
              "text": "Development Unknown"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "production_unknown",
              "text": "Production Unknown"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "production_unknown",
              "text": "Production Unknown"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "filming",
              "text": "Filming"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "filming",
              "text": "Filming"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "filming",
              "text": "Filming"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "post_production",
              "text": "Post-production"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "completed",
              "text": "Completed"
            }
          },
          {
            "__typename": "ProductionStatusHistory",
            "status": {
              "__typename": "ProductionStatus",
              "id": "released",
              "text": "Released"
            }
          }
        ],
        "restriction": null
      },
      "quotes": {
        "__typename": "TitleQuoteConnection",
        "edges": []
      },
      "quotesTotal": {
        "__typename": "TitleQuoteConnection",
        "total": 0
      },
      "ratingsSummary": {
        "__typename": "RatingsSummary",
        "topRanking": {
          "__typename": "TopRanking",
          "id": "topRated:tt15654328:en_US",
          "rank": 2716,
          "text": {
            "__typename": "LocalizedString",
            "value": "Top Rated"
          }
        }
      },
      "releaseDate": {
        "__typename": "ReleaseDate",
        "country": {
          "__typename": "LocalizedDisplayableCountry",
          "id": "US",
          "text": "United States"
        },
        "day": 21,
        "month": 11,
        "year": 2023
      },
      "releaseYear": {
        "__typename": "YearRange",
        "year": 2023
      },
      "reviews": {
        "__typename": "ReviewsConnection",
        "total": 414
      },
      "runtime": {
        "__typename": "Runtime",
        "seconds": 9840
      },
      "series": null,
      "soundtrack": {
        "__typename": "SoundtrackConnection",
        "edges": [
          {
            "__typename": "SoundtrackEdge",
            "node": {
              "__typename": "Track",
              "comments": [
                {
                  "__typename": "Markdown",
                  "plaidHtml": "Music by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm4794064/?ref_=tt_trv_snd\">Anirudh Ravichander</a>"
                },
                {
                  "__typename": "Markdown",
                  "plaidHtml": "Lyrics by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm14530447/?ref_=tt_trv_snd\">Heisenberg</a>"
                },
                {
                  "__typename": "Markdown",
                  "plaidHtml": "Performed by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm4794064/?ref_=tt_trv_snd\">Anirudh Ravichander</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm4837111/?ref_=tt_trv_snd\">Siddharth Basrur</a>"
                }
              ],
              "text": "Bloody Sweet"
            }
          }
        ]
      },
      "spokenLanguages": {
        "__typename": "SpokenLanguages",
        "spokenLanguages": [
          {
            "__typename": "SpokenLanguage",
            "id": "ta",
            "text": "Tamil"
          }
        ]
      },
      "technicalSpecifications": {
        "__typename": "TechnicalSpecifications",
        "aspectRatios": {
          "__typename": "AspectRatios",
          "items": [
            {
              "__typename": "AspectRatio",
              "aspectRatio": "2.39 : 1",
              "attributes": []
            }
          ]
        },
        "colorations": {
          "__typename": "Colorations",
          "items": [
            {
              "__typename": "Coloration",
              "attributes": [],
              "conceptId": "color",
              "text": "Color"
            }
          ]
        },
        "soundMixes": {
          "__typename": "SoundMixes",
          "items": []
        }
      },
      "titleMainImages": {
        "__typename": "ImageConnection",
        "edges": [
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Sanjay Dutt, Arjun Sarja, Kamal Haasan, Anurag Kashyap, Joseph Vijay, Mathew Thomas, Gautham Vasudev Menon, Babu Antony, Denzil Smith, Trisha Krishnan, Mansoor Ali Khan, Priya Anand, Mysskin, Anirudh Ravichander, Madhusudhan Rao, George Maryan, Madonna Sebastian, Lokesh Kanagaraj, and Sandy Master in Leo (2023)"
              },
              "height": 688,
              "id": "rm854806785",
              "url": "https://m.media-amazon.com/images/M/MV5BMWQ4MmNmMTAtNmNjMy00M2IwLTlkYzgtNDA0OWRmMTdkNmY2XkEyXkFqcGdeQXVyMTY1MzAyNjU4._V1_.jpg",
              "width": 1032
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Joseph Vijay in Leo (2023)"
              },
              "height": 829,
              "id": "rm121132289",
              "url": "https://m.media-amazon.com/images/M/MV5BY2ZiODc1MmMtYTVmMy00YTMwLTk4ZWEtMGQ2ZTI0ZDczMDhjXkEyXkFqcGdeQXVyMTQ3Mzk2MDg4._V1_.jpg",
              "width": 660
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Sanjay Dutt, Arjun Sarja, Joseph Vijay, Gautham Vasudev Menon, and Mysskin in Leo (2023)"
              },
              "height": 420,
              "id": "rm1797083905",
              "url": "https://m.media-amazon.com/images/M/MV5BZDQzZjNkODAtOTljYi00OGJkLWIwN2ItYTE4ZmFjYTNlMzZjXkEyXkFqcGdeQXVyMTY3ODkyNDkz._V1_.jpg",
              "width": 310
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Joseph Vijay in Leo (2023)"
              },
              "height": 1500,
              "id": "rm1630098177",
              "url": "https://m.media-amazon.com/images/M/MV5BYTAzYzVlYmItMWI1Yi00ZGRjLTkwYWUtYWM3ZDIwOGFiODk4XkEyXkFqcGdeQXVyMTY3ODkyNDkz._V1_.jpg",
              "width": 1000
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Leo (2023)"
              },
              "height": 420,
              "id": "rm1515606785",
              "url": "https://m.media-amazon.com/images/M/MV5BMmE5YjEzMTEtMmRmZS00YzVkLThjZmYtNTA2ZjEwYzlmOGM4XkEyXkFqcGdeQXVyMTY3ODkyNDkz._V1_.jpg",
              "width": 310
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Sanjay Dutt and Joseph Vijay in Leo (2023)"
              },
              "height": 2126,
              "id": "rm2849526273",
              "url": "https://m.media-amazon.com/images/M/MV5BODcwZDhjNzMtMDA5Mi00OTlkLWI5MTktZWExODA1NDA5ZWE5XkEyXkFqcGdeQXVyMTUyNjIwMDEw._V1_.jpg",
              "width": 1400
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Sanjay Dutt and Joseph Vijay in Leo (2023)"
              },
              "height": 2126,
              "id": "rm2899857921",
              "url": "https://m.media-amazon.com/images/M/MV5BM2Y4MzQ3NmUtOWQ5My00YTFjLTkzNDMtNzliODQ5NTFmZjg3XkEyXkFqcGdeQXVyMTUyNjIwMDEw._V1_.jpg",
              "width": 1400
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Joseph Vijay in Leo (2023)"
              },
              "height": 2048,
              "id": "rm2030525697",
              "url": "https://m.media-amazon.com/images/M/MV5BMmJjODA4ZTMtNWIxMy00MGU4LThkYTctYTNiNDRlMDFiZDdmXkEyXkFqcGdeQXVyMTUyNjIwMDEw._V1_.jpg",
              "width": 1348
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Leo (2023)"
              },
              "height": 845,
              "id": "rm2897435137",
              "url": "https://m.media-amazon.com/images/M/MV5BNDhhMjU3ZTktNWE5OS00NmY1LTlkMGMtYzczMjljNjUzMjdjXkEyXkFqcGdeQXVyMTQ3Mzk2MDg4._V1_.jpg",
              "width": 438
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Leo (2023)"
              },
              "height": 2048,
              "id": "rm3139315201",
              "url": "https://m.media-amazon.com/images/M/MV5BYTU0NjZmOGUtZWE2NS00OWQ2LWI2NjgtMDRkZGEwZmFkZTgzXkEyXkFqcGdeQXVyMTU0ODI1NTA2._V1_.jpg",
              "width": 1152
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Leo (2023)"
              },
              "height": 826,
              "id": "rm2420323073",
              "url": "https://m.media-amazon.com/images/M/MV5BNWEwYjY1N2ItMzcxOS00YTRmLTk5NDctN2M1MTljYWJkYmMyXkEyXkFqcGdeQXVyMTUzNTgzNzM0._V1_.jpg",
              "width": 462
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Joseph Vijay in Leo (2023)"
              },
              "height": 1366,
              "id": "rm3568453633",
              "url": "https://m.media-amazon.com/images/M/MV5BYjk2YWRmYjctMDk3NS00ZDNiLWFiNGItY2IwMzdjMjhhODU0XkEyXkFqcGdeQXVyMTM1OTU1MzQx._V1_.jpg",
              "width": 2048
            }
          },
          {
            "__typename": "ImageEdge",
            "node": {
              "__typename": "Image",
              "caption": {
                "__typename": "Markdown",
                "plainText": "Joseph Vijay in Leo (2023)"
              },
              "height": 1367,
              "id": "rm3400681473",
              "url": "https://m.media-amazon.com/images/M/MV5BMmJjZDkyYTUtM2M4MC00YTUzLTlmZDgtMTk1MWQxMWI5ZTJhXkEyXkFqcGdeQXVyMTM1OTU1MzQx._V1_.jpg",
              "width": 2048
            }
          }
        ],
        "total": 95
      },
      "titleText": {
        "__typename": "TitleText",
        "text": "Leo"
      },
      "titleType": {
        "__typename": "TitleType",
        "canHaveEpisodes": false,
        "id": "movie"
      },
      "topQuestions": {
        "__typename": "AlexaQuestionConnection",
        "edges": [
          {
            "__typename": "AlexaQuestionEdge",
            "node": {
              "__typename": "AlexaQuestion",
              "attributeId": "run-time",
              "question": {
                "__typename": "Markdown",
                "plainText": "How long is Leo?"
              }
            }
          }
        ],
        "total": 14
      },
      "trivia": {
        "__typename": "TriviaConnection",
        "edges": [
          {
            "__typename": "TriviaEdge",
            "node": {
              "__typename": "TitleTrivia",
              "relatedNames": null,
              "text": {
                "__typename": "Markdown",
                "plaidHtml": "This film is heavily inspired by the classic graphic novel &quot;A History of Violence&quot;."
              },
              "trademark": null
            }
          }
        ]
      },
      "triviaTotal": {
        "__typename": "TriviaConnection",
        "total": 10
      },
      "videoStrip": {
        "__typename": "VideoConnection",
        "edges": [
          {
            "__typename": "VideoEdge",
            "node": {
              "__typename": "Video",
              "contentType": {
                "__typename": "VideoContentType",
                "displayName": {
                  "__typename": "LocalizedString",
                  "value": "Trailer"
                }
              },
              "id": "vi3073296153",
              "name": {
                "__typename": "LocalizedString",
                "value": "Official Trailer"
              },
              "runtime": {
                "__typename": "VideoRuntime",
                "value": 141
              },
              "thumbnail": {
                "__typename": "Thumbnail",
                "height": 1080,
                "url": "https://m.media-amazon.com/images/M/MV5BYjY1YjliNjQtOTU4NC00M2JlLWEwY2MtMmI2YjlmNThkMmY3XkEyXkFqcGdeQWpvc2FyYw@@._V1_.jpg",
                "width": 1920
              }
            }
          },
          {
            "__typename": "VideoEdge",
            "node": {
              "__typename": "Video",
              "contentType": {
                "__typename": "VideoContentType",
                "displayName": {
                  "__typename": "LocalizedString",
                  "value": "Trailer"
                }
              },
              "id": "vi2111686425",
              "name": {
                "__typename": "LocalizedString",
                "value": "Leo - Official Trailer"
              },
              "runtime": {
                "__typename": "VideoRuntime",
                "value": 162
              },
              "thumbnail": {
                "__typename": "Thumbnail",
                "height": 775,
                "url": "https://m.media-amazon.com/images/M/MV5BYmUwNzIyYWUtOGEzNi00ZTQzLTg1NjEtY2ViYjAyNzAzNzg5XkEyXkFqcGdeQWthc2hpa2F4._V1_.jpg",
                "width": 1378
              }
            }
          },
          {
            "__typename": "VideoEdge",
            "node": {
              "__typename": "Video",
              "contentType": {
                "__typename": "VideoContentType",
                "displayName": {
                  "__typename": "LocalizedString",
                  "value": "Clip"
                }
              },
              "id": "vi2010891545",
              "name": {
                "__typename": "LocalizedString",
                "value": "Most Anticipated Indian Movies of 2023"
              },
              "runtime": {
                "__typename": "VideoRuntime",
                "value": 61
              },
              "thumbnail": {
                "__typename": "Thumbnail",
                "height": 1080,
                "url": "https://m.media-amazon.com/images/M/MV5BNTQ1ZDhmOWMtMWE5Mi00NTc0LWI4YTUtMzM0ZmJmNGMyMzcwXkEyXkFqcGdeQWthc2hpa2F4._V1_.jpg",
                "width": 1920
              }
            }
          },
          {
            "__typename": "VideoEdge",
            "node": {
              "__typename": "Video",
              "contentType": {
                "__typename": "VideoContentType",
                "displayName": {
                  "__typename": "LocalizedString",
                  "value": "Promo"
                }
              },
              "id": "vi2977416473",
              "name": {
                "__typename": "LocalizedString",
                "value": "LEO - Bloody Sweet Promo"
              },
              "runtime": {
                "__typename": "VideoRuntime",
                "value": 169
              },
              "thumbnail": {
                "__typename": "Thumbnail",
                "height": 720,
                "url": "https://m.media-amazon.com/images/M/MV5BM2Y1YjhhZDAtYjliZS00YTJiLWEzYjAtZjNjZDU1ZjQyZjZkXkEyXkFqcGdeQXRyYW5zY29kZS13b3JrZmxvdw@@._V1_.jpg",
                "width": 1280
              }
            }
          }
        ]
      },
      "videos": {
        "__typename": "TitleRelatedVideosConnection",
        "total": 5
      },
      "wins": {
        "__typename": "AwardNominationConnection",
        "total": 0
      },
      "worldwideGross": {
        "__typename": "BoxOfficeGross",
        "total": {
          "__typename": "Money",
          "amount": 6978436,
          "currency": "USD"
        }
      },
      "writers": [
        {
          "__typename": "PrincipalCreditsForCategory",
          "category": {
            "__typename": "CreditCategory",
            "text": "Writers"
          },
          "credits": [
            {
              "__typename": "Crew",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm7992231",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Lokesh Kanagaraj"
                }
              }
            },
            {
              "__typename": "Crew",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm7188712",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Rathna Kumar"
                }
              }
            },
            {
              "__typename": "Crew",
              "attributes": null,
              "name": {
                "__typename": "Name",
                "id": "nm5338753",
                "nameText": {
                  "__typename": "NameText",
                  "text": "Deeraj Vaidy"
                }
              }
            }
          ],
          "totalCredits": 3
        }
      ]
    }
  },
  "message": "Successful",
  "status": true
}
// IMages
const image={
  "currentPage": 1,
  "data": [
    {
      "id": "/title/tt6857128/mediaviewer/rm2478219265",
      "image": "https://m.media-amazon.com/images/M/MV5BZjg1ZmFkYjMtZDY4YS00NjhmLThkMmYtOGIyNjJhZjU5MzFiXkEyXkFqcGdeQXVyNTAzMTc1NjE@._V1_UY100_UX100_AL_.jpg",
      "imageWeb": "https://www.imdb.com/title/tt6857128/mediaviewer/rm2478219265",
      "title": "Naomi Watts at an event for Unaired Game of Thrones Prequel Pilot (2019)"
    },
    {
      "id": "/title/tt6857128/mediaviewer/rm3530220545",
      "image": "https://m.media-amazon.com/images/M/MV5BODg5NDJhMjYtMTYyYi00NzAwLTliNmYtNGZhMjQ4ZjNkMjgyXkEyXkFqcGdeQXVyNTA3MTU2MjE@._V1_UY100_CR39,0,100,100_AL_.jpg",
      "imageWeb": "https://www.imdb.com/title/tt6857128/mediaviewer/rm3530220545",
      "title": "Georgie Henley, Denise Gough, Toby Regbo, Jamie Campbell Bower, Ivanno Jeremiah, Alex Sharp, Sheila Atim, and Naomi Ackie in Unaired Game of Thrones Prequel Pilot (2019)"
    },
    {
      "id": "/title/tt6857128/mediaviewer/rm4184531969",
      "image": "https://m.media-amazon.com/images/M/MV5BZmE5NjdjZWUtNmEyMS00NmZiLTk5YzYtNmI1OGNkOTJlZTM5XkEyXkFqcGdeQXVyNTA3MTU2MjE@._V1_UY100_CR39,0,100,100_AL_.jpg",
      "imageWeb": "https://www.imdb.com/title/tt6857128/mediaviewer/rm4184531969",
      "title": "Naomi Watts and Josh Whitehouse in Unaired Game of Thrones Prequel Pilot (2019)"
    },
    {
      "id": "/title/tt6857128/mediaviewer/rm158886400",
      "image": "https://m.media-amazon.com/images/M/MV5BMGJiZjNiYzktMDEzNi00YzRkLWI1MTMtOTJiODYzYTQxMTA2XkEyXkFqcGdeQXVyNTQxOTM1NTc@._V1_UY100_CR106,0,100,100_AL_.jpg",
      "imageWeb": "https://www.imdb.com/title/tt6857128/mediaviewer/rm158886400",
      "title": "Georgie Henley, Toby Regbo, Ivanno Jeremiah, and Alex Sharp in Unaired Game of Thrones Prequel Pilot (2019)"
    },
    {
      "id": "/title/tt6857128/mediaviewer/rm1751607808",
      "image": "https://m.media-amazon.com/images/M/MV5BY2ZkOTYzNGItYTU3Yy00NDE3LWEwZTMtNzYwZmU5ZDJjMDZkXkEyXkFqcGdeQXVyNTQxOTM1NTc@._V1_UY100_CR106,0,100,100_AL_.jpg",
      "imageWeb": "https://www.imdb.com/title/tt6857128/mediaviewer/rm1751607808",
      "title": "Denise Gough, Jamie Campbell Bower, Sheila Atim, and Naomi Ackie in Unaired Game of Thrones Prequel Pilot (2019)"
    },
    {
      "id": "/registration/signin",
      "image": null,
      "imageWeb": "https://www.imdb.com/registration/signin",
      "title": ""
    }
  ],
  "message": "Successful",
  "resultsPerPage": 48,
  "status": true,
  "totalPages": 1,
  "totalResultCount": 5
}

// Video
const video={
  "currentPage": 1,
  "data": [
    {
      "id": "vi3689725721",
      "image": "https://m.media-amazon.com/images/M/MV5BZmU2MTFiMmUtOTgzNi00YjM4LWJmYWItYjQ0MzY2YzNlOGM5XkEyXkFqcGdeQWFsZWxvZw@@._V1_SP330,330,0,C,0,0,0_CR65,90,200,150_PIimdb-blackband-204-14,TopLeft,0,0_PIimdb-blackband-204-28,BottomLeft,0,1_CR0,0,200,150_PIimdb-bluebutton-big,BottomRight,-1,-1_ZAClip,4,123,16,196,verdenab,8,255,255,255,1_ZAon%2520IMDb,4,1,14,196,verdenab,7,255,255,255,1_ZA03%253A28,164,1,14,36,verdenab,7,255,255,255,1_PIimdb-HDIconMiniWhite,BottomLeft,4,-2_ZA%2522House%2520of%2520the%2520Dragon%2522%2520R%252E%252E%252E%2520%2528S2%252EE7%2529,24,138,14,176,arialbd,7,255,255,255,1_.jpg",
      "title": "\"House of the Dragon\" Rises From Ashes of \"Game of Thrones\" Prequels",
      "video": "https://www.imdb.com/video/vi3689725721"
    },
    {
      "id": "vi2046803225",
      "image": "https://m.media-amazon.com/images/M/MV5BZTgxNTgxMjEtODgwYi00MTUzLTk0MTEtOWRhNmI3MTExY2U2XkEyXkFqcGdeQWxpenpp._V1_SP330,330,0,C,0,0,0_CR65,90,200,150_PIimdb-blackband-204-14,TopLeft,0,0_PIimdb-blackband-204-28,BottomLeft,0,1_CR0,0,200,150_PIimdb-bluebutton-big,BottomRight,-1,-1_ZAClip,4,123,16,196,verdenab,8,255,255,255,1_ZAon%2520IMDb,4,1,14,196,verdenab,7,255,255,255,1_ZA03%253A17,164,1,14,36,verdenab,7,255,255,255,1_PIimdb-HDIconMiniWhite,BottomLeft,4,-2_ZAUnaired%2520Game%2520of%2520Thrones%2520Preque%252E%252E%252E,24,138,14,176,arialbd,7,255,255,255,1_.jpg",
      "title": "What We Know About the \"Untitled Game of Thrones Prequel\" ... So Far",
      "video": "https://www.imdb.com/video/vi2046803225"
    },
    {
      "id": "vi1343273497",
      "image": "https://m.media-amazon.com/images/M/MV5BMDcwYTlhYzUtYWIzMC00NTU5LTkwNWEtNzQ3MDQyY2QxNTJmXkEyXkFqcGdeQWFsZWxvZw@@._V1_SP330,330,0,C,0,0,0_CR65,90,200,150_PIimdb-blackband-204-14,TopLeft,0,0_PIimdb-blackband-204-28,BottomLeft,0,1_CR0,0,200,150_PIimdb-bluebutton-big,BottomRight,-1,-1_ZAClip,4,123,16,196,verdenab,8,255,255,255,1_ZAon%2520IMDb,4,1,14,196,verdenab,7,255,255,255,1_ZA02%253A32,164,1,14,36,verdenab,7,255,255,255,1_PIimdb-HDIconMiniWhite,BottomLeft,4,-2_ZAIMDbrief,24,138,14,176,arialbd,7,255,255,255,1_.jpg",
      "title": "Meet the Ladies Leading \"Game of Thrones\" Prequel",
      "video": "https://www.imdb.com/video/vi1343273497"
    },
    {
      "id": "vi1921956377",
      "image": "https://m.media-amazon.com/images/M/MV5BOGYwNWU5MzktODNkYi00YzcyLWE2NDktZjZkYWU0NWMwM2VkXkEyXkFqcGdeQWFsZWxvZw@@._V1_SP330,330,0,C,0,0,0_CR65,90,200,150_PIimdb-blackband-204-14,TopLeft,0,0_PIimdb-blackband-204-28,BottomLeft,0,1_CR0,0,200,150_PIimdb-bluebutton-big,BottomRight,-1,-1_ZAClip,4,123,16,196,verdenab,8,255,255,255,1_ZAon%2520IMDb,4,1,14,196,verdenab,7,255,255,255,1_ZA01%253A49,164,1,14,36,verdenab,7,255,255,255,1_PIimdb-HDIconMiniWhite,BottomLeft,4,-2_ZAIMDbrief,24,138,14,176,arialbd,7,255,255,255,1_.jpg",
      "title": "IMDbrief: Naomi Watts Joins \"Game of Thrones\" Prequel",
      "video": "https://www.imdb.com/video/vi1921956377"
    }
  ],
  "message": "Successful",
  "resultsPerPage": 30,
  "status": true,
  "totalPages": 1,
  "totalResultCount": 4
}



// Sound Track

const sound_track={
  "data": [
    {
      "expandLimit": 6,
      "id": "sn0857273",
      "listContent": [
        {
          "html": "(uncredited)"
        },
        {
          "html": "Written and Performed by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1014697/?ref_=ttsnd\">Ramin Djawadi</a>"
        }
      ],
      "rowTitle": "Main Title",
      "stackedListItem": true
    },
    {
      "expandLimit": 6,
      "id": "sn1864914",
      "listContent": [
        {
          "html": "Performed by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm6855916/?ref_=ttsnd\">SZA</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1070597/?ref_=ttsnd\">The Weeknd</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm6346805/?ref_=ttsnd\">Travis Scott</a>"
        }
      ],
      "rowTitle": "Power is Power",
      "stackedListItem": true
    }
  ],
  "message": "Successful",
  "status": true
}


// Rating

const Rating={
  "data": {
    "entityMetadata": {
      "canHaveEpisodes": true,
      "castPageTitle": {
        "edges": [
          {
            "node": {
              "name": {
                "nameText": {
                  "text": "Peter Dinklage"
                }
              }
            }
          },
          {
            "node": {
              "name": {
                "nameText": {
                  "text": "Lena Headey"
                }
              }
            }
          },
          {
            "node": {
              "name": {
                "nameText": {
                  "text": "Emilia Clarke"
                }
              }
            }
          },
          {
            "node": {
              "name": {
                "nameText": {
                  "text": "Kit Harington"
                }
              }
            }
          }
        ]
      },
      "certificate": {
        "rating": "TV-MA"
      },
      "countriesOfOrigin": {
        "countries": [
          {
            "id": "US"
          }
        ]
      },
      "creatorsPageTitle": [
        {
          "credits": [
            {
              "name": {
                "nameText": {
                  "text": "David Benioff"
                }
              }
            },
            {
              "name": {
                "nameText": {
                  "text": "D.B. Weiss"
                }
              }
            }
          ]
        }
      ],
      "directorsPageTitle": [],
      "id": "tt0944947",
      "meta": {
        "canonicalId": "tt0944947",
        "publicationStatus": "PUBLISHED"
      },
      "originalTitleText": {
        "text": "Game of Thrones"
      },
      "plot": {
        "plotText": {
          "plainText": "Nine noble families fight for control over the lands of Westeros, while an ancient enemy returns after being dormant for a millennia."
        }
      },
      "primaryImage": {
        "caption": {
          "plainText": "Sean Bean in Game of Thrones (2011)"
        },
        "height": 1500,
        "url": "https://m.media-amazon.com/images/M/MV5BN2IzYzBiOTQtNGZmMi00NDI5LTgxMzMtN2EzZjA1NjhlOGMxXkEyXkFqcGdeQXVyNjAwNDUxODI@._V1_.jpg",
        "width": 1000
      },
      "productionStatus": {
        "currentProductionStage": {
          "id": "released"
        },
        "restriction": null
      },
      "ratingsSummary": {
        "aggregateRating": 9.2
      },
      "releaseYear": {
        "endYear": 2019,
        "year": 2011
      },
      "runtime": {
        "seconds": 3420
      },
      "series": null,
      "subNavCredits": {
        "total": 8404
      },
      "subNavReviews": {
        "total": 5688
      },
      "subNavTrivia": {
        "total": 209
      },
      "titleGenres": {
        "genres": [
          {
            "genre": {
              "text": "Action"
            }
          },
          {
            "genre": {
              "text": "Adventure"
            }
          },
          {
            "genre": {
              "text": "Drama"
            }
          }
        ]
      },
      "titleText": {
        "text": "Game of Thrones"
      },
      "titleType": {
        "canHaveEpisodes": true,
        "id": "tvSeries",
        "isEpisode": false,
        "isSeries": true,
        "text": "TV Series"
      }
    },
    "heatmapData": {
      "episodeData": [
        {
          "data": [
            {
              "cursor": "dHQxNDgwMDU1",
              "id": "tt1480055",
              "rating": 8.9
            },
            {
              "cursor": "dHQxNjY4NzQ2",
              "id": "tt1668746",
              "rating": 8.6
            },
            {
              "cursor": "dHQxODI5OTYy",
              "id": "tt1829962",
              "rating": 8.5
            },
            {
              "cursor": "dHQxODI5OTYz",
              "id": "tt1829963",
              "rating": 8.6
            },
            {
              "cursor": "dHQxODI5OTY0",
              "id": "tt1829964",
              "rating": 9
            },
            {
              "cursor": "dHQxODM3ODYy",
              "id": "tt1837862",
              "rating": 9.1
            },
            {
              "cursor": "dHQxODM3ODYz",
              "id": "tt1837863",
              "rating": 9.1
            },
            {
              "cursor": "dHQxODM3ODY0",
              "id": "tt1837864",
              "rating": 8.9
            },
            {
              "cursor": "dHQxODUxMzk4",
              "id": "tt1851398",
              "rating": 9.6
            },
            {
              "cursor": "dHQxODUxMzk3",
              "id": "tt1851397",
              "rating": 9.4
            }
          ],
          "endCursor": "dHQxODUxMzk3",
          "episodeCount": 10
        },
        {
          "data": [
            {
              "cursor": "dHQxOTcxODMz",
              "id": "tt1971833",
              "rating": 8.6
            },
            {
              "cursor": "dHQyMDY5MzE4",
              "id": "tt2069318",
              "rating": 8.4
            },
            {
              "cursor": "dHQyMDcwMTM1",
              "id": "tt2070135",
              "rating": 8.7
            },
            {
              "cursor": "dHQyMDY5MzE5",
              "id": "tt2069319",
              "rating": 8.6
            },
            {
              "cursor": "dHQyMDc0NjU4",
              "id": "tt2074658",
              "rating": 8.6
            },
            {
              "cursor": "dHQyMDg1MjM4",
              "id": "tt2085238",
              "rating": 8.9
            },
            {
              "cursor": "dHQyMDg1MjM5",
              "id": "tt2085239",
              "rating": 8.8
            },
            {
              "cursor": "dHQyMDg1MjQw",
              "id": "tt2085240",
              "rating": 8.6
            },
            {
              "cursor": "dHQyMDg0MzQy",
              "id": "tt2084342",
              "rating": 9.7
            },
            {
              "cursor": "dHQyMTEyNTEw",
              "id": "tt2112510",
              "rating": 9.3
            }
          ],
          "endCursor": "dHQyMTEyNTEw",
          "episodeCount": 10
        },
        {
          "data": [
            {
              "cursor": "dHQyMTc4Nzgy",
              "id": "tt2178782",
              "rating": 8.6
            },
            {
              "cursor": "dHQyMTc4Nzcy",
              "id": "tt2178772",
              "rating": 8.5
            },
            {
              "cursor": "dHQyMTc4ODAy",
              "id": "tt2178802",
              "rating": 8.7
            },
            {
              "cursor": "dHQyMTc4Nzk4",
              "id": "tt2178798",
              "rating": 9.5
            },
            {
              "cursor": "dHQyMTc4Nzg4",
              "id": "tt2178788",
              "rating": 8.9
            },
            {
              "cursor": "dHQyMTc4ODEy",
              "id": "tt2178812",
              "rating": 8.7
            },
            {
              "cursor": "dHQyMTc4ODE0",
              "id": "tt2178814",
              "rating": 8.6
            },
            {
              "cursor": "dHQyMTc4ODA2",
              "id": "tt2178806",
              "rating": 8.9
            },
            {
              "cursor": "dHQyMTc4Nzg0",
              "id": "tt2178784",
              "rating": 9.9
            },
            {
              "cursor": "dHQyMTc4Nzk2",
              "id": "tt2178796",
              "rating": 9.1
            }
          ],
          "endCursor": "dHQyMTc4Nzk2",
          "episodeCount": 10
        },
        {
          "data": [
            {
              "cursor": "dHQyODE2MTM2",
              "id": "tt2816136",
              "rating": 9
            },
            {
              "cursor": "dHQyODMyMzc4",
              "id": "tt2832378",
              "rating": 9.7
            },
            {
              "cursor": "dHQyOTcyNDI2",
              "id": "tt2972426",
              "rating": 8.7
            },
            {
              "cursor": "dHQyOTcyNDI4",
              "id": "tt2972428",
              "rating": 8.7
            },
            {
              "cursor": "dHQzMDYwODU2",
              "id": "tt3060856",
              "rating": 8.6
            },
            {
              "cursor": "dHQzMDYwOTEw",
              "id": "tt3060910",
              "rating": 9.7
            },
            {
              "cursor": "dHQzMDYwODc2",
              "id": "tt3060876",
              "rating": 9
            },
            {
              "cursor": "dHQzMDYwNzgy",
              "id": "tt3060782",
              "rating": 9.7
            },
            {
              "cursor": "dHQzMDYwODU4",
              "id": "tt3060858",
              "rating": 9.6
            },
            {
              "cursor": "dHQzMDYwODYw",
              "id": "tt3060860",
              "rating": 9.6
            }
          ],
          "endCursor": "dHQzMDYwODYw",
          "episodeCount": 10
        },
        {
          "data": [
            {
              "cursor": "dHQzNjU4MDEy",
              "id": "tt3658012",
              "rating": 8.3
            },
            {
              "cursor": "dHQzODQ2NjI2",
              "id": "tt3846626",
              "rating": 8.3
            },
            {
              "cursor": "dHQzODY2ODM2",
              "id": "tt3866836",
              "rating": 8.4
            },
            {
              "cursor": "dHQzODY2ODM4",
              "id": "tt3866838",
              "rating": 8.5
            },
            {
              "cursor": "dHQzODY2ODQw",
              "id": "tt3866840",
              "rating": 8.5
            },
            {
              "cursor": "dHQzODY2ODQy",
              "id": "tt3866842",
              "rating": 7.9
            },
            {
              "cursor": "dHQzODY2ODQ2",
              "id": "tt3866846",
              "rating": 8.8
            },
            {
              "cursor": "dHQzODY2ODUw",
              "id": "tt3866850",
              "rating": 9.8
            },
            {
              "cursor": "dHQzODY2ODI2",
              "id": "tt3866826",
              "rating": 9.4
            },
            {
              "cursor": "dHQzODY2ODYy",
              "id": "tt3866862",
              "rating": 9.1
            }
          ],
          "endCursor": "dHQzODY2ODYy",
          "episodeCount": 10
        },
        {
          "data": [
            {
              "cursor": "dHQzNjU4MDE0",
              "id": "tt3658014",
              "rating": 8.4
            },
            {
              "cursor": "dHQ0MDc3NTU0",
              "id": "tt4077554",
              "rating": 9.3
            },
            {
              "cursor": "dHQ0MTMxNjA2",
              "id": "tt4131606",
              "rating": 8.6
            },
            {
              "cursor": "dHQ0MjgzMDE2",
              "id": "tt4283016",
              "rating": 9
            },
            {
              "cursor": "dHQ0MjgzMDI4",
              "id": "tt4283028",
              "rating": 9.7
            },
            {
              "cursor": "dHQ0MjgzMDU0",
              "id": "tt4283054",
              "rating": 8.3
            },
            {
              "cursor": "dHQ0MjgzMDYw",
              "id": "tt4283060",
              "rating": 8.5
            },
            {
              "cursor": "dHQ0MjgzMDc0",
              "id": "tt4283074",
              "rating": 8.3
            },
            {
              "cursor": "dHQ0MjgzMDg4",
              "id": "tt4283088",
              "rating": 9.9
            },
            {
              "cursor": "dHQ0MjgzMDk0",
              "id": "tt4283094",
              "rating": 9.9
            }
          ],
          "endCursor": "dHQ0MjgzMDk0",
          "episodeCount": 10
        },
        {
          "data": [
            {
              "cursor": "dHQ1NjU0MDg4",
              "id": "tt5654088",
              "rating": 8.5
            },
            {
              "cursor": "dHQ1NjU1MTc4",
              "id": "tt5655178",
              "rating": 8.8
            },
            {
              "cursor": "dHQ1Nzc1ODQw",
              "id": "tt5775840",
              "rating": 9.1
            },
            {
              "cursor": "dHQ1Nzc1ODQ2",
              "id": "tt5775846",
              "rating": 9.7
            },
            {
              "cursor": "dHQ1Nzc1ODU0",
              "id": "tt5775854",
              "rating": 8.7
            },
            {
              "cursor": "dHQ1Nzc1ODY0",
              "id": "tt5775864",
              "rating": 9
            },
            {
              "cursor": "dHQ1Nzc1ODc0",
              "id": "tt5775874",
              "rating": 9.4
            }
          ],
          "endCursor": "dHQ1Nzc1ODc0",
          "episodeCount": 7
        },
        {
          "data": [
            {
              "cursor": "dHQ1OTI0MzY2",
              "id": "tt5924366",
              "rating": 7.6
            },
            {
              "cursor": "dHQ2MDI3OTA4",
              "id": "tt6027908",
              "rating": 7.9
            },
            {
              "cursor": "dHQ2MDI3OTEy",
              "id": "tt6027912",
              "rating": 7.5
            },
            {
              "cursor": "dHQ2MDI3OTE0",
              "id": "tt6027914",
              "rating": 5.5
            },
            {
              "cursor": "dHQ2MDI3OTE2",
              "id": "tt6027916",
              "rating": 6
            },
            {
              "cursor": "dHQ2MDI3OTIw",
              "id": "tt6027920",
              "rating": 4
            }
          ],
          "endCursor": "dHQ2MDI3OTIw",
          "episodeCount": 6
        }
      ],
      "seasonData": {
        "cursor": "",
        "missedInitialSeasons": {}
      },
      "seasons": 8,
      "totalEpisodes": 73
    },
    "histogramData": {
      "aggregateRating": 9.2,
      "countryData": [
        {
          "aggregateRating": 9.2,
          "countryCode": "US",
          "displayText": "United States",
          "totalVoteCount": 431925
        },
        {
          "aggregateRating": 9.2,
          "countryCode": "GB",
          "displayText": "United Kingdom",
          "totalVoteCount": 186983
        },
        {
          "aggregateRating": 9.4,
          "countryCode": "IN",
          "displayText": "India",
          "totalVoteCount": 98060
        },
        {
          "aggregateRating": 9.1,
          "countryCode": "TR",
          "displayText": "Turkey",
          "totalVoteCount": 88163
        },
        {
          "aggregateRating": 9.2,
          "countryCode": "DE",
          "displayText": "Germany",
          "totalVoteCount": 65488
        }
      ],
      "histogramValues": [
        {
          "formattedVoteCount": "68K",
          "rating": 1,
          "voteCount": 67544
        },
        {
          "formattedVoteCount": "7.5K",
          "rating": 2,
          "voteCount": 7498
        },
        {
          "formattedVoteCount": "8.4K",
          "rating": 3,
          "voteCount": 8350
        },
        {
          "formattedVoteCount": "9.9K",
          "rating": 4,
          "voteCount": 9871
        },
        {
          "formattedVoteCount": "20K",
          "rating": 5,
          "voteCount": 19510
        },
        {
          "formattedVoteCount": "32K",
          "rating": 6,
          "voteCount": 32280
        },
        {
          "formattedVoteCount": "83K",
          "rating": 7,
          "voteCount": 83048
        },
        {
          "formattedVoteCount": "210K",
          "rating": 8,
          "voteCount": 210240
        },
        {
          "formattedVoteCount": "483K",
          "rating": 9,
          "voteCount": 482669
        },
        {
          "formattedVoteCount": "1.3M",
          "rating": 10,
          "voteCount": 1264740
        }
      ],
      "titleId": "tt0944947",
      "totalVoteCount": 2185750
    },
    "isRatable": true,
    "parentDisplayText": "Game of Thrones",
    "posterData": {
      "constId": "tt0944947",
      "image": {
        "caption": "Game of Thrones",
        "maxHeight": 1500,
        "maxWidth": 1000,
        "url": "https://m.media-amazon.com/images/M/MV5BN2IzYzBiOTQtNGZmMi00NDI5LTgxMzMtN2EzZjA1NjhlOGMxXkEyXkFqcGdeQXVyNjAwNDUxODI@._V1_.jpg"
      },
      "type": "tvSeries"
    },
    "sidebarProps": {
      "titleSidebarProps": {
        "countriesOfOrigin": {
          "__typename": "CountriesOfOrigin",
          "countries": [
            {
              "__typename": "CountryOfOrigin",
              "id": "US"
            }
          ]
        },
        "productionStatus": {
          "__typename": "ProductionStatusDetails",
          "currentProductionStage": {
            "__typename": "ProductionStage",
            "id": "released"
          },
          "restriction": null
        }
      }
    },
    "titleText": "Game of Thrones"
  },
  "message": "Successful",
  "status": true
}

// Techincal Staff
const OtherCAst={
  "data": [
    {
      "id": "runtime",
      "listContent": [
        {
          "id": 1,
          "subText": "",
          "text": "57m"
        }
      ],
      "rowTitle": "Runtime"
    },
    {
      "id": "soundmixes",
      "listContent": [
        {
          "href": "/search/title/?sound_mixes=dolby_digital&ref_=ttspec_spec_2",
          "text": "Dolby Digital"
        },
        {
          "href": "/search/title/?sound_mixes=dolby_atmos&ref_=ttspec_spec_2",
          "subText": "(Blu-ray release)",
          "text": "Dolby Atmos"
        }
      ],
      "rowTitle": "Sound mix"
    },
    {
      "id": "colorations",
      "listContent": [
        {
          "href": "/search/title/?colors=color&ref_=ttspec_spec_3",
          "text": "Color"
        }
      ],
      "rowTitle": "Color"
    },
    {
      "id": "aspectratio",
      "listContent": [
        {
          "text": "1.78 : 1"
        }
      ],
      "rowTitle": "Aspect ratio"
    },
    {
      "id": "cameras",
      "listContent": [
        {
          "subText": "(season 8)",
          "text": "Arri Alexa Mini, Cooke S4/i and Hawk V-Series Lenses"
        },
        {
          "subText": "(season 8)",
          "text": "Arri Alexa SXT Plus, Cooke S4/i, Hawk V-Series and Angenieux Optimo Lenses"
        },
        {
          "subText": "(Season 3 & 4)",
          "text": "Arri Alexa Studio, Cooke S4 and Angenieux Optimo Lenses"
        },
        {
          "subText": "(Season 5 & 6)",
          "text": "Arri Alexa XT, Cooke S4 and Angenieux Optimo Lenses"
        },
        {
          "subText": "(Season 1 -2)",
          "text": "Arri Alexa, Cooke S4 and Angenieux Optimo Lenses"
        },
        {
          "text": "Red Epic Dragon"
        }
      ],
      "rowTitle": "Camera"
    },
    {
      "id": "negativeFormat",
      "listContent": [
        {
          "text": "Digital"
        }
      ],
      "rowTitle": "Negative Format"
    },
    {
      "id": "process",
      "listContent": [
        {
          "subText": "(season2-)",
          "text": "Codex"
        },
        {
          "subText": "(master format)",
          "text": "Digital Intermediate (2K)"
        },
        {
          "text": "Dolby Vision"
        },
        {
          "subText": "(season 1)",
          "text": "HDCAM SR"
        },
        {
          "text": "HDR10"
        },
        {
          "subText": "(anamorphic, season 8, source format, some scenes)",
          "text": "Hawk Scope"
        },
        {
          "subText": "(season 2-)",
          "text": "ProRes"
        },
        {
          "subText": "(some shots, Season 5-)",
          "text": "Redcode RAW"
        }
      ],
      "rowTitle": "Cinematographic Process"
    },
    {
      "id": "printedFormat",
      "listContent": [
        {
          "subText": "(HDTV)",
          "text": "Digital"
        },
        {
          "subText": "(UHD Blu-ray and HBO Max release)",
          "text": "Dolby Vision"
        },
        {
          "subText": "(UHD Blu-ray and HBO Max release)",
          "text": "UHDTV"
        }
      ],
      "rowTitle": "Printed Film Format"
    }
  ],
  "message": "Successful",
  "status": true
}


// Top Cast

const Actor={
  "data": [
    {
      "id": "nm0185819",
      "name": "Daniel Craig"
    },
    {
      "id": "nm0910607",
      "name": "Christoph Waltz"
    },
    {
      "id": "nm2244205",
      "name": "Léa Seydoux"
    },
    {
      "id": "nm0000146",
      "name": "Ralph Fiennes"
    },
    {
      "id": "nm0000899",
      "name": "Monica Bellucci"
    },
    {
      "id": "nm0924210",
      "name": "Ben Whishaw"
    },
    {
      "id": "nm0365140",
      "name": "Naomie Harris"
    },
    {
      "id": "nm1176985",
      "name": "Dave Bautista"
    },
    {
      "id": "nm0778831",
      "name": "Andrew Scott"
    },
    {
      "id": "nm1239499",
      "name": "Rory Kinnear"
    },
    {
      "id": "nm0159802",
      "name": "Jesper Christensen"
    },
    {
      "id": "nm0187361",
      "name": "Alessandro Cremona"
    },
    {
      "id": "nm2362713",
      "name": "Stephanie Sigman"
    },
    {
      "id": "nm2204178",
      "name": "Tenoch Huerta"
    },
    {
      "id": "nm2578315",
      "name": "Adriana Paz"
    },
    {
      "id": "nm0287398",
      "name": "Domenico Fortunato"
    },
    {
      "id": "nm2940827",
      "name": "Marco Zingaro"
    },
    {
      "id": "nm7469129",
      "name": "Stefano Elfi DiClaudia"
    },
    {
      "id": "nm1947068",
      "name": "Ian Bonar"
    },
    {
      "id": "nm0931767",
      "name": "Tam Williams"
    },
    {
      "id": "nm1483883",
      "name": "Richard Banham"
    },
    {
      "id": "nm2553988",
      "name": "Pip Carter"
    },
    {
      "id": "nm0501676",
      "name": "Simon Lenagan"
    },
    {
      "id": "nm0107792",
      "name": "Alessandro Bressanello"
    },
    {
      "id": "nm3207271",
      "name": "Marc Zinga"
    },
    {
      "id": "nm2692312",
      "name": "Brigitte Millar"
    },
    {
      "id": "nm1513288",
      "name": "Adel Bencherif"
    },
    {
      "id": "nm2203695",
      "name": "Gediminas Adomaitis"
    },
    {
      "id": "nm0487333",
      "name": "Peppe Lanzetta"
    },
    {
      "id": "nm2318119",
      "name": "Francesco Arca"
    },
    {
      "id": "nm1142860",
      "name": "Matteo Taranto"
    },
    {
      "id": "nm6197272",
      "name": "Emilio Aniba"
    },
    {
      "id": "nm0756237",
      "name": "Benito Sagredo"
    },
    {
      "id": "nm1859839",
      "name": "Dai Tabuchi"
    },
    {
      "id": "nm0645714",
      "name": "George Lasha"
    },
    {
      "id": "nm2590784",
      "name": "Sargon Yelda"
    },
    {
      "id": "nm3338257",
      "name": "Andy Cheung"
    },
    {
      "id": "nm3689362",
      "name": "Erick Hayden"
    },
    {
      "id": "nm1360310",
      "name": "Oleg Mirochnikov"
    },
    {
      "id": "nm0758400",
      "name": "Antonio Salines"
    },
    {
      "id": "nm6221923",
      "name": "Miloud Mourad Benamara"
    },
    {
      "id": "nm3694640",
      "name": "Gido Schimanski"
    },
    {
      "id": "nm0053443",
      "name": "Nigel Barber"
    },
    {
      "id": "nm0619628",
      "name": "Patrice Naiambana"
    },
    {
      "id": "nm0180388",
      "name": "Stephane Cornicard"
    },
    {
      "id": "nm0266815",
      "name": "Gary Fannin"
    },
    {
      "id": "nm2692900",
      "name": "Sadao Ueda"
    },
    {
      "id": "nm5529172",
      "name": "Phillip Law"
    },
    {
      "id": "nm2647349",
      "name": "Wai Wong"
    },
    {
      "id": "nm1692732",
      "name": "Joseph Balderrama"
    },
    {
      "id": "nm4110185",
      "name": "Eiji Mihara"
    },
    {
      "id": "nm2554701",
      "name": "Junichi Kajioka"
    },
    {
      "id": "nm0770526",
      "name": "Victor Schefé"
    },
    {
      "id": "nm0934731",
      "name": "Harald Windisch"
    },
    {
      "id": "nm1276598",
      "name": "Tristan Matthiae"
    },
    {
      "id": "nm0098524",
      "name": "Detlef Bothe"
    },
    {
      "id": "nm4411152",
      "name": "Bodo Friesecke"
    },
    {
      "id": "nm2282618",
      "name": "Wilhelm Iben"
    },
    {
      "id": "nm4964847",
      "name": "Noemi Krausz"
    },
    {
      "id": "nm5995132",
      "name": "Noah Saavedra"
    },
    {
      "id": "nm2223384",
      "name": "Francis Attakpah"
    },
    {
      "id": "nm5123552",
      "name": "Michael Glantschnig"
    },
    {
      "id": "nm5665325",
      "name": "Marlon Boess"
    },
    {
      "id": "nm2709898",
      "name": "Marie Fee Wohlmuth"
    },
    {
      "id": "nm5505944",
      "name": "Lili Epply"
    },
    {
      "id": "nm5671519",
      "name": "Konstantin Gerlach"
    },
    {
      "id": "nm1871255",
      "name": "Lara Parmiani"
    },
    {
      "id": "nm3203072",
      "name": "Umit Ulgen"
    },
    {
      "id": "nm4107140",
      "name": "Amra Mallassi"
    },
    {
      "id": "nm4213457",
      "name": "Ziad Abaza"
    },
    {
      "id": "nm7695785",
      "name": "Walid Mumuni"
    },
    {
      "id": "nm2471942",
      "name": "Derek Horsham"
    },
    {
      "id": "nm3335517",
      "name": "Nari Blair-Mangat"
    },
    {
      "id": "nm7695786",
      "name": "Michael White"
    },
    {
      "id": "nm4531508",
      "name": "Adam McGrady"
    },
    {
      "id": "nm5883384",
      "name": "Nader Dernaika"
    },
    {
      "id": "nm3329852",
      "name": "Pezh Maan"
    },
    {
      "id": "nm7429290",
      "name": "Nad Abdoolakhan"
    },
    {
      "id": "nm8421090",
      "name": "Charlie Akin"
    },
    {
      "id": "nm2158357",
      "name": "Adil Akram"
    },
    {
      "id": "nm5359185",
      "name": "Alister Albert"
    },
    {
      "id": "nm2506300",
      "name": "Lasco Atkins"
    },
    {
      "id": "nm1057873",
      "name": "Omar Ayala"
    },
    {
      "id": "nm6454657",
      "name": "David Olawale Ayinde"
    },
    {
      "id": "nm7424573",
      "name": "Mohan Banerji"
    },
    {
      "id": "nm2737377",
      "name": "Steve Barnett"
    },
    {
      "id": "nm6580238",
      "name": "Mark Baxter"
    },
    {
      "id": "nm15057321",
      "name": "Mark Beautement"
    },
    {
      "id": "nm0085944",
      "name": "Paul Blackwell"
    },
    {
      "id": "nm6333736",
      "name": "Gerardo Bosco"
    },
    {
      "id": "nm7954852",
      "name": "Tom Bourlet"
    },
    {
      "id": "nm10973728",
      "name": "Lorenzo Brambilla"
    },
    {
      "id": "nm7141912",
      "name": "Matthew Brandon"
    },
    {
      "id": "nm14527752",
      "name": "Jennifer Brenner"
    },
    {
      "id": "nm6573215",
      "name": "Harry Brewis"
    },
    {
      "id": "nm4756154",
      "name": "Dante Briggins"
    },
    {
      "id": "nm5725422",
      "name": "Jill Buchanan"
    },
    {
      "id": "nm2025778",
      "name": "Oliver Cantú Lozano"
    },
    {
      "id": "nm9191742",
      "name": "Calvin Chen"
    },
    {
      "id": "nm7631833",
      "name": "Mahmud Chowdhury"
    },
    {
      "id": "nm3178863",
      "name": "Eric Coco"
    },
    {
      "id": "nm6584210",
      "name": "Maurisa Selene Coleman"
    },
    {
      "id": "nm0171625",
      "name": "Bern Collaço"
    },
    {
      "id": "nm6536316",
      "name": "Fabio Colonna"
    },
    {
      "id": "nm4827698",
      "name": "Christopher DeGress"
    },
    {
      "id": "nm6254576",
      "name": "Alan Del Castillo"
    },
    {
      "id": "nm0001132",
      "name": "Judi Dench"
    },
    {
      "id": "nm5687164",
      "name": "Leigh Dent"
    },
    {
      "id": "nm9554435",
      "name": "Alessio Di Silvestro"
    },
    {
      "id": "nm6219361",
      "name": "Filip Dordievski"
    },
    {
      "id": "nm7564685",
      "name": "Steve Doyle"
    },
    {
      "id": "nm7303783",
      "name": "Daniel Eghan"
    },
    {
      "id": "nm6280542",
      "name": "Leila Elbahy"
    },
    {
      "id": "nm8568535",
      "name": "Marc Esse"
    },
    {
      "id": "nm7066645",
      "name": "Karl Farrer"
    },
    {
      "id": "nm7871215",
      "name": "Lucy Figueroa"
    },
    {
      "id": "nm5513531",
      "name": "Neve Gachev"
    },
    {
      "id": "nm6711707",
      "name": "Gloria Garcia"
    },
    {
      "id": "nm5927785",
      "name": "David Georgiou"
    },
    {
      "id": "nm3079422",
      "name": "Dennis Good"
    },
    {
      "id": "nm4096805",
      "name": "Tim Hammersley"
    },
    {
      "id": "nm3946724",
      "name": "Sam Hanover"
    },
    {
      "id": "nm3679391",
      "name": "Bunmi Hazzan"
    },
    {
      "id": "nm6221752",
      "name": "David Howkins"
    },
    {
      "id": "nm8375403",
      "name": "Daniel Jones"
    },
    {
      "id": "nm6613137",
      "name": "Justified"
    },
    {
      "id": "nm2841197",
      "name": "Samantha Kelly"
    },
    {
      "id": "nm7255532",
      "name": "Attila G. Kerekes"
    },
    {
      "id": "nm3977056",
      "name": "Kaveh Khatiri"
    },
    {
      "id": "nm2876028",
      "name": "Darryl Lane"
    },
    {
      "id": "nm5855226",
      "name": "Jorge Leon"
    },
    {
      "id": "nm7258972",
      "name": "Rogers Leona"
    },
    {
      "id": "nm8421573",
      "name": "Volenté Lloyd"
    },
    {
      "id": "nm5626018",
      "name": "Tyrone Love"
    },
    {
      "id": "nm3642063",
      "name": "Shaun Lucas"
    },
    {
      "id": "nm3250640",
      "name": "Johnny Lynch"
    },
    {
      "id": "nm5339661",
      "name": "Sid Man"
    },
    {
      "id": "nm6378175",
      "name": "Joanne Manchester"
    },
    {
      "id": "nm1974519",
      "name": "Gary Mancini"
    },
    {
      "id": "nm4214626",
      "name": "Sergio Mariano"
    },
    {
      "id": "nm2927778",
      "name": "Garry Marriott"
    },
    {
      "id": "nm6764710",
      "name": "Christopher Michael J. Marsh"
    },
    {
      "id": "nm5044207",
      "name": "Nicholas Marshall"
    },
    {
      "id": "nm3435231",
      "name": "Alex Martin"
    },
    {
      "id": "nm5020928",
      "name": "Martyn Mayger"
    },
    {
      "id": "nm4430776",
      "name": "Pete Meads"
    },
    {
      "id": "nm8137631",
      "name": "Bradley Wj Miller"
    },
    {
      "id": "nm4255398",
      "name": "Keith Milner"
    },
    {
      "id": "nm6018008",
      "name": "Haaris Mirza"
    },
    {
      "id": "nm8074647",
      "name": "Sandeep Mohan"
    },
    {
      "id": "nm5916370",
      "name": "Matija Matovic Mondi"
    },
    {
      "id": "nm5032801",
      "name": "Martín Montellano"
    },
    {
      "id": "nm8110039",
      "name": "Stefania Montesolaro"
    },
    {
      "id": "nm7419291",
      "name": "Arnold Montey"
    },
    {
      "id": "nm6484472",
      "name": "James M.L. Muller"
    },
    {
      "id": "nm4069122",
      "name": "Benjayx Murphy"
    },
    {
      "id": "nm2124465",
      "name": "Taylor Murphy"
    },
    {
      "id": "nm8229619",
      "name": "Mahel Nahim"
    },
    {
      "id": "nm5126893",
      "name": "Kumud Pant"
    },
    {
      "id": "nm8579037",
      "name": "Ashish Patel"
    },
    {
      "id": "nm11694988",
      "name": "Richard Pearce"
    },
    {
      "id": "nm6595037",
      "name": "Mac Pietowski"
    },
    {
      "id": "nm5995060",
      "name": "Mike Ray"
    },
    {
      "id": "nm9864534",
      "name": "Graham j Reeves"
    },
    {
      "id": "nm3230361",
      "name": "Michael Riedacher"
    },
    {
      "id": "nm13271779",
      "name": "Angel Rossell"
    },
    {
      "id": "nm3776673",
      "name": "Vuksan Rovcanin"
    },
    {
      "id": "nm10921073",
      "name": "Maurice Sardison"
    },
    {
      "id": "nm9663721",
      "name": "Jason Saunders"
    },
    {
      "id": "nm6047482",
      "name": "Linus Scheithauer"
    },
    {
      "id": "nm9026499",
      "name": "Rashid Shadat"
    },
    {
      "id": "nm6437865",
      "name": "Lady Conny Sharples"
    },
    {
      "id": "nm8976535",
      "name": "Stuart Shepherd-Garner"
    },
    {
      "id": "nm5630547",
      "name": "Sam Shoubber"
    },
    {
      "id": "nm3167170",
      "name": "Weiwei Si"
    },
    {
      "id": "nm3149501",
      "name": "Ernesto Siller"
    },
    {
      "id": "nm7250657",
      "name": "Toshi Sinha"
    },
    {
      "id": "nm8421086",
      "name": "Gerard Smith"
    },
    {
      "id": "nm6680316",
      "name": "Clem So"
    },
    {
      "id": "nm6203418",
      "name": "Daran Somers"
    },
    {
      "id": "nm1713109",
      "name": "Adrian South"
    },
    {
      "id": "nm2491463",
      "name": "Karol Steele"
    },
    {
      "id": "nm4571421",
      "name": "Daniel Stisen"
    },
    {
      "id": "nm6483912",
      "name": "Ellen Claire Sutherland"
    },
    {
      "id": "nm6897145",
      "name": "Phil Tillott"
    },
    {
      "id": "nm10009142",
      "name": "Winson Ting"
    },
    {
      "id": "nm1949559",
      "name": "Chuen Tsou"
    },
    {
      "id": "nm5018678",
      "name": "Romeo Visca"
    },
    {
      "id": "nm0923001",
      "name": "Paul Weston"
    },
    {
      "id": "nm6620079",
      "name": "Daniel Westwood"
    },
    {
      "id": "nm2711324",
      "name": "Chris Wilson"
    },
    {
      "id": "nm1921196",
      "name": "Gregg Wilson"
    },
    {
      "id": "nm0933865",
      "name": "Michael G. Wilson"
    },
    {
      "id": "nm7780072",
      "name": "Danielle Yen"
    },
    {
      "id": "nm6520637",
      "name": "Miroslav Zaruba"
    },
    {
      "id": "nm7463501",
      "name": "Ruolan Zhang"
    },
    {
      "id": "nm5244682",
      "name": "Dominic Zwemmer"
    },
    {
      "id": "nm7111555",
      "name": "Julio César Álvarez"
    }
  ],
  "message": "Successful",
  "status": true
}


// News

const news={
  "data": [
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64177580/?ref_=ttnw_art_plk",
          "id": "permalink-ni64177580",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64177580&ref_=ttnw_art_rpt",
          "id": "report-ni64177580",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/30/2023"
        },
        {
          "text": "by Nischal Niraula"
        },
        {
          "href": "https://collider.com/game-of-thrones-lady-stoneheart/",
          "text": "Collider.com",
          "type": "external"
        }
      ],
      "cardHtml": "Given the sheer vastness of the source it was adapted from, there is no way <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> could depict every written story and character in the show. The author of the book, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R. R. Martin</a> has said as much, claiming that it would require at least 13 seasons if the series were to remain a faithful adaptation. Indeed, it was inevitable that certain elements of the story would get sacrificed to appeal to the new medium. And still, none of these cutoffs sting as much as the decision to remove Lady Stoneheart from the show. The very introduction of this character has inspired one of the most powerful moments in the books, and given the uniqueness of her very existence, she remains one of the most fascinating figures in all of Westeros.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://collider.com/game-of-thrones-lady-stoneheart/\">See full article at Collider.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BNmU0YmZjZGUtMWExZS00MGM0LWFkMTctZWJkM2JkNmM4MWYwXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "‘Game of Thrones’ Left Out This Vital Book Character",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://collider.com/game-of-thrones-lady-stoneheart/",
      "id": "ni64177580",
      "sourceName": "Collider.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64177533/?ref_=ttnw_art_plk",
          "id": "permalink-ni64177533",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64177533&ref_=ttnw_art_rpt",
          "id": "report-ni64177533",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Joe Roberts"
        },
        {
          "href": "https://www.slashfilm.com/1339748/rob-mcelhenney-was-pranked-by-game-of-thrones-showrunners/",
          "text": "Slash Film",
          "type": "external"
        }
      ],
      "cardHtml": "These days, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0568390/\">Rob McElhenney</a> seems to spend a large chunk of his time running a Welsh football club and hanging out with <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0005351/\">Ryan Reynolds</a>. But he&#39;s also somehow found time to keep the show he co-created, &quot;<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0472954/\">It&#39;s Always Sunny In Philadelphia</a>,&quot; running into what is now its 16th season.<br/><br/>The show already broke a record with its 15th season, becoming the longest-running live-action comedy series in American TV history, overtaking &quot;<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0044230/\">The Adventures of Ozzie and Harriet</a>&quot; to claim the top spot. For a show about a gang of degenerate yet lovable sociopaths, that&#39;s quite an achievement, especially considering it almost went off the air after its first season, before McElhenny and his cast agreed to add some special sauce in the form of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000362/\">Danny DeVito</a>. It&#39;s also impressive considering &quot;<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0472954/\">It&#39;s Always Sunny</a>&quot; managed to beat out other shows and claim the record for the wordiest show on television, reportedly delivering...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.slashfilm.com/1339748/rob-mcelhenney-was-pranked-by-game-of-thrones-showrunners/\">See full article at Slash Film<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 438,
        "maxWidth": 780,
        "url": "https://m.media-amazon.com/images/M/MV5BNjc5MzNiZDctMzNjNi00ZDBiLWJjNDktMjA1MjI5ZTIxMjk4XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "The Time It's Always Sunny's Rob McElhenney Was Pranked By The Game Of Thrones Showrunners",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.slashfilm.com/1339748/rob-mcelhenney-was-pranked-by-game-of-thrones-showrunners/",
      "id": "ni64177533",
      "sourceName": "Slash Film"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64177509/?ref_=ttnw_art_plk",
          "id": "permalink-ni64177509",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64177509&ref_=ttnw_art_rpt",
          "id": "report-ni64177509",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Ava Lombardi"
        },
        {
          "href": "https://uinterview.com/news/george-r-r-martin-says-game-of-thrones-spinoff-deal-with-hbo-has-been-suspended-due-to-strike/",
          "text": "Uinterview",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R.R. Martin</a>, the mastermind behind <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> and House of Dragons, announced that his 2021 deal with HBO was suspended on June 1.<br/><br/>Martin signed with HBO to develop several <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> spinoffs. However, he has put that on hold in light of the Hollywood strikes that are currently taking place, in which actors and writers are seeking equitable pay for the entire production team.<br/><br/>Martin and HBO are not the first to halt production amid the protests. Amazon, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0026840/\">Warner Bros.</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0045277/\">Discovery Channel</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0195910/\">NBCUniversal</a>, Disney and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0007821/\">CBS Studios</a> have all announced their suspension of first-look and overall deals.<br/><br/>“I still have plenty to do, of course. In that, I am one of the lucky ones,” wrote Martin in a social media post. “These strikes are not really about name writers or producers or showrunners, most of whom are fine; we’re striking for the entry-level writers, the story editors,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://uinterview.com/news/george-r-r-martin-says-game-of-thrones-spinoff-deal-with-hbo-has-been-suspended-due-to-strike/\">See full article at Uinterview<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 500,
        "maxWidth": 690,
        "url": "https://m.media-amazon.com/images/M/MV5BOTFlZmVjNGUtZWZhYS00ZTE4LWIwMjYtZTAzM2U3NjFmNWI5XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "George R.R. Martin Says ‘Game Of Thrones’ Spinoff Deal With HBO Has Been Suspended Due To Strike",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://uinterview.com/news/george-r-r-martin-says-game-of-thrones-spinoff-deal-with-hbo-has-been-suspended-due-to-strike/",
      "id": "ni64177509",
      "sourceName": "Uinterview"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64177433/?ref_=ttnw_art_plk",
          "id": "permalink-ni64177433",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64177433&ref_=ttnw_art_rpt",
          "id": "report-ni64177433",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Smrutisnat Jena"
        },
        {
          "href": "https://www.cbr.com/vikings-vs-the-last-kingdom-comparison/",
          "text": "Comic Book Resources",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2306299/\">Vikings</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4179452/\">The Last Kingdom</a> have been the two most prominent Viking-era television historical dramas for years. While many people enjoy both series, the superiority of one over the other will always be a part of the shows&#39; legacies.<br/><br/>Both are top-rated series in their own right. If a new viewer wanted to choose only one to watch, the decision might be a little tricky. The best approach is comparing each show&#39;s historical accuracy, writing, plot and acting to determine whether <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4179452/\">The Last Kingdom</a> or <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2306299/\">Vikings</a> is the superior series.<br/><br/>Related: These Two Shows Are Perfect for Fans of The Mandalorian<br/><br/>Vikings&#39; Action Makes Up For its Historical Inaccuracy<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2306299/\">Vikings</a> takes place during the late 8th and early 9th centuries, a time right before Nordic warriors made it to the shores of England. The series chronicles the lives of the legendary hero Ragnar Lothbrok and his sons. It&#39;s often argued...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cbr.com/vikings-vs-the-last-kingdom-comparison/\">See full article at Comic Book Resources<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BNTYwZmIwODMtOWU3ZC00NTIzLWEyOGQtODNlZmNkOGY0ZmY2XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Vikings vs. The Last Kingdom: Which Is Better?",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cbr.com/vikings-vs-the-last-kingdom-comparison/",
      "id": "ni64177433",
      "sourceName": "Comic Book Resources"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64177254/?ref_=ttnw_art_plk",
          "id": "permalink-ni64177254",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64177254&ref_=ttnw_art_rpt",
          "id": "report-ni64177254",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Lukas Shayo"
        },
        {
          "href": "https://screenrant.com/house-of-the-dragon-season-2-set-photos-scorpion-ballista/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "Warning: Contains Spoilers for <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a> season 2!<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a> season 2 will feature the return of the dragon-killing scorpions, providing insight into the tactics House Targaryen will use in their war. The scorpion weapons were previously used by Euron Greyjoy to kill one of Daenerys Targaryen&#39;s dragons in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>. Despite the story taking place over a century before Daenerys&#39; time, the presence of multiple dragons justifies the use of these weapons in the upcoming season.<br/><br/>The dragon-killing scorpions from <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> are set to return in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a> season 2. As Westeros devolves into civil war, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a> will be setting the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11352546/\">Blacks</a> and the Greens against each other. Both sides have dragons, and both sides are prepared to charge into a war for the Iron Throne. With each army seeking fire and blood, they will need to tear down the...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/house-of-the-dragon-season-2-set-photos-scorpion-ballista/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BYzNkMjUwOGMtNzA4Zi00NjQ2LWE5ZGYtYTEyMzc3MDQ2M2JmXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "House of the Dragon Season 2 Set Photos Reveal Game of Thrones' Dragon-Killing Weapons Return",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/house-of-the-dragon-season-2-set-photos-scorpion-ballista/",
      "id": "ni64177254",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64177145/?ref_=ttnw_art_plk",
          "id": "permalink-ni64177145",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64177145&ref_=ttnw_art_rpt",
          "id": "report-ni64177145",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Gary Collinson"
        },
        {
          "href": "https://www.flickeringmyth.com/2023/07/nicolas-winding-refns-the-famous-five-gets-a-first-look-image-as-cast-announced/",
          "text": "Flickeringmyth",
          "type": "external"
        }
      ],
      "cardHtml": "Read the original post here: Flickering Myth<br/><br/>Last month came the rather unexpected news that Drive and The Neon Demon director <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0716347/\">Nicolas Winding Refn</a> is producing a TV adaptation of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0090067/\">Enid Blyton</a>’s beloved children’s books <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0078611/\">The Famous Five</a> for The <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0921192/\">BBC</a>, and now we have our first official look at the upcoming series.<br/><br/>As revealed by the BBC with the first look image above, the new series will feature <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm10996873/\">Diaana Babnicova</a> as George, Flora Jacoby Richardson as Anne, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11538365/\">Kit Rakusen</a> as Dick and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11830110/\">Elliott Rose</a> as Julian, long with Kep the Dog as Timmy.<br/><br/>Also set to feature in the show alongside the young leads are <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0322416/\">Jack Gleeson</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>) as Wentworth, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm2497049/\">Ann Akinjirin</a> (Moon Knight) as Fanny, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0484202/\">James Lance</a> (Ted Lasso) as <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm10473363/\">Quentin</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0703438/\">Diana Quick</a> (Father Brown) as Mrs Wentworth. The official synopsis reads:<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0078611/\">The Famous Five</a> follows the five daring young explorers as they encounter treacherous,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.flickeringmyth.com/2023/07/nicolas-winding-refns-the-famous-five-gets-a-first-look-image-as-cast-announced/\">See full article at Flickeringmyth<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 338,
        "maxWidth": 600,
        "url": "https://m.media-amazon.com/images/M/MV5BMmE0MmNjZTUtYmRmZS00YmNkLTgzODEtODk1ZWYxOTg2NWUyXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Nicolas Winding Refn’s The Famous Five gets a first-look image as cast announced",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.flickeringmyth.com/2023/07/nicolas-winding-refns-the-famous-five-gets-a-first-look-image-as-cast-announced/",
      "id": "ni64177145",
      "sourceName": "Flickeringmyth"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64177020/?ref_=ttnw_art_plk",
          "id": "permalink-ni64177020",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64177020&ref_=ttnw_art_rpt",
          "id": "report-ni64177020",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Chris Bumbray"
        },
        {
          "href": "https://www.joblo.com/the-best-movies-tv-of-2023-so-far/",
          "text": "JoBlo.com",
          "type": "external"
        }
      ],
      "cardHtml": "2023 is already more than half over, and I’m sure you’re all asking yourselves the same question – where does the time go? Suffice it to say, the year has been solid in terms of content, but with the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0611542/\">SAG</a>-AFTRA-wga strikes still in full force, it seems likely the dog days of summer will suck for new content. That’s why we here at JoBlo have whipped up a handy list of the best movies and TV that have come out so far this year, so if you missed anything, now is your chance to catch up!<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14452776/\">The Bear</a>:<br/><br/>For my money, now that <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt7660850/\">Succession</a> is finished, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14452776/\">The Bear</a> is the best show on TV. The story of a Chicago restaurant’s staff is one of the most intense shows on TV, especially if you’ve ever worked in a kitchen. Season one was superb, but the second season is even better,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.joblo.com/the-best-movies-tv-of-2023-so-far/\">See full article at JoBlo.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 538,
        "maxWidth": 1024,
        "url": "https://m.media-amazon.com/images/M/MV5BZDU1ZTNhMDYtM2VkYi00YWMzLWE0MzQtMDAzYzI3YjQ5YjdjXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "The Best Movies and TV of 2023 (So Far)",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.joblo.com/the-best-movies-tv-of-2023-so-far/",
      "id": "ni64177020",
      "sourceName": "JoBlo.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64177006/?ref_=ttnw_art_plk",
          "id": "permalink-ni64177006",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64177006&ref_=ttnw_art_rpt",
          "id": "report-ni64177006",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Ben Sherlock"
        },
        {
          "href": "https://screenrant.com/satisfying-tv-character-deaths-ranked/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "Despicable villains in TV shows often meet satisfying and deserved deaths, like Gemma Teller Morrow in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1124373/\">Sons of Anarchy</a> and High Commander Winslow in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5834204/\">The Handmaid&#39;s Tale</a>. Characters who start off beloved but become hated due to their amoral actions, such as Ralph Cifaretto in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0141842/\">The Sopranos</a> and Arthur &quot;The Trinity Killer&quot; Mitchell in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0773262/\">Dexter</a>, have deaths that bring a sense of justice. Swift and justified deaths of villains like Kilgrave in Jessica <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1493122/\">Jones</a> and Ramsay Bolton in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> bring closure and satisfaction to viewers.<br/><br/>From Joffrey Baratheon in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> to the Governor in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1520211/\">The Walking Dead</a>, there have been some really satisfying character deaths throughout TV history. Usually, TV character deaths are heartbreaking, like Hank Schrader in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0903747/\">Breaking Bad</a> or <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm4959030/\">Omar Little</a> in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0306414/\">The Wire</a>. Even a character who isn’t particularly likable, like Logan Roy in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt7660850/\">Succession</a>, can tug on the heartstrings when they...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/satisfying-tv-character-deaths-ranked/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 790,
        "maxWidth": 1580,
        "url": "https://m.media-amazon.com/images/M/MV5BMGU3MThjYjgtNWQ1My00NmRmLTlkNmQtZTY5ZDI5MDhhOTMwXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "10 Most Satisfying TV Deaths",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/satisfying-tv-character-deaths-ranked/",
      "id": "ni64177006",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176941/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176941",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176941&ref_=ttnw_art_rpt",
          "id": "report-ni64176941",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Agency News Desk"
        },
        {
          "href": "https://glamsham.com/bollywood/news/iron-man-3-mask-harry-potter-wands-captain-america-shield-to-be-auctioned",
          "text": "GlamSham",
          "type": "external"
        }
      ],
      "cardHtml": "Los Angeles, July 29 (Ians) The helmet worn by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000375/\">Robert Downey Jr</a> in ‘<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1300854/\">Iron Man 3</a>’, wands used in the Harry Potter film series, the mask worn by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0005351/\">Ryan Reynolds</a> in ‘<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1431045/\">Deadpool</a>’ and a <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1330276/\">Captain America</a> shield used by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0262635/\">Chris Evans</a>, are among a host of film paraphernalia set to go on sale.<br/><br/>The helmet, made of fibreglass material and with eyes that shine a blue-white colour, is being sold at an event from <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0624545/\">Julien’s Auctions</a> and Turner Classic Movies (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0738637/\">TCM</a>) for US Dollars 50,000 to 70,000.<br/><br/>The Legends: Hollywood And Royalty auction, featuring more than 1,400 items, in Beverly Hills, California, in September will celebrate 100 years of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0002663/\">Warner Bros</a>, as per Evening Standard.<br/><br/>Previously announced items include three designer dresses worn by Diana, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0703073/\">Princess of Wales</a> which have not been seen in public for more than 30 years.<br/><br/>The auction will also see Star Wars, Stark Trek, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game Of Thrones</a> and James Bond props...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://glamsham.com/bollywood/news/iron-man-3-mask-harry-potter-wands-captain-america-shield-to-be-auctioned\">See full article at GlamSham<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 675,
        "maxWidth": 492,
        "url": "https://m.media-amazon.com/images/M/MV5BMzdmOWMyZTQtZjAzNC00NmQ0LWJlN2YtZDY1Y2E1MjI5NzFmXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "'Iron Man 3' mask, Harry Potter wands, Captain America shield to be auctioned",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://glamsham.com/bollywood/news/iron-man-3-mask-harry-potter-wands-captain-america-shield-to-be-auctioned",
      "id": "ni64176941",
      "sourceName": "GlamSham"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176907/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176907",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176907&ref_=ttnw_art_rpt",
          "id": "report-ni64176907",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Rohitavra Majumdar"
        },
        {
          "href": "https://fugitives.com/hidden-strike-review-2023-netflix-action-thriller-film-scott-waugh/",
          "text": "Film Fugitives",
          "type": "external"
        }
      ],
      "cardHtml": "Twenty minutes into <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0915304/\">Scott Waugh</a>’s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6879446/\">Hidden Strike</a>, we get a sandstorm. By then, the movie has successfully established an intriguing premise and is heading towards <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1392190/\">Mad Max: Fury Road</a> territory. In fact, one of the main leads, the living legend <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000329/\">Jackie Chan</a>, drives a bus toward the storm, which essentially adds to the thrill quotient of the movie. Considering how the action genre has been reinvigorated lately thanks to the likes of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10366206/\">John Wick 4</a> and Mission Impossible: Dead Reckoning, it is not surprising to see a movie like <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6879446/\">Hidden Strike</a> trying to be innovative.<br/><br/>Despite having <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1078479/\">John Cena</a> and Jackie Chan, two actors you wouldn’t usually associate with the new breed of action movies, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6879446/\">Hidden Strike</a> takes off in a fantastic manner. It introduces a world where capitalism is necessarily the main villain and the cause of the suffering of the poor. With a set-up like that,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://fugitives.com/hidden-strike-review-2023-netflix-action-thriller-film-scott-waugh/\">See full article at Film Fugitives<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 575,
        "maxWidth": 1024,
        "url": "https://m.media-amazon.com/images/M/MV5BZmVkMDQ3OTQtNTg1Ni00ZWY1LWEyNDktNjhhOWYwODZlMWI3XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "‘Hidden Strike’ (2023) Review: Jackie Chan-John Cena Starrer Has A Brilliant Opening Then Goes Downhill",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://fugitives.com/hidden-strike-review-2023-netflix-action-thriller-film-scott-waugh/",
      "id": "ni64176907",
      "sourceName": "Film Fugitives"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176805/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176805",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176805&ref_=ttnw_art_rpt",
          "id": "report-ni64176805",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/29/2023"
        },
        {
          "text": "by Ricky Church"
        },
        {
          "href": "https://www.flickeringmyth.com/2023/07/star-wars-the-acolyte-cast-promise-epic-lightsaber-fights-and-choreography/",
          "text": "Flickeringmyth",
          "type": "external"
        }
      ],
      "cardHtml": "Read the original post here: Flickering Myth<br/><br/>There is a lot of secrecy surrounding the upcoming Star Wars TV series <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt12262202/\">The Acolyte</a>, but the show’s cast revealed in a podcast for Entertainment Weekly audiences can expect to see epic lightsaber fights influenced by martial arts and samurai swordplay.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt12262202/\">Star Wars: The Acolyte</a> ventures into uncharted territory for the saga as the first “Sith-led” Star Wars story, and is described as a “mystery-thriller” set during the dying days of the High Republic – around a century before the events of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0120915/\">Star Wars: Episode I – The Phantom Menace</a>. It is, in fact, that first prequel that stars <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3254274/\">Manny Jacinto</a>, Charlie Bartnett and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm6748436/\">Dafne Keen</a> have likened to their lightsaber battles, referencing the epic clash between Qui-Gon Jinn, Obi-Wan Kenobi and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm15095188/\">Darth Maul</a> in Phantom Menace‘s climax.<br/><br/>“If you loved that sequence with Qui-Gon and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11330999/\">Obi-Wan</a> and Darth Maul I think...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.flickeringmyth.com/2023/07/star-wars-the-acolyte-cast-promise-epic-lightsaber-fights-and-choreography/\">See full article at Flickeringmyth<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 405,
        "maxWidth": 600,
        "url": "https://m.media-amazon.com/images/M/MV5BNWJhMTFjMTktN2YxMy00ZDJmLWI0NGQtOTFhYWFkYmU0NGU3XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Star Wars: The Acolyte cast promise epic lightsaber fights and choreography",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.flickeringmyth.com/2023/07/star-wars-the-acolyte-cast-promise-epic-lightsaber-fights-and-choreography/",
      "id": "ni64176805",
      "sourceName": "Flickeringmyth"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176418/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176418",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176418&ref_=ttnw_art_rpt",
          "id": "report-ni64176418",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Matthew Stewart"
        },
        {
          "href": "https://www.goldderby.com/feature/2023-emmy-predictions-best-drama-series-casting-1205505164/",
          "text": "Gold Derby",
          "type": "external"
        }
      ],
      "cardHtml": "Among the dozen Emmy Awards “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>” collected in 2019 for its final season was one for casting, which made it the first drama program to achieve a third victory in that category. Each time it was honored there, it also won Best Drama Series, setting a precedent that “Succession” could emulate this year after having taken both prizes in 2020 and 2022. Although it is heavily favored to clinch the top honor again, its potential casting win might not come as easily or at all, given the remarkably stiff competition it faces from “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13406094/\">The White Lotus</a>.”<br/><br/>After winning 10 Emmys in 2022 while classified as a limited series, “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13406094/\">The White Lotus</a>” is now competing in seven specific drama series categories, including casting. Its genre shift was triggered by its second season’s incorporation of previously established characters. As it goes against “Succession” in this race, it will also have to fend off two-time winner “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4786824/\">The Crown</a>,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.goldderby.com/feature/2023-emmy-predictions-best-drama-series-casting-1205505164/\">See full article at Gold Derby<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 150,
        "maxWidth": 150,
        "url": "https://m.media-amazon.com/images/M/MV5BZDFkNTIxMTUtZTZiZS00NTg0LWI2M2QtMTQzYjU3ZjZiZGJmXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "2023 Emmy Predictions: Best Drama Series Casting",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.goldderby.com/feature/2023-emmy-predictions-best-drama-series-casting-1205505164/",
      "id": "ni64176418",
      "sourceName": "Gold Derby"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176417/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176417",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176417&ref_=ttnw_art_rpt",
          "id": "report-ni64176417",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Amy K Brown"
        },
        {
          "href": "https://collider.com/game-of-thrones-best-leaders-reddit/",
          "text": "Collider.com",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R. R Martin</a>&#39;s extensive fantastical universe spans generations, wars, dragons, and everything in between. <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> holds up as one of the highest-rated television shows of all time, and The House of The Dragon is gaining just as much praise. Behind the shows is the book series, including A <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> and the book that brought Hotd to life, Fire and Blood. George R. R Martin has been commended for his writing, and how much dedication he puts into his various characters.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://collider.com/game-of-thrones-best-leaders-reddit/\">See full article at Collider.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BMTkzYmIxZGMtYTMwMS00MDdlLThhZTctNjE0YmMxYWQ2NTUwXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "10 Best Game of Thrones Leaders, According to Reddit",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://collider.com/game-of-thrones-best-leaders-reddit/",
      "id": "ni64176417",
      "sourceName": "Collider.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176367/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176367",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176367&ref_=ttnw_art_rpt",
          "id": "report-ni64176367",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Brennan Klein"
        },
        {
          "href": "https://screenrant.com/the-famous-five-show-jack-gleeson-casting-update/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0322416/\">Jack Gleeson</a>, who played Joffrey Baratheon in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>, has landed his first major onscreen role since leaving the show in 2014. During his hiatus from television acting, Gleeson co-founded a theater company and performed in various local Irish events. Gleeson&#39;s new role in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0078611/\">The Famous Five</a> marks a potential mainstream return after nearly a decade of retirement.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> star Jack Gleeson has taken his first major onscreen role in nearly a decade with <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0078611/\">The Famous Five</a>. On <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>, Gleeson played the petulant young king Joffrey Baratheon, who sat on the Iron Throne for some time despite his real father being his mother Cersei Lannister&#39;s (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0372176/\">Lena Headey</a>) brother Jaime (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0182666/\">Nikolaj Coster-Waldau</a>). Gleeson starred in 26 episodes of the hit fantasy series before <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm14467081/\">Joffrey</a> was poisoned during the event known as the Purple Wedding.<br/><br/>Now, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0921192/\">BBC</a> has announced the cast of the upcoming series <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0078611/\">The Famous Five</a>, an...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/the-famous-five-show-jack-gleeson-casting-update/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BNTI1N2U3MzctN2VkMC00ZTQzLTliMzEtOTNmNGE3YmVhODQ1XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Game of Thrones' Joffrey Actor Lands First Major Role After Almost A Decade-Long Retirement",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/the-famous-five-show-jack-gleeson-casting-update/",
      "id": "ni64176367",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176314/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176314",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176314&ref_=ttnw_art_rpt",
          "id": "report-ni64176314",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Emma Wagner"
        },
        {
          "href": "https://screenrant.com/good-omens-season-2-cameos/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "This article contains spoilers for <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1869454/\">Good Omens</a> season 2.Good Omens season 2 continues Aziraphale and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm9587733/\">Crowley</a>&#39;s adventure, all while featuring plenty of amazing cameos. The second-season guest spots not only bring fresh faces to the Prime Video show but a spate of wonderful actors too. Adapted from <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0301274/\">Neil Gaiman</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0695332/\">Terry Pratchett</a>&#39;s book of the same name, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1869454/\">Good Omens</a> season 1 follows the novel closely. However, with no sequel material to pull from, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1869454/\">Good Omens</a> season 2 presents an entirely new storyline crafted by Gaiman, which centers on the relationship between Aziraphale and Crowley.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1869454/\">Good Omens</a> season 2 delves deeper into the timeless bond between Aziraphale and Crowley, which illustrates how their interactions and experiences influence each other over the ages. While the inaugural season also boasts notable cameo appearances, such as <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0607375/\">David Morrissey</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1212722/\">Benedict Cumberbatch</a>, and even Gaiman, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1869454/\">Good Omens</a> season 2 doesn&#39;t disappoint either, thanks to appearances from Oscar winners and well-known character actors.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/good-omens-season-2-cameos/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 900,
        "maxWidth": 1800,
        "url": "https://m.media-amazon.com/images/M/MV5BNTlmNjU5OTItZGIyNy00MDJhLTljNzYtYmRhNzAzMmQ4NzBjXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Frances McDormand, Peter Davison & 5 Other Cameos In Good Omens Season 2",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/good-omens-season-2-cameos/",
      "id": "ni64176314",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176305/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176305",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176305&ref_=ttnw_art_rpt",
          "id": "report-ni64176305",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Cody Hamman"
        },
        {
          "href": "https://www.joblo.com/demeter-clip-image-gallery/",
          "text": "JoBlo.com",
          "type": "external"
        }
      ],
      "cardHtml": "Yesterday, we shared a trio of clips from Universal Pictures’ upcoming film <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1001520/\">The Last Voyage of the Demeter</a>, which is based on a single chapter, the Captain’s Log, from <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0831290/\">Bram Stoker</a>’s 1897 novel <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt9139220/\">Dracula</a>. Now another clip from the movie has made its way online, and you can check that out in the embed above. Our friends at <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0189525/\">Bloody Disgusting</a> also got their hands on an image gallery and those images – which feature a couple interesting looks at the movie’s version of Dracula – can be seen at the bottom of this article.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1001520/\">The Last Voyage of the Demeter</a> is set to reach theatres on August 11th.<br/><br/>Escaping development hell twenty years after the script was first written, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1001520/\">The Last Voyage of the Demeter</a> tells the story of the merchant ship Demeter, which was chartered to carry private cargo – fifty unmarked wooden crates – from Carpathia to London. Strange events...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.joblo.com/demeter-clip-image-gallery/\">See full article at JoBlo.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 681,
        "maxWidth": 1024,
        "url": "https://m.media-amazon.com/images/M/MV5BNDQyYjMwMTctNDljNS00MmJjLWE4MjEtYWY4MjIxNGRkMzA0XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "The Last Voyage of the Demeter unveils another clip and an image gallery",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.joblo.com/demeter-clip-image-gallery/",
      "id": "ni64176305",
      "sourceName": "JoBlo.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176306/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176306",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176306&ref_=ttnw_art_rpt",
          "id": "report-ni64176306",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Amie Cranswick"
        },
        {
          "href": "https://www.flickeringmyth.com/2023/07/the-last-voyage-of-the-demeter-clips-tease-new-dracula-movie/",
          "text": "Flickeringmyth",
          "type": "external"
        }
      ],
      "cardHtml": "Read the original post here: Flickering Myth<br/><br/>With just two weeks to go until its theatrical release, four clips have arrived online for <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1001520/\">The Last Voyage of the Demeter</a>, the supernatural horror from director <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0004217/\">André Øvredal</a> which is based on the seventh chapter in the classic Bram <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1682180/\">Stoker</a> novel, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt9139220/\">Dracula</a>; watch them below…<br/><br/>Based on a single chilling chapter from <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0831290/\">Bram Stoker</a>’s classic novel <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt9139220/\">Dracula</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1001520/\">The Last Voyage of the Demeter</a> tells the terrifying story of the merchant ship Demeter, which was chartered to carry private cargo—fifty unmarked wooden crates—from Carpathia to London.<br/><br/>Strange events befall the doomed crew as they attempt to survive the ocean voyage, stalked each night by a merciless presence onboard the ship. When the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11304168/\">Demeter</a> finally arrives off the shores of England, it is a charred, derelict wreck. There is no trace of the crew.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1001520/\">The Last Voyage of the Demeter</a> stars...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.flickeringmyth.com/2023/07/the-last-voyage-of-the-demeter-clips-tease-new-dracula-movie/\">See full article at Flickeringmyth<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 331,
        "maxWidth": 600,
        "url": "https://m.media-amazon.com/images/M/MV5BOWZiYjNiOWQtZGZiMC00NGZmLWIwNWItMTJjMjA4YmZiMjg2XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "The Last Voyage of the Demeter clips tease new Dracula movie",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.flickeringmyth.com/2023/07/the-last-voyage-of-the-demeter-clips-tease-new-dracula-movie/",
      "id": "ni64176306",
      "sourceName": "Flickeringmyth"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64176253/?ref_=ttnw_art_plk",
          "id": "permalink-ni64176253",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64176253&ref_=ttnw_art_rpt",
          "id": "report-ni64176253",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Luiz H. C."
        },
        {
          "href": "https://bloody-disgusting.com/editorials/3770932/period-piece-horror-monster-movies-you-should-watch/",
          "text": "bloody-disgusting.com",
          "type": "external"
        }
      ],
      "cardHtml": "From historically accurate costumes to expensive set designs, it takes a lot of money to shoot a believable period piece, with these films requiring an additional level of planning in order to feel true to life. That’s why it’s so rare to see non-blockbuster productions take on this challenge – especially when it comes to monster movies.<br/><br/>That being said, there are still some brave genre filmmakers that try and experiment with different story settings without the benefit of a super-hero movie budget, which often leads to incredibly unique horror films. That’s why we’ve decided to come up with a list recommending six of the best period-piece monster movies, as creature features shouldn’t have to be limited to any particular era.<br/><br/>For the purposes of this list, we’ll be defining “period piece” as any movie that takes place in a time period previous to when it was filmed.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://bloody-disgusting.com/editorials/3770932/period-piece-horror-monster-movies-you-should-watch/\">See full article at bloody-disgusting.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 416,
        "maxWidth": 740,
        "url": "https://m.media-amazon.com/images/M/MV5BNjAyYTBmMzQtM2QyNC00ZjAwLTg1NzMtOTFmOGJlZGQ3Y2M4XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Six Period Piece Monster Movies You Should Watch",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://bloody-disgusting.com/editorials/3770932/period-piece-horror-monster-movies-you-should-watch/",
      "id": "ni64176253",
      "sourceName": "bloody-disgusting.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64175966/?ref_=ttnw_art_plk",
          "id": "permalink-ni64175966",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64175966&ref_=ttnw_art_rpt",
          "id": "report-ni64175966",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Jordan Williams"
        },
        {
          "href": "https://screenrant.com/good-omens-house-dragon-ty-tennant-young-aegon-death-fire/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "Warning! This article contains spoilers for <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1869454/\">Good Omens</a> season 2, episode 2!<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1869454/\">Good Omens</a> season 2 features <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a>’s Young Aegon actor <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm6122080/\">Ty Tennant</a> in a brief cameo, which nearly fulfills a death that the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> spinoff couldn’t include. Amazon’s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1869454/\">Good Omens</a> season 2 cast brings back <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0855039/\">David Tennant</a> as <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm9587733/\">Crowley</a>, a demon who was cast away from Hell after hindering <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm2526043/\">Satan</a>’s plan to enact the Apocalypse. Tennant’s return also came with the casting of two of the actor’s family members: His father-in-law, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0436992/\">Doctor Who</a>’s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0205749/\">Peter Davison</a>, and his son, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a> season 1’s Ty Tennant.<br/><br/>While Ty Tennant only appeared in two episodes of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a> season 1 as Young Aegon Targaryen, the actor made the most of his time as his loathsome character defaced his bedroom window, got drunk at a funeral, and was frequently chastised by his mother.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/good-omens-house-dragon-ty-tennant-young-aegon-death-fire/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 1000,
        "maxWidth": 2000,
        "url": "https://m.media-amazon.com/images/M/MV5BMDYzMDU1YmUtODZmOS00MjMwLWEyNjItMzI0NWU2YjUxZjc2XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Amazon Just Teased The House Of The Dragon Death That Got's Spinoff Never Could",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/good-omens-house-dragon-ty-tennant-young-aegon-death-fire/",
      "id": "ni64175966",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64175913/?ref_=ttnw_art_plk",
          "id": "permalink-ni64175913",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64175913&ref_=ttnw_art_rpt",
          "id": "report-ni64175913",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Erika Bean"
        },
        {
          "href": "https://www.thedigitalfix.com/wheel-of-time/season-2-release-date",
          "text": "The Digital Fix",
          "type": "external"
        }
      ],
      "cardHtml": "What is <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt7462410/\">The Wheel of Time</a> season 2 release date? Amazon&#39;s fantasy show, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt7462410/\">The Wheel of Time</a>, was so promising that it was renewed for season 2 before it had even aired on the streaming service. Here&#39;s what we know so far about what to expect when it returns.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0331080/\">Wheel of Time</a> season 1 gave us what we&#39;d been missing since <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> ended: an adaptation of beloved, sprawling, and ambitious fantasy novels. Along with the Rings of Power season 2 release date and the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a> season 2 release date, the return of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt7462410/\">The Wheel of Time</a> will attempt to win the battle of the best TV series in the magical genre: a battle that is hotly contested.<br/><br/>But what is <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt7462410/\">The Wheel of Time</a> season 2 release date, and what do we know about the show&#39;s sprawling cast and richly textured plot? Unlike <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3104337/\">Robert Jordan</a>&#39;s novels, this guide is very accessible and very concise.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.thedigitalfix.com/wheel-of-time/season-2-release-date\">See full article at The Digital Fix<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 1080,
        "maxWidth": 1920,
        "url": "https://m.media-amazon.com/images/M/MV5BOWRjOGQ5MTEtMWZlZS00OTFhLThjY2QtOGZkYzlhNDRlMGVmXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "The Wheel of Time season 2 release date, cast, plot, and more news",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.thedigitalfix.com/wheel-of-time/season-2-release-date",
      "id": "ni64175913",
      "sourceName": "The Digital Fix"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64175768/?ref_=ttnw_art_plk",
          "id": "permalink-ni64175768",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64175768&ref_=ttnw_art_rpt",
          "id": "report-ni64175768",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Lissete Lanuza Sáenz"
        },
        {
          "href": "https://www.cbr.com/witcher-season-3-part-2-review/",
          "text": "Comic Book Resources",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5180504/\">The Witcher</a> Season 3, Part 2 saves the worst for last with three episodes that deliver a fair bit in the way of big battles but very little in the way of emotional beats, proving that <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0144901/\">Netflix</a>&#39;s staggered release strategy isn&#39;t really sustainable. Or, at least, that it isn&#39;t sustainable for shows that aren&#39;t planned to be released in this fashion, which <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5180504/\">The Witcher</a> Season 3 clearly wasn&#39;t.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0147147/\">Henry Cavill</a>&#39;s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11508625/\">Geralt</a> of Rivia has some high moments, as the actor bids goodbye to a character he has inhabited for three seasons and that fans will likely always consider synonymous with him, but those moments don&#39;t come close to the highs of Season 1, and there&#39;s nothing resembling a heroic sendoff in the final moments of Season 3. If anything, Cavill&#39;s Geralt departs with a whimper and not a bang. The next time fans see the character, he will be <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm2955013/\">Liam Hemsworth</a>, and fans...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cbr.com/witcher-season-3-part-2-review/\">See full article at Comic Book Resources<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BYmJiNDhlOTQtOWRhNi00ZmFkLWE3OTctY2Q2YzMzMWZkN2U1XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "The Witcher Season 3 Part 2 Review",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cbr.com/witcher-season-3-part-2-review/",
      "id": "ni64175768",
      "sourceName": "Comic Book Resources"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64175607/?ref_=ttnw_art_plk",
          "id": "permalink-ni64175607",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64175607&ref_=ttnw_art_rpt",
          "id": "report-ni64175607",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Agency News Desk"
        },
        {
          "href": "https://glamsham.com/bollywood/news/gots-jack-gleeson-unrecognisable-in-new-famous-five-role",
          "text": "GlamSham",
          "type": "external"
        }
      ],
      "cardHtml": "London, July 28 (Ians) Irish actor <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0322416/\">Jack Gleeson</a>, who plays the cruel and sadistic King Joffrey Baratheon in ‘Game of Thrones’, is set to feature in the TV adaptation of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0090067/\">Enid Blyton</a>’s ‘<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0078611/\">The Famous Five</a>’ novels, and by the first look of his character, it appears to be another villainous one.<br/><br/>Gleeson has transformed into Wentworth for a first-look at the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0921192/\">BBC</a>’s reboot of ‘<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0078611/\">The Famous Five</a>’ and looks very different from his role as Joffrey Baratheon.<br/><br/>His fair golden hair, which was synonymous with the Lannisters in ‘Game of Thrones’ is gone and instead, Gleeson cuts a rather villainous figure, as per Express UK.<br/><br/>The actor sports short dark locks and a thin moustache as he shoots a terrifying look at the camera.<br/><br/>His character Wentworth is dressed in a blue pinstripe suit with white shirt and striped scarf, which is fastened in a bow.<br/><br/>Completing his evil look,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://glamsham.com/bollywood/news/gots-jack-gleeson-unrecognisable-in-new-famous-five-role\">See full article at GlamSham<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 336,
        "maxWidth": 933,
        "url": "https://m.media-amazon.com/images/M/MV5BNzViNzkwMzYtNjhiMy00NWVkLTkwYTQtYjZiMzE3MTg2OTBmXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "GoT's Jack Gleeson unrecognisable in new 'Famous Five' role",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://glamsham.com/bollywood/news/gots-jack-gleeson-unrecognisable-in-new-famous-five-role",
      "id": "ni64175607",
      "sourceName": "GlamSham"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64175162/?ref_=ttnw_art_plk",
          "id": "permalink-ni64175162",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64175162&ref_=ttnw_art_rpt",
          "id": "report-ni64175162",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/28/2023"
        },
        {
          "text": "by Jill Goldsmith"
        },
        {
          "href": "https://deadline.com/2023/07/roku-charlie-collier-lotr-got-house-of-the-dragon-earnings-wga-sag-aftra-strike-1235449864/",
          "text": "Deadline Film + TV",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0364962/\">Roku</a> executives spent some time today talking about <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0408922/\">M&amp;e</a> and the company’s Media &amp; Entertainment advertising business that they expect to take a hit in the second half of the year as Hollywood strikes disrupt the television calendar.<br/><br/>“As an illustration of the M&amp;e marketplace change, it’s taken place in really less than one year,” said President <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm2488237/\">Charlie Collier</a>, the former Fox and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0759230/\">AMC</a> exec who joined Roku last fall, on a conference call after the company’s quarterly earnings.<br/><br/>“It feels like a long time ago, but in just August and September of last year, that’s when HBO Max, now Max, launched its <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> spinoff [<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a>]. It’s when Amazon launched its <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0120737/\">Lord of The Rings</a>, The Rings of Power TV show. And you’re not going to see anything like that this year for all sorts of obvious reasons. And...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://deadline.com/2023/07/roku-charlie-collier-lotr-got-house-of-the-dragon-earnings-wga-sag-aftra-strike-1235449864/\">See full article at Deadline Film + TV<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 845,
        "maxWidth": 1500,
        "url": "https://m.media-amazon.com/images/M/MV5BODA5OTcwMjgtOGQwMy00YjNmLTlkYTktOGE3YjE1M2ZhNDk1XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Roku’s Charlie Collier Recalls Frothy Late Summer 2022 Of Rings & Dragons: “You’re Not Going To See Anything Like That This Year”",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://deadline.com/2023/07/roku-charlie-collier-lotr-got-house-of-the-dragon-earnings-wga-sag-aftra-strike-1235449864/",
      "id": "ni64175162",
      "sourceName": "Deadline Film + TV"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64175118/?ref_=ttnw_art_plk",
          "id": "permalink-ni64175118",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64175118&ref_=ttnw_art_rpt",
          "id": "report-ni64175118",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/27/2023"
        },
        {
          "text": "by Aman Goyal"
        },
        {
          "href": "https://www.cbr.com/game-of-thrones-jack-gleeson-famous-five-reboot/",
          "text": "Comic Book Resources",
          "type": "external"
        }
      ],
      "cardHtml": "After nine years of being mostly retired, actor <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0322416/\">Jack Gleeson</a>, best known for his role in HBO&#39;s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>, is set to make a comeback to television.<br/><br/>Fans of the hit epic fantasy drama series have a reason to rejoice as Gleeson, who received acclaim for his performance as the villainous king Joffrey Baratheon in the first four seasons of the series, will once again grace our television screens. In an announcement from <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0921192/\">BBC</a> about upcoming the adaptation of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0090067/\">Enid Blyton</a>’s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0078611/\">The Famous Five</a> series, the actor was announced as one of the cast members. The actor had previously announced his retirement from acting, citing in interviews that the experience of being a full-time actor had reduced his passion for the job, though he&#39;s had sporadic roles in recent years.<br/><br/>Related: <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">GoT</a> Author <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R.R. Martin</a> Is Still Writing The Winds of Winter Despite Strikes<br/><br/>After retiring from acting for the screen,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cbr.com/game-of-thrones-jack-gleeson-famous-five-reboot/\">See full article at Comic Book Resources<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BODYwODhkODAtZWM0NS00YWI5LThkNDctOGNiMWJmMGQ0OTgwXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Game of Thrones' Joffrey Actor to Star in Drive Director's Famous Five Reboot",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cbr.com/game-of-thrones-jack-gleeson-famous-five-reboot/",
      "id": "ni64175118",
      "sourceName": "Comic Book Resources"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64175018/?ref_=ttnw_art_plk",
          "id": "permalink-ni64175018",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64175018&ref_=ttnw_art_rpt",
          "id": "report-ni64175018",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/27/2023"
        },
        {
          "text": "by Ali Valle"
        },
        {
          "href": "https://movieweb.com/the-righteous-gemstones-season-4-gets-greenlight-from-hbo-after-hitting-record-numbers/",
          "text": "MovieWeb",
          "type": "external"
        }
      ],
      "cardHtml": "It seems the heavens have showered their blessings on HBO&#39;s dark comedy, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8634332/\">The Righteous Gemstones</a>. After a steady climb in recognition and critical acclaim since its inaugural season in August 2019, the show has hit an all-time high. Now, with its latest coup, HBO has greenlit a fourth season even before the curtain falls on its third season finale, scheduled for July 30.<br/><br/>The brainchild of creator <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1144419/\">Danny McBride</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8634332/\">The Righteous Gemstones</a> dives deep into the complex and often contentious lives of a world-renowned televangelist family. Seamlessly blending their pious work with an underbelly of greed and mischief, the show has struck a chord with viewers. This winning combination has not only granted it another season but has also cemented its place in HBO&#39;s hall of fame. Breaking records, the show now stands as McBride’s most-viewed on HBO, overshadowing his earlier successful endeavors like Eastbound and Down and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6266538/\">Vice</a> Principals. As per recent press data,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://movieweb.com/the-righteous-gemstones-season-4-gets-greenlight-from-hbo-after-hitting-record-numbers/\">See full article at MovieWeb<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 630,
        "maxWidth": 1200,
        "url": "https://m.media-amazon.com/images/M/MV5BYWE0NzY4YTMtYzg2My00MTBjLTk4ZGItODAyYWY1NzVhMjUwXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "The Righteous Gemstones Season 4 Gets Greenlight from HBO After Hitting Record Numbers",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://movieweb.com/the-righteous-gemstones-season-4-gets-greenlight-from-hbo-after-hitting-record-numbers/",
      "id": "ni64175018",
      "sourceName": "MovieWeb"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64174830/?ref_=ttnw_art_plk",
          "id": "permalink-ni64174830",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64174830&ref_=ttnw_art_rpt",
          "id": "report-ni64174830",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/27/2023"
        },
        {
          "text": "by Perry Carpenter"
        },
        {
          "href": "https://www.cheatsheet.com/entertainment/game-of-thrones-author-george-r-r-martin-calls-himself-lucky-while-revealing-hbo-suspended-development-deal.html/",
          "text": "Showbiz Cheat Sheet",
          "type": "external"
        }
      ],
      "cardHtml": "As Hollywood grapples with widespread strikes, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> author <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R.R. Martin</a> is counting his blessings. In a surprising revelation, Martin announced that HBO pushed the pause button on his development deals, but he’s far from idle.<br/><br/>Martin finds himself in an enviable position in an industry where many are scrambling for work. With plenty of ongoing projects to occupy his time, the author considers himself ‘lucky.’<br/><br/>George R.R. Martin | <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm5078767/\">Jeff Kravitz</a>/<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0422724/\">FilmMagic</a> for HBO George R.R. Martin calls himself ‘lucky’ amid contract suspension<br/><br/>During the ongoing Hollywood strikes, Martin has disclosed that HBO has put his development deals on hold. However, the renowned creator of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> isn’t wallowing in disappointment.<br/><br/>In a recent post on his official blog, Martin considered himself “lucky” amid the turbulence in Hollywood. While others are hard-pressed for work, his plate remains full despite the suspension of writing for TV shows and movies.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cheatsheet.com/entertainment/game-of-thrones-author-george-r-r-martin-calls-himself-lucky-while-revealing-hbo-suspended-development-deal.html/\">See full article at Showbiz Cheat Sheet<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 800,
        "maxWidth": 1200,
        "url": "https://m.media-amazon.com/images/M/MV5BNGIyMjhhMDEtZmJhMy00MmM5LTkyZjMtMGZiM2ZjYjE3ZmQ5XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "‘Game of Thrones’ Author George R.R. Martin Calls Himself ‘Lucky’ While Revealing HBO Has Suspended His Development Deal",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cheatsheet.com/entertainment/game-of-thrones-author-george-r-r-martin-calls-himself-lucky-while-revealing-hbo-suspended-development-deal.html/",
      "id": "ni64174830",
      "sourceName": "Showbiz Cheat Sheet"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64174584/?ref_=ttnw_art_plk",
          "id": "permalink-ni64174584",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64174584&ref_=ttnw_art_rpt",
          "id": "report-ni64174584",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/27/2023"
        },
        {
          "text": "by Abdullah Al-Ghamdi"
        },
        {
          "href": "https://screenrant.com/the-righteous-gemstones-season-4-show-renewed-hbo/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8634332/\">The Righteous Gemstones</a> season 4 is officially happening, breaking new ground for show creator <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1144419/\">Danny McBride</a>. The comedy show has gained critical acclaim and recognition since its debut in 2019, and it&#39;s now McBride&#39;s most-watched HBO show. Current episodes of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8634332/\">The Righteous Gemstones</a> average 4.9 million viewers and the show&#39;s popularity is still growing.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8634332/\">The Righteous Gemstones</a> season 4 is confirmed at HBO, as the dark comedy breaks new ground for creator Danny McBride. The comedy show, which focuses on a world-famous televangelist family who has a long tradition of mixing deviance and greed with charitable work, has steadily improved in both critical acclaim and recognition since its August 2019 debut. And now, along with getting renewed, it&#39;s made some history.<br/><br/>HBO has confirmed that <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8634332/\">The Righteous Gemstones</a> season 4 will happen, ahead of the comedy&#39;s season 3 finale on July 30. <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8634332/\">The Righteous Gemstones</a> is now also McBride’s most-watched HBO show, outperforming his previous projects Eastbound and Down and Vice Principals.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/the-righteous-gemstones-season-4-show-renewed-hbo/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 960,
        "maxWidth": 1920,
        "url": "https://m.media-amazon.com/images/M/MV5BNzlkYThlMGMtZDZmMC00OGU2LWI5ODktMjUyNTJkYmM1ZjBjXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "The Righteous Gemstones Season 4 Renewed After Breaking HBO Record",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/the-righteous-gemstones-season-4-show-renewed-hbo/",
      "id": "ni64174584",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64174437/?ref_=ttnw_art_plk",
          "id": "permalink-ni64174437",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64174437&ref_=ttnw_art_rpt",
          "id": "report-ni64174437",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/27/2023"
        },
        {
          "text": "by Cody Hamman"
        },
        {
          "href": "https://www.joblo.com/last-voyage-of-the-demeter-clips/",
          "text": "JoBlo.com",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0005073/\">Universal Pictures</a> will be giving the horror film <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1001520/\">The Last Voyage of the Demeter</a>, which is based on a single chapter, the Captain’s Log, from <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0831290/\">Bram Stoker</a>’s 1897 novel <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt9139220/\">Dracula</a>, a theatrical release on August 11th. With the release date just a couple weeks away, they’ve decided to promote the film by dropping a trio of clips online. You can watch one of the clips in the embed above, and the other two can be found at the bottom of this article.<br/><br/>Escaping development hell twenty years after the script was first written, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1001520/\">The Last Voyage of the Demeter</a> tells the story of the merchant ship Demeter, which was chartered to carry private cargo – fifty unmarked wooden crates – from Carpathia to London. Strange events befall the doomed crew as they attempt to survive the ocean voyage, stalked each night by a merciless presence onboard the ship. When the...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.joblo.com/last-voyage-of-the-demeter-clips/\">See full article at JoBlo.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "The Last Voyage of the Demeter (2023)",
        "maxHeight": 6000,
        "maxWidth": 4050,
        "url": "https://m.media-amazon.com/images/M/MV5BOTljMzRkNDItNjYxYS00ODA4LThiZjYtMjI0MTFjODlmMGJmXkEyXkFqcGdeQXVyNzU0NzQxNTE@._V1_.jpg"
      },
      "cardText": "The Last Voyage of the Demeter clips offer a preview of Universal’s new Dracula movie",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.joblo.com/last-voyage-of-the-demeter-clips/",
      "id": "ni64174437",
      "sourceName": "JoBlo.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64174022/?ref_=ttnw_art_plk",
          "id": "permalink-ni64174022",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64174022&ref_=ttnw_art_rpt",
          "id": "report-ni64174022",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/27/2023"
        },
        {
          "text": "by Joshua M. Patton"
        },
        {
          "href": "https://www.cbr.com/the-witcher-game-of-thrones-battles-better/",
          "text": "Comic Book Resources",
          "type": "external"
        }
      ],
      "cardHtml": "The following contains spoilers from The Witcher Season 3, now streaming on <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0144901/\">Netflix</a>.<br/><br/>While fantasy fans know there are few similarities between the properties, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5180504/\">The Witcher</a> is akin to Netflix&#39;s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>. Unfortunately, the series based on the books of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1140292/\">Andrzej Sapkowski</a> has not been as widely praised as those based on the books of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R.R. Martin</a>. However, in The Witcher Season 3, the Battle of Aretuza puts the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> battles to shame.<br/><br/>Whether the &quot;Battle of the Bastards&quot; or &quot;<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10509906/\">The Long Night</a>&quot; at Winterfell, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> battles are massive in scale. They are usually shot on location, involving dozens, if not hundreds, of extras and animals. The Witcher Season 3, Episode 6, &quot;Everybody Has a Plain, &#39;til They Get Punched in the Face,&quot; is an episode-long battle that, in some ways, surpasses HBO&#39;s dragon-laden adventure. The high-end estimates of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5180504/\">The Witcher</a>&#39;s per-episode budget are (not cheap) $10 million.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cbr.com/the-witcher-game-of-thrones-battles-better/\">See full article at Comic Book Resources<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BMGE3YmM2MzAtODdmOS00ZTk4LTg1MDQtMTJhNGJjNjAzMmZlXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "How The Witcher's 'Battle for Aretuza' Surpasses Game of Thrones",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cbr.com/the-witcher-game-of-thrones-battles-better/",
      "id": "ni64174022",
      "sourceName": "Comic Book Resources"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64173912/?ref_=ttnw_art_plk",
          "id": "permalink-ni64173912",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64173912&ref_=ttnw_art_rpt",
          "id": "report-ni64173912",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/27/2023"
        },
        {
          "text": "by Anthony Lund"
        },
        {
          "href": "https://movieweb.com/secret-invasions-finale-causes-superpowered-hero-problem-for-mcu-future/",
          "text": "MovieWeb",
          "type": "external"
        }
      ],
      "cardHtml": "Warning: This article contains spoilers for <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13157618/\">Secret Invasion</a> Episode 6: &quot;Home&quot;<br/><br/>The MCU is not short on superheroes with powers that make them practically invincible, and the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13157618/\">Secret Invasion</a> finale has caused a dilemma for the future of the Marvel franchise by creating a character that surpasses the might of every other hero in the franchise. Having teased the existence of “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2543336/\">The Harvest</a>,” a collection of DNA taken from Earth’s mightiest heroes, the finale of the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0721120/\">Disney+</a> series saw Emliia Clarke’s G’iah being given a super-power makeover that could cause a problem for the MCU’s future stories.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13157618/\">Secret Invasion</a> gave <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm6417198/\">Nick Fury</a> his own TV series, allowing his character to finally be developed in a way that is impossible to do during any of the movies he has appeared in. <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000168/\">Samuel L. Jackson</a> embodies the character with ease, and like most Disney+ Marvel shows, he is...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://movieweb.com/secret-invasions-finale-causes-superpowered-hero-problem-for-mcu-future/\">See full article at MovieWeb<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 630,
        "maxWidth": 1200,
        "url": "https://m.media-amazon.com/images/M/MV5BZTc0YTI3MTQtZjk5Mi00Njg0LTkxMjMtZmFiNGE5MTZlMDA4XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Secret Invasion's Finale Causes Superpowered Hero Problem for MCU Future",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://movieweb.com/secret-invasions-finale-causes-superpowered-hero-problem-for-mcu-future/",
      "id": "ni64173912",
      "sourceName": "MovieWeb"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64173884/?ref_=ttnw_art_plk",
          "id": "permalink-ni64173884",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64173884&ref_=ttnw_art_rpt",
          "id": "report-ni64173884",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/27/2023"
        },
        {
          "text": "by Anthony Lund"
        },
        {
          "href": "https://movieweb.com/hugh-grants-wonka-appearance-blasted-dwarfism/",
          "text": "MovieWeb",
          "type": "external"
        }
      ],
      "cardHtml": "While many people have been delighted to see <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000424/\">Hugh Grant</a> make his debut appearance as an <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1675108/\">Oompa Loompa</a> in the first full trailer for <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0367594/\">Charlie and the Chocolate Factory</a> prequel <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6166392/\">Wonka</a>, not everyone is happy with the actor “taking away” the role of actors with dwarfism. Willow and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3089630/\">Artemis Fowl</a> star <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm14152764/\">George Coppen</a>, who has dwarfism himself, criticised the decision to cast Grant in the role of the movie’s small character.<br/><br/>Speaking in an interview with <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0530479/\">BBC News</a>, Coppen rallied against the use of someone who does not have dwarfism taking away the job of someone who does though the use of special effects. He said:<br/><br/>&quot;A lot of actors [with dwarfism] feel like we are being pushed out of the industry we love. A lot of people, myself included, argue that dwarfs should be offered everyday roles in dramas and soaps, but we aren’t getting offered those roles. One...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://movieweb.com/hugh-grants-wonka-appearance-blasted-dwarfism/\">See full article at MovieWeb<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 630,
        "maxWidth": 1200,
        "url": "https://m.media-amazon.com/images/M/MV5BNTdkMWE2MDAtOWI1NC00ZTUzLWI1NTAtN2Q4MWQ2NjcxZmYyXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Hugh Grant's Wonka Appearance Blasted By Willow Star",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://movieweb.com/hugh-grants-wonka-appearance-blasted-dwarfism/",
      "id": "ni64173884",
      "sourceName": "MovieWeb"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64173312/?ref_=ttnw_art_plk",
          "id": "permalink-ni64173312",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64173312&ref_=ttnw_art_rpt",
          "id": "report-ni64173312",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/26/2023"
        },
        {
          "text": "by Matthew Rudoy"
        },
        {
          "href": "https://screenrant.com/wonka-movie-hugh-grant-oompa-loompa-casting-backlash/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm14152764/\">George Coppen</a> criticizes the casting of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000424/\">Hugh Grant</a> as an <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1675108/\">Oompa Loompa</a> in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6166392/\">Wonka</a>, highlighting the larger issue of actors with dwarfism being pushed out of the industry. Coppen argues that actors with dwarfism should be offered everyday roles in dramas and soaps, but they are not being given those opportunities. Coppen expresses confusion over the decision to enlarge Hugh Grant&#39;s head for the role, questioning the choice made by the casting team.<br/><br/>Wonka&#39;s casting of Hugh Grant as an Oompa Loompa has been slammed by actor George Coppen. Coppen is an actor with dwarfism who is best known for playing Sweet Cupid in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0144901/\">Netflix</a>&#39;s School for Good and Evil. He has also played a dwarf in the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3089630/\">Artemis Fowl</a> movie and a Nelwyn villager in the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10278918/\">Willow</a> television series. The <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6166392/\">Wonka</a> movie stars <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3154303/\">Timothée Chalamet</a> as the eponymous chocolate maker and will explore his origin story prior to <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0367594/\">Charlie and the Chocolate Factory</a>.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/wonka-movie-hugh-grant-oompa-loompa-casting-backlash/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BOGIxMTIxMjktOTdiMC00Yjk2LTlhMjEtNjk1MzA1ZTg1NTA2XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "\"What The Hell Have You Done To Him?\" Hugh Grant's Wonka Casting As Oompa Loompa Slammed By Actor With Dwarfism",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/wonka-movie-hugh-grant-oompa-loompa-casting-backlash/",
      "id": "ni64173312",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64173191/?ref_=ttnw_art_plk",
          "id": "permalink-ni64173191",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64173191&ref_=ttnw_art_rpt",
          "id": "report-ni64173191",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/26/2023"
        },
        {
          "text": "by Lee Freitag"
        },
        {
          "href": "https://www.cbr.com/secret-invasion-super-skrull-face-off-giah-gravik-death/",
          "text": "Comic Book Resources",
          "type": "external"
        }
      ],
      "cardHtml": "The following contains spoilers for <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13157618/\">Secret Invasion</a> Episode 6, &quot;Home,&quot; now streaming on <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0721120/\">Disney+</a>.<br/><br/>G&#39;iah and Gravik engaged in a Super Skrull smackdown in the series finale of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13157618/\">Secret Invasion</a>, which came to a mighty conclusion when the latter was killed.<br/><br/>The sixth and final episode of the Disney+ limited series, &quot;Home,&quot; sees Gravik and G&#39;iah (unbeknownst to the former) becoming new and improved Super Skrulls after the latter (disguised as <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm6417198/\">Nick Fury</a>) handed over The <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1827528/\">Harvest</a> -- a vial containing the DNA of several Avengers and alien creatures. The two Super Skrulls then fight, showcasing their new abilities, such as Mantis&#39; sleep manipulation and Hulk&#39;s super strength. The fight comes to an end when G&#39;iah uses her combined powers to blast a hole through Gravik&#39;s chest, killing him instantly.<br/><br/>Related: Secret Invasion Finale Brings Back [Spoiler]<br/><br/>Gravik&#39;s death will no doubt please the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13157618/\">Secret Invasion</a> fans who are still mourning the...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cbr.com/secret-invasion-super-skrull-face-off-giah-gravik-death/\">See full article at Comic Book Resources<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BMTFiMDUxOTYtNDY0OC00ZTAyLWIyNDYtZTkyYTU4YTcyMDRjXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "G'iah Kills Gravik in Secret Invasion Finale",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cbr.com/secret-invasion-super-skrull-face-off-giah-gravik-death/",
      "id": "ni64173191",
      "sourceName": "Comic Book Resources"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64172805/?ref_=ttnw_art_plk",
          "id": "permalink-ni64172805",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64172805&ref_=ttnw_art_rpt",
          "id": "report-ni64172805",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/26/2023"
        },
        {
          "text": "by Leon Miller"
        },
        {
          "href": "https://www.cbr.com/game-of-thrones-george-rr-martin-writing-strikes/",
          "text": "Comic Book Resources",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> author <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R.R. Martin</a> recently confirmed that he continues to write The Winds of Winter amid the ongoing <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0375836/\">SAG-AFTRA</a> and WGA strikes.<br/><br/>Martin made it clear that the industrial action in Hollywood hasn&#39;t affected progress on The Winds of Winter, the seventh installment in the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">A Song of Ice and Fire</a> series that inspired <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>, in a Not a Blog post. &quot;[Y]es, yes, of course, I&#39;ve been working on Winds of Winter,&quot; he wrote. &quot;Almost every day. Writing, rewriting, editing, writing some more. Making steady progress. Not as fast as I would like... certainly not as fast as You would like… but progress nonetheless.&quot; Fans have been awaiting The Winds of Winter&#39;s release since the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">A Song of Ice and Fire</a> series&#39; sixth installment, A Dance with Dragons, hit shelves in 2011.<br/><br/>Related: Warrior Turns Mai Ling Into a Better Version of Game of Thrones&#39; Cersei...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cbr.com/game-of-thrones-george-rr-martin-writing-strikes/\">See full article at Comic Book Resources<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BYmUyYzA5NTgtOTc2OS00Mzk5LTgzZWYtYTQ1NmUwNDIzMDZlXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "GoT Author George R.R. Martin Is Still Writing The Winds of Winter Despite Strikes",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cbr.com/game-of-thrones-george-rr-martin-writing-strikes/",
      "id": "ni64172805",
      "sourceName": "Comic Book Resources"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64172802/?ref_=ttnw_art_plk",
          "id": "permalink-ni64172802",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64172802&ref_=ttnw_art_rpt",
          "id": "report-ni64172802",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/26/2023"
        },
        {
          "text": "by Ben Sherlock"
        },
        {
          "href": "https://screenrant.com/tv-episodes-beginning-of-end-decline-show-downfall/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "One bad episode can ruin the reputation of a fan-favorite TV show and signal the beginning of its downfall. Shows like <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0096697/\">The Simpsons</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1520211/\">The Walking Dead</a> suffered declines in quality due to controversial episodes, such as the gruesome death of a beloved character. Some shows, like <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4574334/\">Stranger Things</a>, were able to recover from a bad episode and improve their overall quality in subsequent seasons.<br/><br/>When a popular TV show like <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0096697/\">The Simpsons</a> or <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1520211/\">The Walking Dead</a> suffers a tragic downfall and loses its magic, the failure can usually be traced back to one polarizing episode. It’s common for TV shows to reach a peak somewhere in the middle of their run and gradually go downhill afterward. Whether the writers ran out of good ideas and started “jumping the shark,&quot; an actor who was crucial to the series’ success left the cast, or a beloved character was killed off...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/tv-episodes-beginning-of-end-decline-show-downfall/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 840,
        "maxWidth": 1680,
        "url": "https://m.media-amazon.com/images/M/MV5BNzljM2QwNjMtMmEzMi00MDQ2LWI2NWEtZjIxODVmZmZlZjhlXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "10 Episodes That Show Exactly When TV Shows Started Going Downhill",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/tv-episodes-beginning-of-end-decline-show-downfall/",
      "id": "ni64172802",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64172686/?ref_=ttnw_art_plk",
          "id": "permalink-ni64172686",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64172686&ref_=ttnw_art_rpt",
          "id": "report-ni64172686",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/26/2023"
        },
        {
          "text": "by Grant Hermanns"
        },
        {
          "href": "https://screenrant.com/twisted-metal-show-samoa-joe-wrestling-history-sweet-tooth-influences/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1649934/\">Samoa Joe</a> draws on his pro wrestling experience to bring personality to his faceless character in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14261112/\">Twisted Metal</a>. Fans of the gaming franchise are excited to see Joe make his live-action acting debut as <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm12275890/\">Sweet Tooth</a> in the show. With successful wrestler-turned-actors like <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0425005/\">Dwayne Johnson</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1078479/\">John Cena</a>, there is anticipation for whether Joe will become the next sensation in the acting world.<br/><br/>As he gears up to make his live-action acting debut, Samoa Joe explains how his pro wrestling history influenced his <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14261112/\">Twisted Metal</a> show performance. The Ring of Honor World Television Champion stars in the adaptation of the PlayStation gaming franchise as Sweet Tooth, the iconic killer clown and face of the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14261112/\">Twisted Metal</a> games who makes his way through the eponymous tournament in a heavily armed ice cream truck. Joining Joe for the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14261112/\">Twisted Metal</a> show&#39;s cast are <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1107001/\">Anthony Mackie</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3715867/\">Stephanie Beatriz</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0002006/\">Thomas Haden Church</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000117/\">Neve Campbell</a>...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/twisted-metal-show-samoa-joe-wrestling-history-sweet-tooth-influences/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 720,
        "maxWidth": 1280,
        "url": "https://m.media-amazon.com/images/M/MV5BOTc0NTNjMGQtZWNhNS00MWQyLWJjMTMtYWI2N2E4NWFiOTIwXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Twisted Metal Show Actor Explains How Pro Wrestling Influenced His Sweet Tooth Performance",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/twisted-metal-show-samoa-joe-wrestling-history-sweet-tooth-influences/",
      "id": "ni64172686",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64172321/?ref_=ttnw_art_plk",
          "id": "permalink-ni64172321",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64172321&ref_=ttnw_art_rpt",
          "id": "report-ni64172321",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/26/2023"
        },
        {
          "text": "by Naman Ramachandran"
        },
        {
          "href": "https://variety.com/2023/tv/global/enid-blyton-famous-five-bbc-zdf-nicolas-winding-refn-cast-1235680397/",
          "text": "Variety Film + TV",
          "type": "external"
        }
      ],
      "cardHtml": "Casting<br/><br/>Casting for the beloved “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1954464/\">Famous Five</a>” stories of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0090067/\">Enid Blyton</a>, which are being reimagined for the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0921192/\">BBC</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0607381/\">Zdf</a> by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0716347/\">Nicolas Winding Refn</a>, has been revealed.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm10996873/\">Diaana Babnicova</a> is playing the role of George, alongside <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11830110/\">Elliott Rose</a> as Julian, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11538365/\">Kit Rakusen</a> as Dick, Flora Jacoby Richardson as Anne, playing George’s cousins who come to stay at Kirrin Cottage.<br/><br/>Making up the fifth member of the “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1954464/\">Famous Five</a>” is Kip, the Bearded Collie Cross playing Timmy the dog. The cast also includes <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0322416/\">Jack Gleeson</a> (“<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>”), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm2497049/\">Ann Akinjirin</a> (“Moon Knight”), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0484202/\">James Lance</a> (“Ted Lasso”) and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0703438/\">Diana Quick</a> (“Father Brown”).<br/><br/>The 3 x 90′ series is based on the 21 “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1954464/\">Famous Five</a>” novels and short stories Blyton wrote between 1942 and 1963. The series follows five daring young explorers as they encounter treacherous, action-packed adventures, remarkable mysteries, unparalleled danger and astounding secrets. It is created for television and executive produced by Winding Refn (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co1005207/\">byNWR</a>...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://variety.com/2023/tv/global/enid-blyton-famous-five-bbc-zdf-nicolas-winding-refn-cast-1235680397/\">See full article at Variety Film + TV<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 563,
        "maxWidth": 1000,
        "url": "https://m.media-amazon.com/images/M/MV5BYjMzN2ExNWQtMjUxOC00NDM4LWFjZTgtYzQ1NWFmY2M5Zjk3XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Enid Blyton’s ‘Famous Five’ BBC, Zdf Adaptation by Nicolas Winding Refn Sets Cast – Global Bulletin",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://variety.com/2023/tv/global/enid-blyton-famous-five-bbc-zdf-nicolas-winding-refn-cast-1235680397/",
      "id": "ni64172321",
      "sourceName": "Variety Film + TV"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64172290/?ref_=ttnw_art_plk",
          "id": "permalink-ni64172290",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64172290&ref_=ttnw_art_rpt",
          "id": "report-ni64172290",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/26/2023"
        },
        {
          "text": "by Max Goldbart and Melanie Goodfellow"
        },
        {
          "href": "https://deadline.com/2023/07/famous-five-nicholas-winding-refn-sets-cast-bbc-global-briefs-1235448299/",
          "text": "Deadline Film + TV",
          "type": "external"
        }
      ],
      "cardHtml": "Nicholas Winding Refn’s ‘<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1954464/\">Famous Five</a>’ Adaptation Sets Cast<br/><br/>The <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0921192/\">BBC</a>’s upcoming <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1954464/\">Famous Five</a> adaptation from Nicholas Winding Refn has set cast and unveiled first look images. <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm10996873/\">Diaana Babnicova</a> will play the role of George, alongside <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11830110/\">Elliott Rose</a> as Julian, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm11538365/\">Kit Rakusen</a> as Dick, Flora Jacoby Richardson as Anne playing George’s cousins who come to stay at Kirrin Cottage. Joining the five are <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0322416/\">Jack Gleeson</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>) as Wentworth, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm2497049/\">Ann Akinjirin</a> (Moon Knight) as Fanny, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0484202/\">James Lance</a> (Ted Lasso) as <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm10473363/\">Quentin</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0703438/\">Diana Quick</a> (Father Brown) as Mrs Wentworth. The series is being co-produced for <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0607381/\">Zdf</a> and comes from Drive creator Winding Refn’s byNWR along with <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0684153/\">Moonage Pictures</a>. The show will be based on <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0090067/\">Enid Blyton</a>’s iconic 21 stories with filming set to take place shortly across the south west of the UK. <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1954464/\">Famous Five</a> is one of the highest-profile series to come out of the...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://deadline.com/2023/07/famous-five-nicholas-winding-refn-sets-cast-bbc-global-briefs-1235448299/\">See full article at Deadline Film + TV<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 2480,
        "maxWidth": 3748,
        "url": "https://m.media-amazon.com/images/M/MV5BMmNlMDZlNDktYjg0Yy00NjUzLTkwNDQtMmY0YTU3NDc5ODg2XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Nicholas Winding Refn’s ‘Famous Five’ Adaptation Sets Cast; BAFTA Film & TV Committees; Screen Australia Access Program; ‘All Quiet’ Composer Honored – Global Briefs",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://deadline.com/2023/07/famous-five-nicholas-winding-refn-sets-cast-bbc-global-briefs-1235448299/",
      "id": "ni64172290",
      "sourceName": "Deadline Film + TV"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64172134/?ref_=ttnw_art_plk",
          "id": "permalink-ni64172134",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64172134&ref_=ttnw_art_rpt",
          "id": "report-ni64172134",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/26/2023"
        },
        {
          "text": "by Kendall Myers"
        },
        {
          "href": "https://collider.com/game-of-thrones-best-line/",
          "text": "Collider.com",
          "type": "external"
        }
      ],
      "cardHtml": "Over its eight-season run, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> had many iconic quotes, each giving insight into a particular character or situation. Some are even praised for breaking the fourth wall, like Ramsay Bolton&#39;s (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3701064/\">Iwan Rheon</a>) haunting reminder, &quot;If you think this has a happy ending, you haven&#39;t been paying attention.&quot; After the much-hated series finale, these words seemed very fitting, but that only describes the ending. One line from the first season succinctly summarizes the entire show. Before the war even begins, Cersei Lannister (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0372176/\">Lena Headey</a>) tells <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0823247/\">Ned Stark</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000293/\">Sean Bean</a>), &quot;When you play the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">game of thrones</a>, you win, or you die. There is no middle ground.&quot; The honorable Ned may not heed this particular warning, but it rings true throughout the series.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://collider.com/game-of-thrones-best-line/\">See full article at Collider.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BYzhjZDM2YzctYmUzZi00YjlmLTgwM2EtYTM2YTg1MzhmODRkXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "This Is the One Line That Defines 'Game of Thrones'",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://collider.com/game-of-thrones-best-line/",
      "id": "ni64172134",
      "sourceName": "Collider.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64171865/?ref_=ttnw_art_plk",
          "id": "permalink-ni64171865",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64171865&ref_=ttnw_art_rpt",
          "id": "report-ni64171865",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/25/2023"
        },
        {
          "text": "by Isobel Pankhurst"
        },
        {
          "href": "https://www.cbr.com/game-of-thrones-main-character-age/",
          "text": "Comic Book Resources",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game Of Thrones</a> is one of the most popular fantasy series in TV history. While Season 8 may have ended disappointingly, the show&#39;s influence on the television medium is as remarkable as ever. With the first of many planned spinoffs well on its way, it seems that the world of Westeros is here for the long haul.<br/><br/>One question that viewers continue to ask about <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game Of Thrones</a> is just how old the characters were meant to be. The mature nature of the series required the show to age up several characters who were very young in the books. Some characters, however, got the opposite treatment. From young children to wizened sages, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> is full of characters that fans both love and hate.<br/><br/>Updated on July 24th, 2023 by Fawzia Khan: <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> will always remain one of the most talked-about show, especially with spin-offs like <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of The Dragon</a>,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cbr.com/game-of-thrones-main-character-age/\">See full article at Comic Book Resources<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BOTI0MTFhMzgtMGMxYy00Njg5LTg1YWEtMjUwM2YzZWFlNWMxXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Game of Thrones: Every Main Character's Age",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cbr.com/game-of-thrones-main-character-age/",
      "id": "ni64171865",
      "sourceName": "Comic Book Resources"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni63316768/?ref_=ttnw_art_plk",
          "id": "permalink-ni63316768",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni63316768&ref_=ttnw_art_rpt",
          "id": "report-ni63316768",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/25/2023"
        },
        {
          "text": "by TVSeriesFinale.com"
        },
        {
          "href": "https://tvseriesfinale.com/tv-show/hbo-tv-show-ratings/",
          "text": "TVSeriesFinale.com",
          "type": "external"
        }
      ],
      "cardHtml": "While HBO execs aren&#39;t tied to the ratings like regular commercial channels, they have to air programs that will keep viewers subscribed. Which of their shows will be cancelled or renewed? We&#39;ll have to wait and see.<br/><br/>Scripted HBO shows listed: <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4426738/\">Animals</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10234362/\">Avenue 5</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0069754/\">The Baby</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2891574/\">Ballers</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10814438/\">Betty</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3920596/\">Big Little Lies</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0979432/\">Boardwalk Empire</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3216586/\">The Brink</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8002604/\">Camping</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0434672/\">The Comeback</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5295524/\">Crashing</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0264235/\">Curb Your Enthusiasm</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4998350/\">The Deuce</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4304864/\">Divorce</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0866442/\">Eastbound &amp; Down</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8772296/\">Euphoria</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt7211618/\">Gentleman Jack</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2342652/\">Getting On</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1723816/\">Girls</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4406178/\">The Gilded Age</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2378794/\">Hello Ladies</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5923012/\">Here and Now</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6078096/\">High Maintenance</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5607976/\">His Dark Materials</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11204260/\">I May Destroy You</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0425118/\">I Know This Much Is True</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14954666/\">The Idol</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0835434/\">In Treatment</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt7671070/\">Industry</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5024912/\">Insecure</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13649314/\">Irma Vep</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3431720/\">Jonah from Tonga</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3581920/\">The Last of Us</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2699128/\">The Leftovers</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2581458/\">Looking</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6905686/\">Lovecraft Country</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10155688/\">Mare of Easttown</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5056958/\">Mosaic</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8304608/\">Mrs. Fletcher</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8697870/\">The Nevers</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt7157248/\">The New Pope</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1870479/\">The Newsroom</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2401256/\">The Night Of</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8550800/\">The Outsider</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0050051/\">Perry Mason</a>,...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://tvseriesfinale.com/tv-show/hbo-tv-show-ratings/\">See full article at TVSeriesFinale.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 66,
        "maxWidth": 88,
        "url": "https://m.media-amazon.com/images/M/MV5BM2QzNmE1MDMtNWZlNC00YzQxLTlhYTAtM2NjZjg1MzBjMDg3XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "HBO TV Show Ratings (updated 7/25/2023)",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://tvseriesfinale.com/tv-show/hbo-tv-show-ratings/",
      "id": "ni63316768",
      "sourceName": "TVSeriesFinale.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64171870/?ref_=ttnw_art_plk",
          "id": "permalink-ni64171870",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64171870&ref_=ttnw_art_rpt",
          "id": "report-ni64171870",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/25/2023"
        },
        {
          "text": "by Stephanie Watel"
        },
        {
          "href": "https://movieweb.com/george-rr-martins-deal-with-hbo-suspended-while-house-of-the-dragon-keeps-filming/",
          "text": "MovieWeb",
          "type": "external"
        }
      ],
      "cardHtml": "As the strike between the WGA/SAG-<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0324673/\">AFTRA</a> continues indefinitely with still no end in sight, countless film and television projects are in perpetual limbo across the country. Over at HBO, while its local productions have shuttered, its high fantasy wonder-hit <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House of the Dragon</a> has continued on schedule, mainly due to the fact that its actors and crew belong to U.K.&#39;s union called Equity. This puts the production beyond the jurisdiction of the strike, and per union rules actors are not permitted to protest in solidarity with the union of another country. <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R.R. Martin</a>, original author of the show&#39;s source content Fire and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13280054/\">Blood</a> as well as the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> series, has since voiced his full support of the strike. However, per a report from <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0177508/\">Collider</a>, he took to his personal blog once again recently and revealed that his ongoing five-year deal with HBO and...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://movieweb.com/george-rr-martins-deal-with-hbo-suspended-while-house-of-the-dragon-keeps-filming/\">See full article at MovieWeb<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 630,
        "maxWidth": 1200,
        "url": "https://m.media-amazon.com/images/M/MV5BNDE4NjY5NmItODgyMC00NTNhLWEwODUtN2FkZjMzMWVkYWY1XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "George R.R. Martin's Deal with HBO Suspended While House of the Dragon Keeps Filming",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://movieweb.com/george-rr-martins-deal-with-hbo-suspended-while-house-of-the-dragon-keeps-filming/",
      "id": "ni64171870",
      "sourceName": "MovieWeb"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64171842/?ref_=ttnw_art_plk",
          "id": "permalink-ni64171842",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64171842&ref_=ttnw_art_rpt",
          "id": "report-ni64171842",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/25/2023"
        },
        {
          "text": "by Marcello Massone"
        },
        {
          "href": "https://www.cbr.com/fast-x-blu-ray-digital-release-date-bonus-content/",
          "text": "Comic Book Resources",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5433140/\">Fast X</a>, the 10th film of the highly popular Fast and Furious franchise, is speeding its way onto Blu-ray after an impressive box-office run.<br/><br/><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0743251/\">Universal Pictures Home Entertainment</a> has officially revealed the home release dates for the summer blockbuster hit, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5433140/\">Fast X</a>, which has achieved a remarkable milestone of over $7 billion in global box office sales. Starring <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0004874/\">Vin Diesel</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0735442/\">Michelle Rodriguez</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0879085/\">Tyrese Gibson</a>, and Chris “Ludacris” Bridges, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5433140/\">Fast X</a> is a high-energy spectacle filled with full-throttle action and heart-pounding thrills.<br/><br/>Related: Vin Diesel Says <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0425005/\">Dwayne Johnson</a>&#39;s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt5433140/\">Fast X</a> Return Was &#39;No Easy Task&#39;<br/><br/>Joining the roster of iconic <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1013752/\">Fast &amp; Furious</a> stars are <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1078479/\">John Cena</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13146488/\">Peacemaker</a>), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm2812026/\">Nathalie Emmanuel</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0108287/\">Jordana Brewster</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0437646/\">Sung Kang</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm2207222/\">Scott Eastwood</a> (Pacific Rim Uprising), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm6403016/\">Daniela Melchior</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6334354/\">The Suicide Squad</a>), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm2024927/\">Alan Ritchson</a> (Reacher), alongside esteemed actors <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000545/\">Helen Mirren</a> (Barbie) and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0488953/\">Brie Larson</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4154664/\">Captain Marvel</a>).<br/><br/>The Fast and Furious franchise has been following Dominic Torretto...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cbr.com/fast-x-blu-ray-digital-release-date-bonus-content/\">See full article at Comic Book Resources<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 700,
        "maxWidth": 1400,
        "url": "https://m.media-amazon.com/images/M/MV5BNTk4NTAyNWEtMWU4NC00YmU0LTkyZmItYTZhYTE0MDI0OWIwXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Fast X Races Onto Blu-ray, Digital With Plenty of Bonus Content",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cbr.com/fast-x-blu-ray-digital-release-date-bonus-content/",
      "id": "ni64171842",
      "sourceName": "Comic Book Resources"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64171740/?ref_=ttnw_art_plk",
          "id": "permalink-ni64171740",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64171740&ref_=ttnw_art_rpt",
          "id": "report-ni64171740",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/25/2023"
        },
        {
          "text": "by Cody Hamman"
        },
        {
          "href": "https://www.joblo.com/rebel-moon-characters/",
          "text": "JoBlo.com",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0811583/\">Zack Snyder</a> is building a new cinematic universe with his two-film sci-fi epic <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14998742/\">Rebel Moon</a>, the first installment of which is scheduled to be released through the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0144901/\">Netflix</a> streaming service on December 22nd. With that date still five months away, Netflix is looking to build the hype by revealing information on the characters that populate <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14998742/\">Rebel Moon</a>. Images of several of the characters can be seen at the bottom of this article.<br/><br/>Snyder has always been open about the fact that he’s hoping “a massive IP and a universe that can be built out” from the foundation of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14998742/\">Rebel Moon</a>. He crafted the story for <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14998742/\">Rebel Moon</a> with 300 co-writer <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0426500/\">Kurt Johnstad</a>, and the pair wrote the screenplay with <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0993840/\">Army of the Dead</a> co-writer <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm8748334/\">Shay Hatten</a>. The events of the film, which draws inspiration from <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0047478/\">Seven Samurai</a>, are set in motion when a peaceful colony on the edge of the...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.joblo.com/rebel-moon-characters/\">See full article at JoBlo.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 683,
        "maxWidth": 1024,
        "url": "https://m.media-amazon.com/images/M/MV5BNjM0OTE5YzEtYjk0ZS00MWQ3LTk1NGEtMjI2ZWQ0MjEyNGU1XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "Rebel Moon: Netflix shares info on characters in Zack Snyder film",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.joblo.com/rebel-moon-characters/",
      "id": "ni64171740",
      "sourceName": "JoBlo.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64171699/?ref_=ttnw_art_plk",
          "id": "permalink-ni64171699",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64171699&ref_=ttnw_art_rpt",
          "id": "report-ni64171699",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/25/2023"
        },
        {
          "text": "by Seb Flatau"
        },
        {
          "href": "https://screenrant.com/most-important-tv-shows-all-time/",
          "text": "ScreenRant.com",
          "type": "external"
        }
      ],
      "cardHtml": "Streaming services have played a crucial role in the &quot;golden age of television,&quot; but they are not the only reason for the surge in quality content. TV shows like M*A*S*H, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0092925/\">Dragnet</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0052520/\">The Twilight Zone</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0060028/\">Star Trek</a>, and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0098904/\">Seinfeld</a> have demonstrated technical, commercial, and artistic innovations that shaped the modern television climate. <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0411008/\">Lost</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0141842/\">The Sopranos</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4574334/\">Stranger Things</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0096697/\">The Simpsons</a>, and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> have all made significant cultural impacts and are considered landmark shows in television history.<br/><br/>Throughout television’s long and storied history, a handful of TV shows have distinguished themselves as crucial to the development of the industry. It goes without saying that TV has undergone some massive shifts throughout the years. The ways people consume the medium and the tools available to those who make it are constantly progressing. For that reason, the present moment is commonly regarded as a “golden age of television” due...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://screenrant.com/most-important-tv-shows-all-time/\">See full article at ScreenRant.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 1000,
        "maxWidth": 2000,
        "url": "https://m.media-amazon.com/images/M/MV5BMDFiNzU2ZWUtNTg5Yi00OGY0LWFhMjctMDkyZjc3OWY5ZDQ4XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "10 Most Important TV Shows Of All Time",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://screenrant.com/most-important-tv-shows-all-time/",
      "id": "ni64171699",
      "sourceName": "ScreenRant.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64170798/?ref_=ttnw_art_plk",
          "id": "permalink-ni64170798",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64170798&ref_=ttnw_art_rpt",
          "id": "report-ni64170798",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/25/2023"
        },
        {
          "text": "by Max Goldbart"
        },
        {
          "href": "https://deadline.com/2023/07/sherwood-david-harewood-monica-dolan-season-2-james-graham-1235447149/",
          "text": "Deadline Film + TV",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm13541537/\">James Graham</a>’s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0921192/\">BBC</a> drama <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt13994572/\">Sherwood</a> has added more than a dozen Season 2 cast members including <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0362873/\">David Harewood</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0230826/\">Monica Dolan</a>.<br/><br/>One of the BBC’s most-watched drama series last year moves to the present day for its second season. <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1796960/\">Homeland</a> star Harewood and BAFTA-winner <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0230742/\">Dolan</a> are joined by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0512305/\">Robert Lindsay</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1156714/\">Sharlene Whyte</a> (Stephen, Small <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm14510261/\">Axe</a>), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0226820/\">Stephen Dillane</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11846996/\">Vigil</a>), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm4123351/\">Ria Zmitrowicz</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10369484/\">The Power</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt6835252/\">Three Girls</a>), Aisling Loftus (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14245846/\">The Midwich Cuckoos</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0063794/\">War and Peace</a>), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3016166/\">Robert Emms</a> (Andor, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm12369838/\">Chernobyl</a>), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm6635960/\">Michael Balogun</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt1830379/\">Top Boy</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10127546/\">The Lehman Trilogy</a>), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1180835/\">Christine Bottomley</a>(<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11694186/\">Domina</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8594510/\">Back To Life</a>), <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm7963638/\">Oliver Huntingdon</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt14538210/\">The Rising</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3428912/\">Happy Valley</a>) Jorden Myrie (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt17520694/\">Mood</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt16437278/\">The Strays</a>) and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm9053586/\">Conor Deane</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10590066/\">All Creatures Great &amp; Small</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt8110232/\">Newark</a>) and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm9915746/\">Bethany Asher</a> (<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0114938/\">Wild Bill</a>, Mobility).<br/><br/>Leads <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0607375/\">David Morrissey</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0544334/\">Lesley Manville</a> are reprising their roles and the second season is being directed by three-time BAFTA nominee <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1163237/\">Clio Barnard</a>, with <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt10228230/\">Quiz</a> scribe Graham penning the six episodes.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://deadline.com/2023/07/sherwood-david-harewood-monica-dolan-season-2-james-graham-1235447149/\">See full article at Deadline Film + TV<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 720,
        "maxWidth": 1280,
        "url": "https://m.media-amazon.com/images/M/MV5BNDE1MjA4YjQtZDk3MS00YmVlLThjMTgtZjU3YTY0YWNhNzA4XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "‘Sherwood’ Adds David Harewood, Monica Dolan & More Season 2 Cast",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://deadline.com/2023/07/sherwood-david-harewood-monica-dolan-season-2-james-graham-1235447149/",
      "id": "ni64170798",
      "sourceName": "Deadline Film + TV"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64170725/?ref_=ttnw_art_plk",
          "id": "permalink-ni64170725",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64170725&ref_=ttnw_art_rpt",
          "id": "report-ni64170725",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/25/2023"
        },
        {
          "text": "by Om Prakash Kaushal"
        },
        {
          "href": "https://dailyresearchplot.com/2023/07/25/when-is-the-abandons-netflix-series-coming/",
          "text": "https://dailyresearchplot.com/wp-content/uploads/2023/03/new-sam",
          "type": "external"
        }
      ],
      "cardHtml": "When Is The <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0144901/\">Netflix</a> Series <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt16280546/\">The Abandons</a> Coming? Well, with the Western genre experiencing an immense surge in popularity in recent years, it comes as no shock that even some of the world’s biggest stars have embraced this captivating genre.<br/><br/>The industry rather than relying on remakes of classic Westerns, has witnessed the emergence of a multitude of new television shows that have already earned their place among TV’s finest Western productions.<br/><br/>Acclaimed series like HBO’s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0475784/\">Westworld</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0088372/\">Hugo Blick</a>’s <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11771270/\">The English</a>, and the massively popular <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4236770/\">Yellowstone</a> franchise have spearheaded this Western renaissance, ushering in an era of significant success for stories set in the rugged frontier.<br/><br/>Hence, the excitement was palpable among fans of the genre when news broke in late 2022 about Netflix’s latest project, the officially ordered western series, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt16280546/\">The Abandons</a>, brought to life by the renowned <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1176676/\">Kurt Sutter</a>.<br/><br/>As time has passed and...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://dailyresearchplot.com/2023/07/25/when-is-the-abandons-netflix-series-coming/\">See full article at https://dailyresearchplot.com/wp-content/uploads/2023/03/new-sam<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Westworld (2016)",
        "maxHeight": 1280,
        "maxWidth": 864,
        "url": "https://m.media-amazon.com/images/M/MV5BZDg1OWRiMTktZDdiNy00NTZlLTg2Y2EtNWRiMTcxMGE5YTUxXkEyXkFqcGdeQXVyMTM2MDY0OTYx._V1_.jpg"
      },
      "cardText": "When Is The Abandons Netflix Series Coming?",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://dailyresearchplot.com/2023/07/25/when-is-the-abandons-netflix-series-coming/",
      "id": "ni64170725",
      "sourceName": "https://dailyresearchplot.com/wp-content/uploads/2023/03/new-sam"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64170640/?ref_=ttnw_art_plk",
          "id": "permalink-ni64170640",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64170640&ref_=ttnw_art_rpt",
          "id": "report-ni64170640",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/25/2023"
        },
        {
          "text": "by Amy K Brown"
        },
        {
          "href": "https://collider.com/best-game-of-thrones-storylines-reddit/",
          "text": "Collider.com",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> managed to keep its crown even after its bitter and controversial end in 2019. It remains one of the biggest shows in a generation, with (mostly) expert storytelling and show-stopping performances. Based on the <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R. R. Martin</a> series, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> ended up with an average viewership of 46 million by Season 8. Fans just had the first season of The House of the Dragon to keep them busy (Season 2 is currently in the works), but many still wait for the next book installment, which will pick up after some Season 5 events.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://collider.com/best-game-of-thrones-storylines-reddit/\">See full article at Collider.com<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 1000,
        "maxWidth": 2000,
        "url": "https://m.media-amazon.com/images/M/MV5BYTlkM2JkMTYtM2NhMC00NTUwLWE3MmMtZTlhYzllMGMzNGI0XkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "10 Best 'Game of Thrones' Storylines, According to Reddit",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://collider.com/best-game-of-thrones-storylines-reddit/",
      "id": "ni64170640",
      "sourceName": "Collider.com"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64170486/?ref_=ttnw_art_plk",
          "id": "permalink-ni64170486",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64170486&ref_=ttnw_art_rpt",
          "id": "report-ni64170486",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/24/2023"
        },
        {
          "text": "by Charlene Badasie"
        },
        {
          "href": "https://www.cbr.com/george-rr-martin-hbo-deal-suspended/",
          "text": "Comic Book Resources",
          "type": "external"
        }
      ],
      "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> author <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George Rr Martin</a> says his deal with HBO has been suspended for over a month amid the ongoing Writers Guild of America strike.<br/><br/>&quot;My overall deal with HBO was suspended on June 1,&quot; Martin wrote in his latest Not a Blog post. &quot;I still have plenty to do, of course. In that, I am one of the lucky ones. These strikes are not really about name writers or producers or showrunners, most of whom are fine. We&#39;re striking for the entry-level writers, the story editors, the students hoping to break in, the actor who has four lines, the guy working his first staff job who dreams of creating his own show one day, as I did back in the 80s,&quot; he continued.<br/><br/>Related: The <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a> Comics Are a Must-Read For Anyone Still Bitter Over The Show&#39;s Ending<br/><br/>Martin also revealed that all negotiations between the...<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://www.cbr.com/george-rr-martin-hbo-deal-suspended/\">See full article at Comic Book Resources<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 600,
        "maxWidth": 1200,
        "url": "https://m.media-amazon.com/images/M/MV5BOWE3YjM3MTQtNjQ3My00MDJkLThjYTktNzMyOGFiM2JjMTIzXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "HBO Suspends Deal With GoT Author George Rr Martin",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://www.cbr.com/george-rr-martin-hbo-deal-suspended/",
      "id": "ni64170486",
      "sourceName": "Comic Book Resources"
    },
    {
      "actionProps": [
        {
          "children": "Permalink",
          "href": "/news/ni64170356/?ref_=ttnw_art_plk",
          "id": "permalink-ni64170356",
          "label": "Permalink"
        },
        {
          "children": "Report this",
          "href": "https://www.imdb.com/newsdesk/help/report?deepLink=report_news&news_item=ni64170356&ref_=ttnw_art_rpt",
          "id": "report-ni64170356",
          "label": "Report this"
        }
      ],
      "bottomList": [
        {
          "text": "7/24/2023"
        },
        {
          "text": "by Aashna Shah"
        },
        {
          "href": "https://etcanada.com/news/1008383/george-r-r-martin-shocked-over-uk-laws-allowing-house-of-the-dragon-filming-amid-strike/",
          "text": "ET Canada",
          "type": "external"
        }
      ],
      "cardHtml": "Despite two Hollywood unions going on strike, HBO proceeded to film Season 2 of its popular series “The House of the Dragon.”<br/><br/>Read More: <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3592338/\">Emilia Clarke</a> Shares Why She ‘Just Can’t’ Watch ‘<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt11198330/\">House Of The Dragon</a>’: ‘It’s So <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0312209/\">Strange</a>’<br/><br/>This happened because the “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">Game of Thrones</a>” prequel scripts were finished prior to the Writers Guild of America’s strike starting on May 2. And unlike <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/company/co0375836/\">SAG-AFTRA</a>, which is now on strike, the performers in the TV show are members of a British actors union.<br/><br/>The explanations were provided by “<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt0944947/\">A Song of Ice and Fire</a>” author <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/\">George R.R. Martin</a>, who just updated his blog, “Not a Blog“, with information regarding the TV adaptation. He was open and honest about his thoughts on the “long and bitter” labour strikes that are presently causing the film and television industries to suffer.<br/><br/>“Honestly, I was shocked to hear that,” Martin wrote on his blog.<div data-reactroot=\"\"><a class=\"ipc-link ipc-link--base sc-c09843a2-0 iZUepX\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\" target=\"_blank\" rel=\"nofollow noopener\" href=\"https://etcanada.com/news/1008383/george-r-r-martin-shocked-over-uk-laws-allowing-house-of-the-dragon-filming-amid-strike/\">See full article at ET Canada<svg width=\"24\" height=\"24\" xmlns=\"http://www.w3.org/2000/svg\" class=\"ipc-icon ipc-icon--launch-inline ipc-icon--inline ipc-link__launch-icon\" viewBox=\"0 0 24 24\" fill=\"currentColor\" role=\"presentation\"><path d=\"M21.6 21.6H2.4V2.4h7.2V0H0v24h24v-9.6h-2.4v7.2zM14.4 0v2.4h4.8L7.195 14.49l2.4 2.4L21.6 4.8v4.8H24V0h-9.6z\"></path></svg></a></div>",
      "cardImage": {
        "caption": "Image",
        "maxHeight": 1280,
        "maxWidth": 1920,
        "url": "https://m.media-amazon.com/images/M/MV5BOTkxMDVhZmEtY2NkNS00ZmYyLWIzNWUtNGJjMDg4ZGYzMDhhXkEyXkFqcGdeQXVyMTE0MzQwMjgz._V1_.jpg"
      },
      "cardText": "George R.R. Martin ‘Shocked’ Over UK Laws Allowing ‘House Of The Dragon’ Filming Amid Strike",
      "cardTextLinkType": "external",
      "cardTextUrl": "https://etcanada.com/news/1008383/george-r-r-martin-shocked-over-uk-laws-allowing-house-of-the-dragon-filming-amid-strike/",
      "id": "ni64170356",
      "sourceName": "ET Canada"
    }
  ],
  "message": "Successful",
  "status": true
}



// trviva

const trviva=
{
  "data": [
    {
      "id": "uncategorized",
      "section": {
        "endCursor": "dHI0MTMyODQ0",
        "items": [
          {
            "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0322416/?ref_=tttrv_tr\">Jack Gleeson</a> (Joffrey Baratheon) received a letter from author <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/?ref_=tttrv_tr\">George R.R. Martin</a> after the show aired, stating: &quot;Congratulations on your marvelous performance. Everyone hates you!&quot;",
            "id": "tr2084620",
            "shareButtonProps": {
              "url": "?item=tr2084620"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 107,
              "itemConst": "tr2084620",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 6283
            }
          },
          {
            "cardHtml": "According to <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3229685/?ref_=tttrv_tr\">Kit Harington</a> (Jon Snow), his performance in the rejected pilot episode was so bad that the creators often jokingly threaten to release scenes of it on the internet if he complains too much.",
            "id": "tr4158652",
            "shareButtonProps": {
              "url": "?item=tr4158652"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 13,
              "itemConst": "tr4158652",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 988
            }
          },
          {
            "cardHtml": "Author <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/?ref_=tttrv_tr\">George R.R. Martin</a> was approached several times with offers to adapt his (still unfinished) book series &quot;A Song of Ice and Fire&quot; into a movie, but he rejected them all, as he thought his books were much too expansive to be made into a movie. He had purposely written them to be virtually unfilmable, and he also declined offers to adapt only certain storylines from the book. When <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1125275/?ref_=tttrv_tr\">David Benioff</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0918949/?ref_=tttrv_tr\">D.B. Weiss</a> told him that they wanted to make a series out of it, he asked them who they thought Jon Snow&#39;s mother could be. Satisfied with the answer, he agreed to sell the rights to the book. The two showrunners later admitted that they tricked HBO into greenlighting the series by convincing them that it was mostly about human drama and character interactions, and could therefore be produced relatively cheaply. They had correctly guessed that none of the studio executives had actually read all of the 4000 pages that Martin had written at the time, and that they had no idea of the expensive scenes that were to come in the future.",
            "id": "tr3566660",
            "shareButtonProps": {
              "url": "?item=tr3566660"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 14,
              "itemConst": "tr3566660",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 942
            }
          },
          {
            "cardHtml": "According to author <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/?ref_=tttrv_tr\">George R.R. Martin</a>, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=tttrv_tr\">Peter Dinklage</a> was the one and only choice to play Tyrion Lannister, and no other actors were auditioned. Dinklage has been nominated eight consecutive times (once for each season) for the Outstanding Supporting Actor in a Drama Series at the Emmys. He won for the first, fifth, seventh and eighth season, setting a new record for most wins in the Outstanding Supporting Actor category for the same role.",
            "id": "tr3230818",
            "shareButtonProps": {
              "url": "?item=tr3230818"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 20,
              "itemConst": "tr3230818",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 1176
            }
          },
          {
            "cardHtml": "When <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0597388/?ref_=tttrv_tr\">Jason Momoa</a> (Khal Drogo) first met <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3592338/?ref_=tttrv_tr\">Emilia Clarke</a> (Daenerys Targaryen) he rugby tackled her to the floor of the Belfast hotel yelling &quot;WIFEY&quot;.",
            "id": "tr4132844",
            "shareButtonProps": {
              "url": "?item=tr4132844"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 32,
              "itemConst": "tr4132844",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 1690
            }
          }
        ],
        "total": 164
      },
      "spoilerSection": {
        "endCursor": "dHIzNTQ4Nzgx",
        "items": [
          {
            "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/?ref_=tttrv_tr\">George R.R. Martin</a>&#39;s wife once said that she will leave him if he kills off Arya or Sansa.",
            "id": "tr4389409",
            "shareButtonProps": {
              "url": "?item=tr4389409"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 12,
              "itemConst": "tr4389409",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 1265
            }
          },
          {
            "cardHtml": "<a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/?ref_=tttrv_tr\">George R.R. Martin</a> stated that the infamous &quot;Red Wedding&quot; was the hardest chapter for him to write in &quot;A Storm of Swords&quot;. He was so emotionally attached to the characters that he wrote the rest of the book first, then that chapter last. Executive Producers <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm1125275/?ref_=tttrv_tr\">David Benioff</a> and <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0918949/?ref_=tttrv_tr\">D.B. Weiss</a>, upon reading it, declared it was one of the major reasons they decided to option the books for a television series. Their dramatization differs from the book in a few details, most notably that Robb&#39;s wife is not present at the wedding, nor is she killed. Whether she is pregnant is unknown.",
            "id": "tr1942248",
            "shareButtonProps": {
              "url": "?item=tr1942248"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 6,
              "itemConst": "tr1942248",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 786
            }
          },
          {
            "cardHtml": "After filming his death scene, <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000293/?ref_=tttrv_tr\">Sean Bean</a> played football with his replica head.",
            "id": "tr2408964",
            "shareButtonProps": {
              "url": "?item=tr2408964"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 8,
              "itemConst": "tr2408964",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 806
            }
          },
          {
            "cardHtml": "Series author <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0552333/?ref_=tttrv_tr\">George R.R. Martin</a> reported on his blog that after the filming of the episode in which Sansa&#39;s direwolf Lady is executed, the dog that played Lady, a Northern Inuit named Zunni, was adopted by <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3849842/?ref_=tttrv_tr\">Sophie Turner</a> (Sansa).",
            "id": "tr1709800",
            "shareButtonProps": {
              "url": "?item=tr1709800"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 10,
              "itemConst": "tr1709800",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 743
            }
          },
          {
            "cardHtml": "The 6&#39;3&quot; <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3729225/?ref_=tttrv_tr\">Gwendoline Christie</a> (Brienne of Tarth) has stated that the most gruelling scene she ever had to play in the series was in season four, episode ten, &quot;The Children&quot;, when she fought sword-to-sword with 6&#39;6&quot; <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0564920/?ref_=tttrv_tr\">Rory McCann</a> (Sandor &quot;The Hound&quot; Clegane). She spent two months training, three to four days a week, with swordmaster <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0806905/?ref_=tttrv_tr\">C.C. Smiff</a> just to build up the required stamina for her fight scene.",
            "id": "tr3548781",
            "shareButtonProps": {
              "url": "?item=tr3548781"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 5,
              "itemConst": "tr3548781",
              "itemType": "TitleTrivia",
              "pageConst": "tt0944947",
              "refTagPrefix": "tttrv",
              "upVotes": 461
            }
          }
        ],
        "total": 45
      }
    }
  ],
  "message": "Successful",
  "status": true
}


// Movies shooting Location 

const shottlocatiion={
  "data": [
    {
      "id": "flmg_locations",
      "name": "Filming locations",
      "section": {
        "endCursor": "bGMwNDQ5NTkw",
        "items": [
          {
            "cardText": "Split, Split-Dalmatia County, Croatia",
            "cardTextUrl": "/search/title/?locations=Split%2C%20Split-Dalmatia%20County%2C%20Croatia&ref_=ttloc_loc_0",
            "id": "lc0820830",
            "shareButtonProps": {
              "url": "?item=lc0820830"
            },
            "userVotingProps": {
              "downVotes": 10,
              "itemConst": "lc0820830",
              "itemType": "FilmingLocation",
              "pageConst": "tt0944947",
              "refTagPrefix": "ttloc",
              "upVotes": 358
            }
          },
          {
            "cardText": "Vrsno, Sibenik, Croatia",
            "cardTextUrl": "/search/title/?locations=Vrsno%2C%20Sibenik%2C%20Croatia&ref_=ttloc_loc_1",
            "id": "lc0820831",
            "shareButtonProps": {
              "url": "?item=lc0820831"
            },
            "userVotingProps": {
              "downVotes": 7,
              "itemConst": "lc0820831",
              "itemType": "FilmingLocation",
              "pageConst": "tt0944947",
              "refTagPrefix": "ttloc",
              "upVotes": 208
            }
          },
          {
            "cardText": "Dubrovnik, Croatia",
            "cardTextUrl": "/search/title/?locations=Dubrovnik%2C%20Croatia&ref_=ttloc_loc_2",
            "id": "lc0449596",
            "shareButtonProps": {
              "url": "?item=lc0449596"
            },
            "userVotingProps": {
              "downVotes": 20,
              "itemConst": "lc0449596",
              "itemType": "FilmingLocation",
              "pageConst": "tt0944947",
              "refTagPrefix": "ttloc",
              "upVotes": 412
            }
          },
          {
            "cardText": "Ouarzazate, Morocco",
            "cardTextUrl": "/search/title/?locations=Ouarzazate%2C%20Morocco&ref_=ttloc_loc_3",
            "id": "lc0449602",
            "shareButtonProps": {
              "url": "?item=lc0449602"
            },
            "userVotingProps": {
              "downVotes": 7,
              "itemConst": "lc0449602",
              "itemType": "FilmingLocation",
              "pageConst": "tt0944947",
              "refTagPrefix": "ttloc",
              "upVotes": 193
            }
          },
          {
            "attributes": "CLA Studios, Ouarzazate, Morocco",
            "cardText": "Atlas Corporation Studios, Ouarzazate, Morocco",
            "cardTextUrl": "/search/title/?locations=Atlas%20Corporation%20Studios%2C%20Ouarzazate%2C%20Morocco&ref_=ttloc_loc_4",
            "id": "lc0449590",
            "shareButtonProps": {
              "url": "?item=lc0449590"
            },
            "userVotingProps": {
              "downVotes": 3,
              "itemConst": "lc0449590",
              "itemType": "FilmingLocation",
              "pageConst": "tt0944947",
              "refTagPrefix": "ttloc",
              "upVotes": 108
            }
          }
        ],
        "total": 63
      }
    },
    {
      "id": "flmg_dates",
      "name": "Filming dates",
      "section": {
        "endCursor": "NA==",
        "items": [
          {
            "cardHtml": "Oct 24, 2009 - Nov 19, 2009",
            "id": "Oct 24, 2009 - Nov 19, 2009"
          },
          {
            "cardHtml": "Jul 26, 2010",
            "id": "Jul 26, 2010"
          },
          {
            "cardHtml": "Nov 2011",
            "id": "Nov 2011"
          },
          {
            "cardHtml": "Jul 2012 - Nov 24, 2012",
            "id": "Jul 2012 - Nov 24, 2012"
          },
          {
            "cardHtml": "Jul 8, 2013 - Nov 21, 2013",
            "id": "Jul 8, 2013 - Nov 21, 2013"
          }
        ],
        "total": 9
      }
    },
    {
      "id": "prod_dates",
      "name": "Production dates",
      "section": {
        "endCursor": null,
        "items": [],
        "total": 0
      }
    }
  ],
  "message": "Successful",
  "status": true
}


// Goofs

const goofs={
  "data": [
    {
      "id": "continuity",
      "name": "Continuity",
      "section": {
        "endCursor": "Z2Y0Nzk2NzAx",
        "items": [
          {
            "cardHtml": "(at around 59 mins) Peter and his classmates are identified as being 16. In <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt2250912/?ref_=ttgf_gf\">Spider-Man: Homecoming (2017)</a>, Peter tells Tony Stark that he is 15. That movie takes place two months after the events of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3498820/?ref_=ttgf_gf\">Captain America: Civil War (2016)</a>, which takes place two years before <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4154756/?ref_=ttgf_gf\">Avengers: Infinity War (2018)</a>. If Peter was 15 in Civil War/Homecoming, he would have been 17 in Infinity War. Far From Home takes place eight months after the events of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4154796/?ref_=ttgf_gf\">Avengers: Endgame (2019)</a>, meaning that Peter and his classmates would be closer to 18.",
            "id": "gf4688233",
            "shareButtonProps": {
              "url": "?item=gf4688233"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 7,
              "itemConst": "gf4688233",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 61
            }
          },
          {
            "cardHtml": "(at around 1h 50 mins) When MJ finds Peter on Tower Bridge, they share a long hug. Peter&#39;s face is bleeding and in the wide shots the blood transfer to MJ&#39;s jacket, left shoulder, can be seen but in the close up shots the blood is absent.",
            "id": "gf4619408",
            "shareButtonProps": {
              "url": "?item=gf4619408"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 9,
              "itemConst": "gf4619408",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 41
            }
          },
          {
            "cardHtml": "During the Tower Bridge battle, there are several very brief shots that show that there are no cars on the bridge.",
            "id": "gf4720351",
            "shareButtonProps": {
              "url": "?item=gf4720351"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 0,
              "itemConst": "gf4720351",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 8
            }
          },
          {
            "cardHtml": "(at around 21 mins) During the attack in Venice, Peter gets soaked when the water pushes him against the railing. Moments later, when he retaliates against the water elemental, his clothes are completely dry and his hair is slightly damp.",
            "id": "gf4642239",
            "shareButtonProps": {
              "url": "?item=gf4642239"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 5,
              "itemConst": "gf4642239",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 17
            }
          },
          {
            "cardHtml": "(at around 1h 27 mins) When Happy and Peter are on the plane above the tulip field, the degree to which Peter&#39;s eyes are inflamed from crying varies widely from shot to shot. His eyes are very red and irritated while sitting, then when he stands, they&#39;re less inflamed, then a shot later, they&#39;re redder. When he goes to build his new suit, the inflammation is completely gone.",
            "id": "gf4796701",
            "shareButtonProps": {
              "url": "?item=gf4796701"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 3,
              "itemConst": "gf4796701",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 11
            }
          }
        ],
        "total": 6
      },
      "spoilerSection": {
        "endCursor": null,
        "items": [],
        "total": 0
      }
    },
    {
      "id": "factual_error",
      "name": "Factual errors",
      "section": {
        "endCursor": "Z2Y0NjM1MDYz",
        "items": [
          {
            "cardHtml": "(at around 35 mins) Based on the shots in the scenes both prior and after, the students are staying at a hotel on the main island of Venice. When they depart, a bus picks them up. However, in reality, motor vehicles are not allowed in the city, especially not buses or coaches. It would be impossible for them to navigate the winding streets or canals.",
            "id": "gf4613215",
            "shareButtonProps": {
              "url": "?item=gf4613215"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 10,
              "itemConst": "gf4613215",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 123
            }
          },
          {
            "cardHtml": "(at around 32 mins) When Mysterio is showing the hologram of his Earth falling to the Fire Elemental, Earth erodes and the particles fall &#39;down&#39;. There is no &#39;down&#39; in space.",
            "id": "gf4786972",
            "shareButtonProps": {
              "url": "?item=gf4786972"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 8,
              "itemConst": "gf4786972",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 29
            }
          },
          {
            "cardHtml": "(at around 37 mins) During the stop in Austria, the price for gasoline at the gas station is below 1 EUR, for one type even below 50 Cents. This is by far lower than any gasoline price in Austria in the last decade and below 50 Cents is even impossible due to the taxes on gasoline.",
            "id": "gf4681989",
            "shareButtonProps": {
              "url": "?item=gf4681989"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 10,
              "itemConst": "gf4681989",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 32
            }
          },
          {
            "cardHtml": "(at around 1h 40 mins) The Guards at the Tower of London are shown firing standard configuration assault rifles, probably M16&#39;s, but the standard issue service rifle in the UK is the SA80, which has a distinctive bullpup configuration.",
            "id": "gf4758611",
            "shareButtonProps": {
              "url": "?item=gf4758611"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 5,
              "itemConst": "gf4758611",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 19
            }
          },
          {
            "cardHtml": "(at around 1h 15 mins) The train from Prague to Berlin is a RailJet Express, which doesn&#39;t go with a locomotive we see in the movie. RailJet locomotives are newer types, with a painting that fits the rest of the train. The one in the movie has the classic Czech Railways painting, not used on RailJet trains.",
            "id": "gf4635063",
            "shareButtonProps": {
              "url": "?item=gf4635063"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 6,
              "itemConst": "gf4635063",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 21
            }
          }
        ],
        "total": 10
      },
      "spoilerSection": {
        "endCursor": "Z2Y0ODI1MTEy",
        "items": [
          {
            "cardHtml": "The Stark drones shown in the movie are only armed with machine guns and when Peter attacks them, they turn out to be quite fragile. Therefore, they couldn&#39;t destroy buildings.",
            "id": "gf6077041",
            "shareButtonProps": {
              "url": "?item=gf6077041"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 1,
              "itemConst": "gf6077041",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 4
            }
          },
          {
            "cardHtml": "(at around 1h 21 mins) After Mysterio is shot in Berlin, you can see a crane truck in the background with a company logo and a phone number on it. The number (minus country and city code) is only four digits long which is virtually impossible in a city like Berlin.",
            "id": "gf4825112",
            "shareButtonProps": {
              "url": "?item=gf4825112"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 6,
              "itemConst": "gf4825112",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 5
            }
          }
        ],
        "total": 2
      }
    },
    {
      "id": "not_a_goof",
      "name": "Incorrectly regarded as goofs",
      "section": {
        "endCursor": "Z2Y0NjIxNTIx",
        "items": [
          {
            "cardHtml": "The Dutch village of &#39;Broek op Langedijk&#39; is actually the courtyard of a Prague restaurant, which explains the village&#39;s typical Central European style of architecture. The actual village of Broek op Langedijk is located just north of Amsterdam and is known for the many agricultural canals that intersect the village.",
            "id": "gf4639839",
            "shareButtonProps": {
              "url": "?item=gf4639839"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 5,
              "itemConst": "gf4639839",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 39
            }
          },
          {
            "cardHtml": "One of the ongoing jokes throughout the movie is Brad Davis wasn&#39;t blipped, so he&#39;s much more developed and athletic than someone like Peter Parker. But this would mean he&#39;s aged five years. If he&#39;s aged five years, he would have already graduated from high school; high school is only four years in the United States. The &quot;undoing of the blip&quot; shows that school was, indeed, going while the others were blipped out of existence. However, if Brad was not in high school when the Snap occurred, but was in middle school, five years later he would be a classmate of Peter Parker, Ned, Betty, MJ, and the rest as depicted in the film.",
            "id": "gf4710039",
            "shareButtonProps": {
              "url": "?item=gf4710039"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 14,
              "itemConst": "gf4710039",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 45
            }
          },
          {
            "cardHtml": "(at around 57 mins) Peter says he is under 21 when Beck offers him a drink. Based on his age during <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3498820/?ref_=ttgf_gf\">Captain America: Civil War (2016)</a> he should be 17 or 18 now. The legal drinking age in the Czech Republic (and most other EU member states) is 18.",
            "id": "gf4621521",
            "shareButtonProps": {
              "url": "?item=gf4621521"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 71,
              "itemConst": "gf4621521",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 60
            }
          }
        ],
        "total": 3
      },
      "spoilerSection": {
        "endCursor": "Z2Y0ODA3Njcx",
        "items": [
          {
            "cardHtml": "Mysterio&#39;s plan about being the greatest superhero ever would fall apart at the first real enemy. He would have nowhere to hide the drones, if his foe is not a hologram. This merely proves that Quentin Beck is in fact unstable--the reason Stark had fired him in the first place.",
            "id": "gf4636874",
            "shareButtonProps": {
              "url": "?item=gf4636874"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 17,
              "itemConst": "gf4636874",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 60
            }
          },
          {
            "cardHtml": "(at around 1h) When Peter gives the glasses to Beck, he has to go through a transfer routine with EDITH -- however, when Beck gives them back on the bridge (at around 1h 45 mins), Peter just puts them on and EDITH responds without any required transfer protocol. This is because Peter had already been authorized to access EDITH, so no new transfer protocol should be necessary.",
            "id": "gf4634139",
            "shareButtonProps": {
              "url": "?item=gf4634139"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 33,
              "itemConst": "gf4634139",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 72
            }
          },
          {
            "cardHtml": "(at around 28 mins) At the beginning of the movie, Nick Fury tells Peter that&#39;s it&#39;s great to finally meet Spider-Man. However, they were both at Tony Stark&#39;s funeral at the end of <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt4154796/?ref_=ttgf_gf\">Avengers: Endgame (2019)</a>. The very next line was &quot;I saw you at the funeral but I didn&#39;t think it was the time to exchange numbers&quot; making this the first meeting.",
            "id": "gf4742738",
            "shareButtonProps": {
              "url": "?item=gf4742738"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 23,
              "itemConst": "gf4742738",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 23
            }
          },
          {
            "cardHtml": "(at around 1h 40 mins) During the Tower of London sequences as the drones converge on Happy and Peter&#39;s classmates, Happy yells out his confession: &quot;I&#39;m in love with Spider-Man&#39;s aunt!&quot; But he was near Peter&#39;s classmates, including Flash, who don&#39;t know Peter is Spider-Man, effectively revealing Peter&#39;s secret identity. He should have said &quot;I&#39;m in love with Peter Parker&#39;s aunt!&quot; instead.",
            "id": "gf4807671",
            "shareButtonProps": {
              "url": "?item=gf4807671"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 23,
              "itemConst": "gf4807671",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 21
            }
          }
        ],
        "total": 4
      }
    },
    {
      "id": "revealing_mistake",
      "name": "Revealing mistakes",
      "section": {
        "endCursor": "Z2Y0NzI5MjY2",
        "items": [
          {
            "cardHtml": "The party visit Prague and elect to view the &quot;Carnival of Lights&quot;. This takes place in October. When Happy rescues Peter from the Netherlands, the tulips are in full bloom. Tulip season lasts from March to May. And the trip begins just after the school year ends in New York City, which is the last Friday in June, placing these events in early July.",
            "id": "gf4749083",
            "shareButtonProps": {
              "url": "?item=gf4749083"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 2,
              "itemConst": "gf4749083",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 36
            }
          },
          {
            "cardHtml": "(at around 1h 27 mins) Happy lands the jet in the tulip field and hovers over it for 15 minutes, according to his own words. As the jet flies away, however, the field is absolutely intact. Not one single spec of dust or tulip has moved out of place.",
            "id": "gf4723166",
            "shareButtonProps": {
              "url": "?item=gf4723166"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 4,
              "itemConst": "gf4723166",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 21
            }
          },
          {
            "cardHtml": "(at around 1h 16 mins) When Peter arrives in Berlin and jumps from the train, people look up... but in various directions, not directly at him.",
            "id": "gf4725984",
            "shareButtonProps": {
              "url": "?item=gf4725984"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 1,
              "itemConst": "gf4725984",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 10
            }
          },
          {
            "cardHtml": "At 1:26: Happy is suturing Peter&#39;s back with a &#39;running stitch&#39; but then Peter gets up without letting Happy finish the stitch and cut the threat; yet the suture material and needle is not hanging from Peter&#39;s back or in Happy&#39;s hands.",
            "id": "gf6065212",
            "shareButtonProps": {
              "url": "?item=gf6065212"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 0,
              "itemConst": "gf6065212",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 3
            }
          },
          {
            "cardHtml": "(at around 1h 25 mins) As Happy and Peter are in the cabin of the private jet leaving the Netherlands, Happy is shown stitching Peter&#39;s right, rear, shoulder. Although he makes the right hand movements, Happy holds no needle, and no string is seen leading from his fingertips to Peter&#39;s shoulder.",
            "id": "gf4729266",
            "shareButtonProps": {
              "url": "?item=gf4729266"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 7,
              "itemConst": "gf4729266",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 11
            }
          }
        ],
        "total": 5
      },
      "spoilerSection": {
        "endCursor": null,
        "items": [],
        "total": 0
      }
    },
    {
      "id": "miscellaneous",
      "name": "Miscellaneous",
      "section": {
        "endCursor": "Z2Y2ODM5NTc5",
        "items": [
          {
            "cardHtml": "When Peter and MJ are on the tower bridge, there is a car on fire next to them but the license plate isn&#39;t in the correct format although upside down.",
            "id": "gf6839579",
            "shareButtonProps": {
              "url": "?item=gf6839579"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 0,
              "itemConst": "gf6839579",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 0
            }
          }
        ],
        "total": 1
      },
      "spoilerSection": {
        "endCursor": "Z2Y2MDI3OTA5",
        "items": [
          {
            "cardHtml": "On multiple occasions after Mysterio gets access to EDITH, the drones obey him without commands. He neither uses the control device on his arm, nor a verbal command.",
            "id": "gf6027909",
            "shareButtonProps": {
              "url": "?item=gf6027909"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 1,
              "itemConst": "gf6027909",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 1
            }
          }
        ],
        "total": 1
      }
    },
    {
      "id": "audio_visual_unsynchronized",
      "name": "Audio/visual unsynchronised",
      "section": {
        "endCursor": "Z2Y0NzMyNjk4",
        "items": [
          {
            "cardHtml": "This film succumbs to the now very tired goof of hand guns making metallic clickety noises as they are raised. Apparently sound people believe the audience needs to hear this and is supposedly the sound of a safety being removed. Except, the hand guns making the sounds are Glocks which have no external or manual safeties. They do not make any noise.",
            "id": "gf4616280",
            "shareButtonProps": {
              "url": "?item=gf4616280"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 52,
              "itemConst": "gf4616280",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 76
            }
          },
          {
            "cardHtml": "(at around 2h 5 mins) All the S.H.I.E.L.D. cars (product placement Audis) have a futuristic electric whirring sound when driving. But the one in the post credits scene has been made to sound like it has a regular internal combustion engine.",
            "id": "gf4732698",
            "shareButtonProps": {
              "url": "?item=gf4732698"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 12,
              "itemConst": "gf4732698",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 13
            }
          }
        ],
        "total": 2
      },
      "spoilerSection": {
        "endCursor": null,
        "items": [],
        "total": 0
      }
    },
    {
      "id": "error_in_geography",
      "name": "Errors in geography",
      "section": {
        "endCursor": "Z2Y1NzQzMjA4",
        "items": [
          {
            "cardHtml": "(at around 1h 40 mins) When Happy and the school group run &quot;into the Crown Jewels vault&quot; they are actually running into the White Tower, not the Crown Jewels vault which is actually in a completely separate building within the Tower of London.",
            "id": "gf5038757",
            "shareButtonProps": {
              "url": "?item=gf5038757"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 1,
              "itemConst": "gf5038757",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 21
            }
          },
          {
            "cardHtml": "(at around 1h 30 mins) When the Stark Jet enters the UK, the caption states the Dorset coastline. Flying from Amsterdam to London you would cross the eastern coast of England, entering over the coast of Essex but the Dorset Chalk Cliffs are on the South West coastline which is 160 miles away.",
            "id": "gf4611040",
            "shareButtonProps": {
              "url": "?item=gf4611040"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 24,
              "itemConst": "gf4611040",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 103
            }
          },
          {
            "cardHtml": "(at around 56 mins) Fury says that he and Maria Hill will travel to the Europol headquarters in Berlin, Germany. However, it is actually located in The Hague, Netherlands (although it could have been moved during the Blip for unstated reasons).",
            "id": "gf4629022",
            "shareButtonProps": {
              "url": "?item=gf4629022"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 10,
              "itemConst": "gf4629022",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 53
            }
          },
          {
            "cardHtml": "(at around 15 mins) Security guards in Italian airports don&#39;t carry long guns or wear uniforms that look like they are from the USSR.",
            "id": "gf4619874",
            "shareButtonProps": {
              "url": "?item=gf4619874"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 16,
              "itemConst": "gf4619874",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 49
            }
          },
          {
            "cardHtml": "How does Peter end up in a cell in Broek op Langedijk after passing out on a train in Germany? First of all, it would make more sense to be found by the Dutch police somewhere far closer to the Dutch-German border, where some international train connections exist. Second, Broek op Langedijk itself doesn&#39;t have a train station. Two nearby towns do have train stations, but why not incarcerate him there then?",
            "id": "gf5743208",
            "shareButtonProps": {
              "url": "?item=gf5743208"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 1,
              "itemConst": "gf5743208",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 10
            }
          }
        ],
        "total": 12
      },
      "spoilerSection": {
        "endCursor": null,
        "items": [],
        "total": 0
      }
    },
    {
      "id": "plot_hole",
      "name": "Plot holes",
      "section": {
        "endCursor": "Z2Y2MDY1MjEz",
        "items": [
          {
            "cardHtml": "EDITH was created by Tony Stark, which raises the question why the defense technology wasn&#39;t used in the final battle of Endgame.",
            "id": "gf5418310",
            "shareButtonProps": {
              "url": "?item=gf5418310"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 2,
              "itemConst": "gf5418310",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 21
            }
          },
          {
            "cardHtml": "An illusionary storm (such as the one in London) would not generate a wind that blows debris around and causes flags to vigorously flap.",
            "id": "gf5292488",
            "shareButtonProps": {
              "url": "?item=gf5292488"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 4,
              "itemConst": "gf5292488",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 19
            }
          },
          {
            "cardHtml": "The EDITH glasses activate instantly when Peter puts them on for the first time on the bus, showing data of everyone he sees. This, however, doesn&#39;t happen later when he drinks with Mysterio in the Prague pub.",
            "id": "gf5418309",
            "shareButtonProps": {
              "url": "?item=gf5418309"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 5,
              "itemConst": "gf5418309",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 11
            }
          },
          {
            "cardHtml": "The movie makes a big deal out of Mysterio and the Daily Bugle revealing the secret identity of Spider-man to be Peter Parker. However the next scene reveals that Nick Fury was being impersonated by a shape-shifting alien skrull, taking orders from the real Nick Fury.<br/><br/>Since Fury had enough interest in Spider-man to associate and mentor him. Fury would keep track of his protegee&#39;s action far beyond London, and would had known about the identity leak, shortly after. Since he would want to protect Parker to keep him as a potential ally, and has 2 shape-shifting skrull aliens, that could help to do a video with both Parker and Spider-man, &quot;visually at the same place&quot;. A solution to the cliffhanger happens a second after it was introduced, rendering it null and void.",
            "id": "gf5575506",
            "shareButtonProps": {
              "url": "?item=gf5575506"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 12,
              "itemConst": "gf5575506",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 14
            }
          },
          {
            "cardHtml": "At 1:32: At his command, E.D.I.T.H. is showing Mysterio the &quot;loose ends&quot; (three students and two S.H.I.E.L.D. personnel are shown) but not Peter Parker.",
            "id": "gf6065213",
            "shareButtonProps": {
              "url": "?item=gf6065213"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 2,
              "itemConst": "gf6065213",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 1
            }
          }
        ],
        "total": 6
      },
      "spoilerSection": {
        "endCursor": "Z2Y0NjE5NzQ3",
        "items": [
          {
            "cardHtml": "(at around 1h 55 mins) The final twist about Peter&#39;s identity is possible only if SHIELD kept Mysterio&#39;s activities a secret. SHIELD, or the Skrulls who impersonate them have no reason to do so, especially as Peter sabotaged the hologram trick of Mysterio, and that certainly went viral in the age of smartphones.",
            "id": "gf4632714",
            "shareButtonProps": {
              "url": "?item=gf4632714"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 9,
              "itemConst": "gf4632714",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 36
            }
          },
          {
            "cardHtml": "A major plot point is that Mysterio and his crew use holographic projectors mounted on their drones to generate their illusions. Once they hijack the Stark drones with the help of EDITH, they announce that they can now generate a much bigger illusion. The problem is, the Stark drones come straight from the satellite to London, with no stops along the way to add the projectors. The drones, by themselves, cannot project illusions. The addition of thousands of new drones will not help create an even larger illusion.",
            "id": "gf4754417",
            "shareButtonProps": {
              "url": "?item=gf4754417"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 8,
              "itemConst": "gf4754417",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 29
            }
          },
          {
            "cardHtml": "(at around 21 mins) The drones we see in the movie wouldn&#39;t be able to generate a water splash like the one that hits Peter in the battle in Venice.",
            "id": "gf4715752",
            "shareButtonProps": {
              "url": "?item=gf4715752"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 17,
              "itemConst": "gf4715752",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 31
            }
          },
          {
            "cardHtml": "(at around 33 mins) Nick Fury mentions that Dr. Strange is unavailable when Peter asks about him. However, in <a class=\"ipc-md-link ipc-md-link--entity\" href=\"/title/tt3501632/?ref_=ttgf_gf\">Thor: Ragnarok (2017)</a>, Strange makes it clear that inter-dimensional crises are his top priority - surely the Elementals would be relevant enough for Strange to at least consider investigating. Perhaps Strange did investigate, and discovered there was nothing inter-dimensional about this - in which case Mysterio&#39;s fraud would have fallen apart and we would not have this movie.",
            "id": "gf4664824",
            "shareButtonProps": {
              "url": "?item=gf4664824"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 22,
              "itemConst": "gf4664824",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 37
            }
          },
          {
            "cardHtml": "The main weapon used against Spider-Man are drones with projectors. The technology uses light to project an image. Light isn&#39;t a solid, so even if it projected a shape, you would be able to see inside it to see the drones. Spider-Man goes inside the image at one stage and he can see the drones in a battle scene, again suggesting the image has a solid surface you cannot see through with an inside and an outside.\nLight just doesn&#39;t work like that. It isn&#39;t a solid, and has to be projected onto a solid to see it being reflected (like a movie screen) or refracted (like a rainbow). But even rainbows are transparent.",
            "id": "gf4619747",
            "shareButtonProps": {
              "url": "?item=gf4619747"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 73,
              "itemConst": "gf4619747",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 62
            }
          }
        ],
        "total": 6
      }
    },
    {
      "id": "character_error",
      "name": "Character error",
      "section": {
        "endCursor": "Z2Y1MzE5Mjk1",
        "items": [
          {
            "cardHtml": "(at around 1h 16 mins) When Peter jumps from the train in Berlin, he lands next to a woman. She screams &quot;Nacht Monkey&quot; and runs away, but the literal translation of &quot;Night Monkey&quot; would be &quot;Nacht-Affe&quot;. It makes no sense she would translate just half of the name (or even translate it at all). After all, Spider-Man is named Spider-Man in Germany too.",
            "id": "gf4725985",
            "shareButtonProps": {
              "url": "?item=gf4725985"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 14,
              "itemConst": "gf4725985",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 52
            }
          },
          {
            "cardHtml": "In the crown jewels vault when MJ first holds the mace, it is extremely heavy and falls to the ground. Later when the battle is over, she runs out of the vault and all the way to Peter carrying the same mace as if it weighs only a couple pounds.",
            "id": "gf5319295",
            "shareButtonProps": {
              "url": "?item=gf5319295"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 6,
              "itemConst": "gf5319295",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 10
            }
          }
        ],
        "total": 2
      },
      "spoilerSection": {
        "endCursor": "Z2Y0NzE1NzUx",
        "items": [
          {
            "cardHtml": "(at around 1h 55 mins) The swinging date at the end of the film is a huge risk of giving away Spider-Man&#39;s secret identity, as at that point, MJ is known to be the girlfriend of Peter Parker.",
            "id": "gf4715751",
            "shareButtonProps": {
              "url": "?item=gf4715751"
            },
            "shouldExpandHtmlContent": true,
            "userVotingProps": {
              "downVotes": 17,
              "itemConst": "gf4715751",
              "itemType": "Goof",
              "pageConst": "tt6320628",
              "refTagPrefix": "ttgf",
              "upVotes": 42
            }
          }
        ],
        "total": 1
      }
    }
  ],
  "message": "Successful",
  "status": true
}



// Quotes Optional Data


const Quotes={
  "data": {
    "endCursor": "cXQ0NTU4MjQz",
    "items": [
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0001097/?ref_=ttqu_qu\">Tywin Lannister</a>: Any man who must say &quot;I am the king&quot; is no true king.</li></ul>",
        "id": "qt3089613",
        "shareButtonProps": {
          "url": "?item=qt3089613"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 5,
          "itemConst": "qt3089613",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 652
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0001097/?ref_=ttqu_qu\">Tywin Lannister</a>: A lion does not concern himself with the opinion of sheep.</li></ul>",
        "id": "qt2415571",
        "shareButtonProps": {
          "url": "?item=qt2415571"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 13,
          "itemConst": "qt2415571",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 1114
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0372176/?ref_=ttqu_qu\">Cersei Lannister</a>: When you play the game of thrones, you win or you die. There is no middle ground.</li></ul>",
        "id": "qt2025967",
        "shareButtonProps": {
          "url": "?item=qt2025967"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 27,
          "itemConst": "qt2025967",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 1943
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3229685/?ref_=ttqu_qu\">Jon Snow</a>: I heard it was best to keep your enemies close.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0226820/?ref_=ttqu_qu\">Stannis Baratheon</a>: Whoever said that didn&#39;t have many enemies.</li></ul>",
        "id": "qt3071482",
        "shareButtonProps": {
          "url": "?item=qt3071482"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 3,
          "itemConst": "qt3071482",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 366
        }
      },
      {
        "cardHtml": "<ul><li>[<em>repeated line</em>]</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000293/?ref_=ttqu_qu\">Eddard Stark</a>: Winter is coming.</li></ul>",
        "id": "qt1699989",
        "shareButtonProps": {
          "url": "?item=qt1699989"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 28,
          "itemConst": "qt1699989",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 1495
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3701064/?ref_=ttqu_qu\">Ramsay Snow</a>: If you think this has a happy ending, you haven&#39;t been paying attention.</li></ul>",
        "id": "qt1981907",
        "shareButtonProps": {
          "url": "?item=qt1981907"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 32,
          "itemConst": "qt1981907",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 1587
        }
      },
      {
        "cardHtml": "<ul><li>[<em>repeated line</em>]</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: A Lannister always pays his debts.</li></ul>",
        "id": "qt1553146",
        "shareButtonProps": {
          "url": "?item=qt1553146"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 21,
          "itemConst": "qt1553146",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 1018
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0384152/?ref_=ttqu_qu\">Lord Varys</a>: Any fool with a bit of luck can find himself born into power. But earning it for yourself, that takes work.</li></ul>",
        "id": "qt3071470",
        "shareButtonProps": {
          "url": "?item=qt3071470"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 4,
          "itemConst": "qt3071470",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 325
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0318821/?ref_=ttqu_qu\">Petyr &#39;Littlefinger&#39; Baelish</a>: The realm. Do you know what the realm is? It&#39;s the thousand blades of Aegon&#39;s enemies. A story we agree to tell each other over and over until we forget that it&#39;s a lie.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0384152/?ref_=ttqu_qu\">Lord Varys</a>: But what do we have left once we abandon the lie? Chaos? A gaping pit waiting to swallow us all.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0318821/?ref_=ttqu_qu\">Petyr &#39;Littlefinger&#39; Baelish</a>: Chaos isn&#39;t a pit. Chaos is a ladder. Many who try to climb it fail and never get to try again. The fall breaks them. And some are given a chance to climb; they refuse. They cling to the realm or the gods or love. Illusions. Only the ladder is real. The climb is all there is.</li></ul>",
        "id": "qt3071553",
        "shareButtonProps": {
          "url": "?item=qt3071553"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 6,
          "itemConst": "qt3071553",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 378
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: [<em>to Cersei</em>] A day will come when you think you are safe and happy, and your joy will turn to ashes in your mouth. And you will know the debt is paid.</li></ul>",
        "id": "qt3611479",
        "shareButtonProps": {
          "url": "?item=qt3611479"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 3,
          "itemConst": "qt3611479",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 216
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: Let me give you some advice, bastard. Never forget what you are, the rest of the world will not. Wear it like armor and it can never be used to hurt you.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3229685/?ref_=ttqu_qu\">Jon Snow</a>: What the hell do you know about being a bastard?</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: All dwarfs are bastards in their father&#39;s eyes.</li></ul>",
        "id": "qt3580232",
        "shareButtonProps": {
          "url": "?item=qt3580232"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 5,
          "itemConst": "qt3580232",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 286
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0001354/?ref_=ttqu_qu\">Mance Rayder</a>: The freedom to make my own mistakes was all I ever wanted.</li></ul>",
        "id": "qt3605351",
        "shareButtonProps": {
          "url": "?item=qt3605351"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 1,
          "itemConst": "qt3605351",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 136
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0226820/?ref_=ttqu_qu\">Stannis Baratheon</a>: We march to victory, or we march to defeat. But we go forward. Only forward.</li></ul>",
        "id": "qt3071548",
        "shareButtonProps": {
          "url": "?item=qt3071548"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 2,
          "itemConst": "qt3071548",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 154
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: [<em>to Joffrey</em>] We&#39;ve had vicious kings and we&#39;ve had idiot kings, but I don&#39;t know if we&#39;ve ever been cursed with a vicious idiot for a king!</li></ul>",
        "id": "qt3089579",
        "shareButtonProps": {
          "url": "?item=qt3089579"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 7,
          "itemConst": "qt3089579",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 303
        }
      },
      {
        "cardHtml": "<ul><li>[<em>repeated line</em>]</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3310211/?ref_=ttqu_qu\">Ygritte</a>: You know nothing, Jon Snow.</li></ul>",
        "id": "qt1916227",
        "shareButtonProps": {
          "url": "?item=qt1916227"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 54,
          "itemConst": "qt1916227",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 1453
        }
      },
      {
        "cardHtml": "<ul><li>[<em>repeated line</em>]</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3964231/?ref_=ttqu_qu\">Hodor</a>: Hodor!</li></ul>",
        "id": "qt2632620",
        "shareButtonProps": {
          "url": "?item=qt2632620"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 35,
          "itemConst": "qt2632620",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 967
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0534635/?ref_=ttqu_qu\">Robb Stark</a>: All men should keep their word, kings most of all.</li></ul>",
        "id": "qt3071469",
        "shareButtonProps": {
          "url": "?item=qt3071469"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 2,
          "itemConst": "qt3071469",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 133
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: [<em>to Janos Slynt</em>] I&#39;m not questioning your honor; I&#39;m denying its existence.</li></ul>",
        "id": "qt4530884",
        "shareButtonProps": {
          "url": "?item=qt4530884"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 1,
          "itemConst": "qt4530884",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 84
        }
      },
      {
        "cardHtml": "<ul><li>[<em>repeated line</em>]</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0396924/?ref_=ttqu_qu\">Melisandre</a>: The night is dark and full of terrors.</li></ul>",
        "id": "qt1989667",
        "shareButtonProps": {
          "url": "?item=qt1989667"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 39,
          "itemConst": "qt1989667",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 786
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0564920/?ref_=ttqu_qu\">Sandor &#39;The Hound&#39; Clegane</a>: Any man dies with a clean sword, I&#39;ll rape his fucking corpse!</li></ul>",
        "id": "qt3611486",
        "shareButtonProps": {
          "url": "?item=qt3611486"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 6,
          "itemConst": "qt3611486",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 190
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3729225/?ref_=ttqu_qu\">Brienne of Tarth</a>: Nothing&#39;s more hateful than failing to protect the one you love.</li></ul>",
        "id": "qt3069598",
        "shareButtonProps": {
          "url": "?item=qt3069598"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 3,
          "itemConst": "qt3069598",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 125
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0050959/?ref_=ttqu_qu\">Oberyn Martell</a>: When we met your sister, she promised she would show you to us. Every day we would ask. Every day she would say, &quot;Soon.&quot; Then she and your brother took us to your nursery and... she unveiled the freak. Your head was a bit large. Your arms and legs were a bit small, but no claw. No red eye. No tail between your legs. Just a tiny pink cock. We didn&#39;t try to hide our disappointment. &quot;That&#39;s not a monster,&quot; I told Cersei, &quot;that&#39;s just a baby.&quot; And she said, &quot;He killed my mother.&quot; And she pinched your little cock so hard, I thought she might pull it off. Until your brother made her stop. &quot;It doesn&#39;t matter,&quot; she told us. &quot;Everyone says he will die soon, I hope they are right; he should not have lived this long.&quot;</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: [<em>tears welling</em>] Well... sooner or later, Cersei always gets what she wants.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0050959/?ref_=ttqu_qu\">Oberyn Martell</a>: And what about what I want? Justice for my sister and her children.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: If you want justice, you&#39;ve come to the wrong place.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0050959/?ref_=ttqu_qu\">Oberyn Martell</a>: I disagree. I&#39;ve come to the perfect place. I want to bring those who have wronged me to justice, and all those who have wronged me are right here. I will begin with Ser Gregor Clegane, who killed my sister&#39;s children and then raped her with their blood still on his hands before killing her, too. I will be your champion.</li></ul>",
        "id": "qt3079236",
        "shareButtonProps": {
          "url": "?item=qt3079236"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 8,
          "itemConst": "qt3079236",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 211
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0004692/?ref_=ttqu_qu\">Robert Baratheon</a>: I&#39;m simply asking you to run my kingdom while I eat, drink, and whore myself into an early grave.</li></ul>",
        "id": "qt2019310",
        "shareButtonProps": {
          "url": "?item=qt2019310"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 31,
          "itemConst": "qt2019310",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 554
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0322416/?ref_=ttqu_qu\">Joffrey Baratheon</a>: If I tell the Hound to cut you in half, he&#39;ll do it without a second thought.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: That would make me the quarter-man. Just doesn&#39;t have the same ring to it.</li></ul>",
        "id": "qt3611491",
        "shareButtonProps": {
          "url": "?item=qt3611491"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 3,
          "itemConst": "qt3611491",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 109
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0322416/?ref_=ttqu_qu\">Joffrey Baratheon</a>: They say Stannis never smiles. I&#39;ll give him a red smile, from ear to ear.</li><li>[<em>Joffrey walks away</em>]</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0227759/?ref_=ttqu_qu\">Tyrion Lannister</a>: [<em>jokingly</em>] Imagine Stannis&#39; terror.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0384152/?ref_=ttqu_qu\">Lord Varys</a>: I am trying.</li></ul>",
        "id": "qt3611484",
        "shareButtonProps": {
          "url": "?item=qt3611484"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 3,
          "itemConst": "qt3611484",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 104
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0000293/?ref_=ttqu_qu\">Eddard Stark</a>: You think my life is some precious thing to me? That I would trade my honor for a few more years... of what? You grew up with actors. You learned their craft and you learnt it well. But I grew up with soldiers. I learned to die a long time ago.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0384152/?ref_=ttqu_qu\">Lord Varys</a>: Pity. Such a pity. What of your daughter&#39;s life, my lord? Is that a precious thing to you?</li></ul>",
        "id": "qt3575159",
        "shareButtonProps": {
          "url": "?item=qt3575159"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 2,
          "itemConst": "qt3575159",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 76
        }
      },
      {
        "cardHtml": "<ul><li>[<em>repeated line</em>]</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm4263213/?ref_=ttqu_qu\">Samwell Tarly</a>: I read it in a book.</li></ul>",
        "id": "qt2912297",
        "shareButtonProps": {
          "url": "?item=qt2912297"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 14,
          "itemConst": "qt2912297",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 219
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3701064/?ref_=ttqu_qu\">Ramsay Snow</a>: To the traitor and bastard Jon Snow. You allowed thousands of wildlings past the Wall. You have betrayed your own kind. You have betrayed the North. Winterfell is mine, bastard. Come and see. Your brother Rickon is in my dungeon. His direwolf&#39;s skin is on my floor. Come and see. I want my bride back. Send her to me, bastard, and I will not trouble you or your wildling lovers. Keep her from me and I will ride north and slaughter every wildling man, woman, and babe living under your protection. You will watch as I skin them living. You will watch as my soldiers take turns raping your sister. You will watch as my dogs devour your wild little brother. Then I will spoon your eyes from their sockets and let my dogs do the rest. Come and see. -Ramsay Bolton, Lord of Winterfell and Warden of the North</li></ul>",
        "id": "qt2911402",
        "shareButtonProps": {
          "url": "?item=qt2911402"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 14,
          "itemConst": "qt2911402",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 206
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0443373/?ref_=ttqu_qu\">Thoros of Myr</a>: For a big hard man, you scare easy.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0564920/?ref_=ttqu_qu\">Sandor &#39;The Hound&#39; Clegane</a>: I&#39;ll tell you what doesn&#39;t scare me. Bald cocksuckers like you! You think you&#39;re fooling anyone with that topknot? Bald cunt.</li></ul>",
        "id": "qt3619114",
        "shareButtonProps": {
          "url": "?item=qt3619114"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 3,
          "itemConst": "qt3619114",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 77
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0182666/?ref_=ttqu_qu\">Jaime Lannister</a>: [<em>about Ned Stark</em>] By what right does the wolf judge the lion? By what right?</li></ul>",
        "id": "qt2731959",
        "shareButtonProps": {
          "url": "?item=qt2731959"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 16,
          "itemConst": "qt2731959",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 213
        }
      },
      {
        "cardHtml": "<ul><li>[<em>Robert strikes Cersei across the face</em>]</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0372176/?ref_=ttqu_qu\">Cersei Lannister</a>: I shall wear this as a badge of honor.</li><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0004692/?ref_=ttqu_qu\">Robert Baratheon</a>: Wear it in silence or I&#39;ll honor you again.</li></ul>",
        "id": "qt3580219",
        "shareButtonProps": {
          "url": "?item=qt3580219"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 5,
          "itemConst": "qt3580219",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 95
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0182666/?ref_=ttqu_qu\">Jaime Lannister</a>: [<em>to Brienne, about Aerys Targaryen</em>] Tell me, if your precious Renly commanded you to kill your own father and stand by while thousands of men, women and children burnt alive, would you have done it? Would you have kept your oath then?</li></ul>",
        "id": "qt3417382",
        "shareButtonProps": {
          "url": "?item=qt3417382"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 5,
          "itemConst": "qt3417382",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 86
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0891092/?ref_=ttqu_qu\">Maester Aemon</a>: Nothing makes the past a sweeter place to visit than the prospect of imminent death.</li></ul>",
        "id": "qt3602921",
        "shareButtonProps": {
          "url": "?item=qt3602921"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 3,
          "itemConst": "qt3602921",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 59
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0564920/?ref_=ttqu_qu\">Sandor &#39;The Hound&#39; Clegane</a>: Fuck the kingsguard. Fuck the city. Fuck the king.</li></ul>",
        "id": "qt6012035",
        "shareButtonProps": {
          "url": "?item=qt6012035"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 1,
          "itemConst": "qt6012035",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 29
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm3701064/?ref_=ttqu_qu\">Ramsay Snow</a>: My mother taught me not to throw stones at cripples... but my father taught me: aim for their head!</li></ul>",
        "id": "qt3582988",
        "shareButtonProps": {
          "url": "?item=qt3582988"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 5,
          "itemConst": "qt3582988",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 43
        }
      },
      {
        "cardHtml": "<ul><li><a class=\"ipc-md-link ipc-md-link--entity\" href=\"/name/nm0004692/?ref_=ttqu_qu\">Robert Baratheon</a>: The whore is pregnant!</li></ul>",
        "id": "qt4558243",
        "shareButtonProps": {
          "url": "?item=qt4558243"
        },
        "shouldExpandHtmlContent": true,
        "userVotingProps": {
          "downVotes": 4,
          "itemConst": "qt4558243",
          "itemType": "TitleQuote",
          "pageConst": "tt0944947",
          "refTagPrefix": "ttqu",
          "upVotes": 22
        }
      }
    ],
    "total": 36
  },
  "message": "Successful",
  "status": true
}






const singleMoViesData=[]


console.log(Details.data.aboveTheFoldData)


// ________________Casting Data {ID,name}______________________
let TempCastObject=[];
const tempCast = Details.data.aboveTheFoldData.castPageTitle.edges;
tempCast.map((singleTempCast)=>{
  TempCastObject={
  id:singleTempCast.node.name.id,
  name:singleTempCast.node.name.nameText.text
  }

  singleMoViesData.push(addCast);
})
 const addCast={
    cast:{
      TempCastObject
    }
  }
  singleMoViesData.push(addCast);

// ________________Moive Country {Country}______________________

const tempCountry = Details.data.aboveTheFoldData.countriesOfOrigin.countries;
tempCountry.map((singlecountry)=>{
  console.log(singlecountry.id);

})



// ________________directorsPageTitle {id,name}______________________
const tempDirector = Details.data.aboveTheFoldData.directorsPageTitle;
tempDirector.map((singleDirector)=>{


  const Direcredits=singleDirector.credits
  Direcredits.map((singleDirecredits)=>{
    console.log(singleDirecredits.name.id)
    console.log(singleDirecredits.name.nameText.text)
  })
})



// ________________FeatureReview is Use But in this not Use______________________





// ________________Genere Data {name}______________________
const tempgenre = Details.data.aboveTheFoldData.genres.genres;
tempgenre.map((singlegenre)=>{
  console.log(singlegenre.text);
})


// ________________Keyword Data {name}______________________
const tempKeyowrd = Details.data.aboveTheFoldData.keywords.edges;
tempKeyowrd.map((singleKeyword)=>{
  console.log(singleKeyword.node.text);
})

// // ________________ meta information Described that the movies is "PUBLISHED" or not Data {name}______________________



// ________________ movies Orginal Title  {name}______________________
console.log(Details.data.aboveTheFoldData.originalTitleText.text)

// ________________ movies Description {name} ______________________
 const tempDescription =Details.data.aboveTheFoldData.plot.plotText.plainText
console.log(tempDescription)


// ________________ movies Description {name} ______________________




// ________________ Video {url} ______________________

const TempVideo = Details.data.aboveTheFoldData.primaryVideos.edges
TempVideo.map((singleVideo)=>{


  const videoUrl=singleVideo.node.playbackURLs

  videoUrl.map((singleVideoUrl)=>{


      console.log(singleVideoUrl.url);
    })


// Optional Year and text

  // console.log(singleVideo.node.primaryTitle.releaseYear.year);
  // console.log(singleVideo.node.primaryTitle.titleText.text);
})


// ________________ principalCredits Credit {id,name} "cast,writer,director all in one" ______________________

const tempCredits = Details.data.aboveTheFoldData.principalCredits;
tempCredits.map((singleCredits)=>{

console.log(singleCredits.category.text)
const MultipleCredit=singleCredits.credits

MultipleCredit.map((singleActorCredit)=>{
    console.log(singleActorCredit.name.id)
    console.log(singleActorCredit.name.nameText.text)
  })
})

// ________________ Movies Production company {id.text} ______________________


const TempProductionCompany=Details.data.aboveTheFoldData.production.edges;
TempProductionCompany.map((singleProdctionCompany)=>{
    console.log(singleProdctionCompany.node.company.companyText.text)
    console.log(singleProdctionCompany.node.company.id)
  })

// ________________ ProductionStatus optional ______________________



// ________________ Rating  ______________________

const TempRating=Details.data.aboveTheFoldData.ratingsSummary;
console.log(TempRating.aggregateRating)
console.log(TempRating.voteCount)




// ________________ Release Date  ______________________

const TempReleaseDate=Details.data.aboveTheFoldData.releaseDate;
console.log(TempReleaseDate.day)
console.log(TempReleaseDate.month)
console.log(TempReleaseDate.year)

const AddReleaseDate={
  date:{
  day:TempReleaseDate.day,
  month:TempReleaseDate.month,
  year:TempReleaseDate.year
  }
}
  singleMoViesData.push(AddReleaseDate)
  

// ________________ Runtime   ______________________
const TempRuntime=Details.data.aboveTheFoldData.runtime;
console.log(TempRuntime.seconds)




console.log(singleMoViesData)
// console.log(image.data)
// console.log(video.data)
// console.log(sound_track.data)
// console.log(Rating.data)
// console.log(OtherCAst.data)
// console.log(Actor.data)
// console.log(news.data)
// console.log(trviva.data)
// console.log(shottlocatiion.data)
// console.log(goofs.data)
// console.log(Quotes.data)

const TempData={
    cast:[
      {
        "id": "nm0897201",
        "name": "Joseph Vijay"
    },{
      "id": "nm0897201",
      "name": "Joseph Vijay"
  }
],
    date:{
      month:"123"
    }

  }
console.log(TempData)