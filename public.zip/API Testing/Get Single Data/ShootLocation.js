const shottlocatiion={
    "data": [
      {
        "id": "flmg_locations",
        "name": "Filming locations",
        "section": {
          "endCursor": "bGMzNTk2NTIx",
          "items": [
            {
              "attributes": "Filming City",
              "cardText": "Kashmir, India",
              "cardTextUrl": "/search/title/?locations=Kashmir%2C%20India&ref_=ttloc_loc_0",
              "id": "lc3537222",
              "shareButtonProps": {
                "url": "?item=lc3537222"
              },
              "userVotingProps": {
                "downVotes": 0,
                "itemConst": "lc3537222",
                "itemType": "FilmingLocation",
                "pageConst": "tt15654328",
                "refTagPrefix": "ttloc",
                "upVotes": 2
              }
            },
            {
              "attributes": "Filming City",
              "cardText": "Chennai, India",
              "cardTextUrl": "/search/title/?locations=Chennai%2C%20India&ref_=ttloc_loc_1",
              "id": "lc3537223",
              "shareButtonProps": {
                "url": "?item=lc3537223"
              },
              "userVotingProps": {
                "downVotes": 0,
                "itemConst": "lc3537223",
                "itemType": "FilmingLocation",
                "pageConst": "tt15654328",
                "refTagPrefix": "ttloc",
                "upVotes": 2
              }
            },
            {
              "attributes": "Filming City",
              "cardText": "Talakona, India",
              "cardTextUrl": "/search/title/?locations=Talakona%2C%20India&ref_=ttloc_loc_2",
              "id": "lc3537224",
              "shareButtonProps": {
                "url": "?item=lc3537224"
              },
              "userVotingProps": {
                "downVotes": 0,
                "itemConst": "lc3537224",
                "itemType": "FilmingLocation",
                "pageConst": "tt15654328",
                "refTagPrefix": "ttloc",
                "upVotes": 1
              }
            },
            {
              "cardText": "Kodaikanal, Tamil Nadu, India",
              "cardTextUrl": "/search/title/?locations=Kodaikanal%2C%20Tamil%20Nadu%2C%20India&ref_=ttloc_loc_3",
              "id": "lc3596520",
              "shareButtonProps": {
                "url": "?item=lc3596520"
              },
              "userVotingProps": {
                "downVotes": 0,
                "itemConst": "lc3596520",
                "itemType": "FilmingLocation",
                "pageConst": "tt15654328",
                "refTagPrefix": "ttloc",
                "upVotes": 0
              }
            },
            {
              "attributes": "Parthiban's house",
              "cardText": "Kashmir, India",
              "cardTextUrl": "/search/title/?locations=Kashmir%2C%20India&ref_=ttloc_loc_4",
              "id": "lc3596521",
              "shareButtonProps": {
                "url": "?item=lc3596521"
              },
              "userVotingProps": {
                "downVotes": 0,
                "itemConst": "lc3596521",
                "itemType": "FilmingLocation",
                "pageConst": "tt15654328",
                "refTagPrefix": "ttloc",
                "upVotes": 0
              }
            }
          ],
          "total": 7
        }
      },
      {
        "id": "flmg_dates",
        "name": "Filming dates",
        "section": {
          "endCursor": null,
          "items": [],
          "total": 0
        }
      },
      {
        "id": "prod_dates",
        "name": "Production dates",
        "section": {
          "endCursor": null,
          "items": [],
          "total": 0
        }
      }
    ],
    "message": "Successful",
    "status": true
  }

// Only Take Filming Location
const TempShootingData=shottlocatiion.data
TempShootingData.map((SingleShootingData)=>{

    console.log(SingleShootingData)
})




