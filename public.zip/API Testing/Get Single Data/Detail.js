// After

const Details = {
  data: {
    aboveTheFoldData: {
      __typename: "Title",
      canHaveEpisodes: false,
      canRate: {
        __typename: "CanRate",
        isRatable: true,
      },
      castPageTitle: {
        __typename: "CreditConnection",
        edges: [
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              name: {
                __typename: "Name",
                id: "nm0897201",
                nameText: {
                  __typename: "NameText",
                  text: "Joseph Vijay",
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              name: {
                __typename: "Name",
                id: "nm0004569",
                nameText: {
                  __typename: "NameText",
                  text: "Sanjay Dutt",
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              name: {
                __typename: "Name",
                id: "nm0440604",
                nameText: {
                  __typename: "NameText",
                  text: "Anurag Kashyap",
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              name: {
                __typename: "Name",
                id: "nm0352032",
                nameText: {
                  __typename: "NameText",
                  text: "Kamal Haasan",
                },
              },
            },
          },
        ],
      },
      certificate: null,
      countriesOfOrigin: {
        __typename: "CountriesOfOrigin",
        countries: [
          {
            __typename: "CountryOfOrigin",
            id: "IN",
          },
        ],
      },
      creatorsPageTitle: [],
      credits: {
        __typename: "CreditConnection",
        total: 197,
      },
      criticReviewsTotal: {
        __typename: "ExternalLinkConnection",
        total: 23,
      },
      directorsPageTitle: [
        {
          __typename: "PrincipalCreditsForCategory",
          credits: [
            {
              __typename: "Crew",
              name: {
                __typename: "Name",
                id: "nm7992231",
                nameText: {
                  __typename: "NameText",
                  text: "Lokesh Kanagaraj",
                },
              },
            },
          ],
        },
      ],
      engagementStatistics: {
        __typename: "EngagementStatistics",
        watchlistStatistics: {
          __typename: "WatchlistStatistics",
          displayableCount: {
            __typename: "LocalizedDisplayableCount",
            text: "Added by 27.8K users",
          },
        },
      },
      externalLinks: {
        __typename: "ExternalLinkConnection",
        total: 46,
      },
      featuredReviews: {
        __typename: "ReviewsConnection",
        edges: [
          {
            __typename: "ReviewEdge",
            node: {
              __typename: "Review",
              author: {
                __typename: "UserProfile",
                nickName: "abhilashsv-67775",
              },
              authorRating: 8,
              submissionDate: "2023-10-20",
              summary: {
                __typename: "ReviewSummary",
                originalText: "LEO - A Good Standalone Movie",
              },
              text: {
                __typename: "ReviewText",
                originalText: {
                  __typename: "Markdown",
                  plainText:
                    "LEO- Most anticipated movie has finally arrived, and it certainly doesn't disappoint and lives upto the Hype it was Given.\n\nThe first half was SUPERB.\n\nSome best solo action where his fights has some more good class than hitting a 50 guys like typical.\n\nIt is not a TYPICAL Vijay film, where his style and Mass entry and saving everyone is not here. There is literally No Mass Intro scene , No Super hero stuffs and all. Just a guy trying to save his family, till the first half.\n\nIts one of the Best acting by Vijay in his career.\n\nSecond Half is a bit laggy feel but its good.\n\nSome CGI work was very bad it looked like NFS Car Chase at some points.\n\nFinal Fight sequence was over crowded with villans it doesn't do much good, But solo fight at last was awesome.\n\nOverall its a Good Movie and a must watch in Theatre.\n\nDon't go with the mindset of Vikram, its not as much good. But its Very much Enjoyable and a nice Vijay Film...",
                },
              },
            },
          },
        ],
      },
      genres: {
        __typename: "Genres",
        genres: [
          {
            __typename: "Genre",
            id: "Action",
            text: "Action",
          },
          {
            __typename: "Genre",
            id: "Crime",
            text: "Crime",
          },
          {
            __typename: "Genre",
            id: "Drama",
            text: "Drama",
          },
          {
            __typename: "Genre",
            id: "Thriller",
            text: "Thriller",
          },
        ],
      },
      id: "tt15654328",
      images: {
        __typename: "ImageConnection",
        edges: [
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              id: "rm854806785",
            },
          },
        ],
        total: 95,
      },
      keywords: {
        __typename: "TitleKeywordConnection",
        edges: [
          {
            __typename: "TitleKeywordEdge",
            node: {
              __typename: "TitleKeyword",
              text: "action hero",
            },
          },
          {
            __typename: "TitleKeywordEdge",
            node: {
              __typename: "TitleKeyword",
              text: "one word title",
            },
          },
          {
            __typename: "TitleKeywordEdge",
            node: {
              __typename: "TitleKeyword",
              text: "intermission",
            },
          },
          {
            __typename: "TitleKeywordEdge",
            node: {
              __typename: "TitleKeyword",
              text: "violence",
            },
          },
          {
            __typename: "TitleKeywordEdge",
            node: {
              __typename: "TitleKeyword",
              text: "extreme violence",
            },
          },
        ],
        total: 36,
      },
      meta: {
        __typename: "TitleMeta",
        canonicalId: "tt15654328",
        publicationStatus: "PUBLISHED",
      },
      metacritic: null,
      meterRanking: {
        __typename: "TitleMeterRanking",
        currentRank: 1395,
        rankChange: {
          __typename: "MeterRankChange",
          changeDirection: "DOWN",
          difference: 49,
        },
      },
      originalTitleText: {
        __typename: "TitleText",
        text: "Leo",
      },
      plot: {
        __typename: "Plot",
        language: {
          __typename: "DisplayableLanguage",
          id: "en-US",
        },
        plotText: {
          __typename: "Markdown",
          plainText:
            "Parthiban is a mild-mannered cafe owner in Kashmir, who fends off a gang of murderous thugs and gains attention from a drug cartel claiming he was once a part of them.",
        },
      },
      plotContributionLink: {
        __typename: "ContributionLink",
        url: "https://contribute.imdb.com/updates?update=tt15654328:outlines.add.1.locale~en-US",
      },
      primaryImage: {
        __typename: "Image",
        caption: {
          __typename: "Markdown",
          plainText: "Joseph Vijay in Leo (2023)",
        },
        height: 1633,
        id: "rm2551271425",
        url: "https://m.media-amazon.com/images/M/MV5BMmFiOGYyZjQtZmZmNC00ZTgzLWI5ZjktMTRiYzc5NjAzODRkXkEyXkFqcGdeQXVyMTYyNDkzNzgz._V1_.jpg",
        width: 1080,
      },
      primaryVideos: {
        __typename: "VideoConnection",
        edges: [
          {
            __typename: "VideoEdge",
            node: {
              __typename: "Video",
              contentType: {
                __typename: "VideoContentType",
                displayName: {
                  __typename: "LocalizedString",
                  value: "Trailer",
                },
                id: "amzn1.imdb.video.contenttype.trailer",
              },
              createdDate: "2023-11-20T15:50:21.751Z",
              description: {
                __typename: "LocalizedString",
                language: "ta",
                value:
                  "Parthiban is a mild-mannered cafe owner in Kashmir, who fends off a gang of murderous thugs and gains attention from a drug cartel claiming he was once a part of them.",
              },
              id: "vi3073296153",
              isMature: false,
              name: {
                __typename: "LocalizedString",
                language: "ta",
                value: "Official Trailer",
              },
              playbackURLs: [
                {
                  __typename: "PlaybackURL",
                  displayName: {
                    __typename: "LocalizedString",
                    language: "en-US",
                    value: "480p",
                  },
                  url: "https://imdb-video.media-imdb.com/vi3073296153/1434659607842-pgv4ql-1700495422057.mp4?Expires=1708782771&Signature=qCZql6Lg2sJHKf67b4MBy12VYnR8YjQlL5pRmeTNaPlO4niqUvx52oDgrYASZ6ISEaXobHaEgRjGRMiJt5fOaHgNOX3sPi4iNj7P8les5M0sV5LkwvQT5LrlrOAX-4R9083mJvazW1fqT8Y6ZT51Cd2i-ItA7rDtqhA20xi-B9Vb1Gz0OTZ1smEem5kFfulPNUXGhTFyTTIl~dZ3f8cl4kEz4myI~lBJg9ByvjgkS3hbNbXD5JONxM2TCTl4yK3RU0N0HYnaGFrYQSVMWfVOOhkAgkYtVQFAMd8pzTEiO17eWtIPCi1gxZ3YrgzlyswQHYK~x48JeIp06sCuKf5Faw__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  videoDefinition: "DEF_480p",
                  videoMimeType: "MP4",
                },
                {
                  __typename: "PlaybackURL",
                  displayName: {
                    __typename: "LocalizedString",
                    language: "en-US",
                    value: "SD",
                  },
                  url: "https://imdb-video.media-imdb.com/vi3073296153/1434659454657-dx9ykf-1700495422057.mp4?Expires=1708782771&Signature=pvOpKfWZf933TZiNv3KFGdFp6hiPpCfom8WVpA1cvd1GxUZtkXrhGOcRBHwaASiDSvApPJ~W5dX-g1B7IZ5ONAtckt9zi4uREYyBpqu3f05g2FnZq~f~y87V05Zpb8Ve1XXEAAlmKE6uS0wleuuOrUwPGLr--9SZRcU8WqNPrmNs47x31M~Mbpck-T-dAuKopwOk7Qc429tZb2m~w2NHWwAsPH0ve2RHInLdYl3Elqm7d2SL5EUOT1SwUKW1iCD1QxeJgrXvcxHkvCRj8hUq2j~89STRDvfprOXuzsNXYmqC~RF5BYvxSfLyVx~4UOSyt7~YexzO1hJkGsCGXst49Q__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  videoDefinition: "DEF_SD",
                  videoMimeType: "MP4",
                },
              ],
              previewURLs: [
                {
                  __typename: "PlaybackURL",
                  displayName: {
                    __typename: "LocalizedString",
                    language: "en-US",
                    value: "AUTO",
                  },
                  url: "https://imdb-video.media-imdb.com/vi3073296153/hls-preview-51812303-ca59-4bc7-9b0f-97157dcd9f74.m3u8?Expires=1708782771&Signature=h1IS22X-Izv2~MJ3qTKuRw7WTLmRj2QoOaqEGMaWPPUOTKFh7PMPWd42aCoLuhr5CMtka-l3vM19214kD7WAqZA~ZS6JVVJ~tHatxh2k2hhVuHJkCzcej5QIKi3m24f-7~wwhXsxM2TrcUcM3gupWv~Gt7ZIRb0Gt-3o4X7kFIKERA5f~uBJhsPfyti-g51Tw4Z5KmRG4joDE37Cwi9kwtgbNK3Jzyqm~QaUlnHmcylHZ-zbIL0tLWpYtBbOID4tdbLZvXJit8cnTzFyEx6uOd4GKM-NHiercowvCB9LiSj2xeHwbAMGm1SZdEzDc8ttuKlSY7TI8Z7ZRymIhfMwww__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  videoDefinition: "DEF_AUTO",
                  videoMimeType: "M3U8",
                },
              ],
              primaryTitle: {
                __typename: "Title",
                id: "tt15654328",
                originalTitleText: {
                  __typename: "TitleText",
                  text: "Leo",
                },
                releaseYear: {
                  __typename: "YearRange",
                  year: 2023,
                },
                titleText: {
                  __typename: "TitleText",
                  text: "Leo",
                },
              },
              recommendedTimedTextTrack: null,
              runtime: {
                __typename: "VideoRuntime",
                value: 141,
              },
              thumbnail: {
                __typename: "Thumbnail",
                height: 1080,
                url: "https://m.media-amazon.com/images/M/MV5BYjY1YjliNjQtOTU4NC00M2JlLWEwY2MtMmI2YjlmNThkMmY3XkEyXkFqcGdeQWpvc2FyYw@@._V1_.jpg",
                width: 1920,
              },
              timedTextTracks: [],
            },
          },
          {
            __typename: "VideoEdge",
            node: {
              __typename: "Video",
              contentType: {
                __typename: "VideoContentType",
                displayName: {
                  __typename: "LocalizedString",
                  value: "Trailer",
                },
                id: "amzn1.imdb.video.contenttype.trailer",
              },
              createdDate: "2023-10-05T13:43:45.730Z",
              description: {
                __typename: "LocalizedString",
                language: "ta",
                value: "",
              },
              id: "vi2111686425",
              isMature: false,
              name: {
                __typename: "LocalizedString",
                language: "ta",
                value: "Leo - Official Trailer",
              },
              playbackURLs: [
                {
                  __typename: "PlaybackURL",
                  displayName: {
                    __typename: "LocalizedString",
                    language: "en-US",
                    value: "480p",
                  },
                  url: "https://imdb-video.media-imdb.com/vi2111686425/1434659607842-pgv4ql-1696513425958.mp4?Expires=1708782771&Signature=nNr5eqfC0Tpvdl02DDiGvV3cST98FEIYIQ0slValzRW~2wH2YybkW63dT6s~pZWbR-9v2wedjfS~UmZ2C7AwYRp3fYHkUaRrf4FWt~iotXHAsV9Nf9yESYUVm8G74JBpadxli3ftVY-XEWDAZlXjEsN87np4XL7TfFdCmy3AJCrdAWcMRu0fvpshqurG440T7FMXjwxePyG4BRrpcklxZYi8gb7yYKhN7XDc2DN0FovT9ntsFatJuYcIAUDXXBUWH9blXGMMzJATjrXLb2pj5LVBlVQ~xuPveft4LG6x6o6g0nPVkSgd900IQAAkn9MKoXtjqbvq9tse2hCaV74pkQ__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  videoDefinition: "DEF_480p",
                  videoMimeType: "MP4",
                },
                {
                  __typename: "PlaybackURL",
                  displayName: {
                    __typename: "LocalizedString",
                    language: "en-US",
                    value: "SD",
                  },
                  url: "https://imdb-video.media-imdb.com/vi2111686425/1434659454657-dx9ykf-1696513425958.mp4?Expires=1708782771&Signature=hroIUmMGrImds~TGrt2MBHC9Bd-wFA9GnTniwolaynhNqRi-9b~tIAqBx6HTo7IUP2HIZPXSfNB5hh1mJWdD~tQP13NU~DAS9eNOieE4gdxrfbywrmniyZbWQoSxbQvV88kRDjT1BtRjGlqZHfpVyeRM-zKIC3eqf8oly-5X6I-Cw4LtoL6LscGkrnnIP07FYYKn7lzODy7tPVe759K~6SsjI2OkRaV5XGvfEsg64lII1WUxMaUkFyZCm9XPrGR8P7mk70GqVVb45IvUUd8tJN~J6BCDRAgIkc-7uzF8Td3DSpmWgHm0SjIX~6SVSvKTIhViSOUo~EJuZF71Cqga2g__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  videoDefinition: "DEF_SD",
                  videoMimeType: "MP4",
                },
              ],
              previewURLs: [
                {
                  __typename: "PlaybackURL",
                  displayName: {
                    __typename: "LocalizedString",
                    language: "en-US",
                    value: "AUTO",
                  },
                  url: "https://imdb-video.media-imdb.com/vi2111686425/hls-preview-ff03a1c1-6f91-43aa-9188-bbd82194b4c1.m3u8?Expires=1708782771&Signature=sAIQdAmS24vfzWizzKql~MzfKUnam7n9-z6CVG7PFjr8~XHfwWSkyPQsqww~mbGgO4cTVpJ~MNAXyicocnkjqUawPjBIlDlMVbKdeisMfnKdPKBDnZMo5YwsorFAxp0Xokz~~nxY1hgPk4ZtLpPxweoIDZopt6jzovDCTYh9J~idCNxO1yWvm5d5Tbd4bxKfBdoa~u-j1yh1BBQu1Lef6AD31rQKxGfNQM6hrNJGS0nsHNi7EihjNaDbGE-UdTBA2NJiTuOQ70CSi9tNQ0UU7uQNfdQTfbP8B13pkP1uf61VnHsUHG1Lojplz1ClRrTxVzm1qentpf-c6s2hDFdURg__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
                  videoDefinition: "DEF_AUTO",
                  videoMimeType: "M3U8",
                },
              ],
              primaryTitle: {
                __typename: "Title",
                id: "tt15654328",
                originalTitleText: {
                  __typename: "TitleText",
                  text: "Leo",
                },
                releaseYear: {
                  __typename: "YearRange",
                  year: 2023,
                },
                titleText: {
                  __typename: "TitleText",
                  text: "Leo",
                },
              },
              recommendedTimedTextTrack: null,
              runtime: {
                __typename: "VideoRuntime",
                value: 162,
              },
              thumbnail: {
                __typename: "Thumbnail",
                height: 775,
                url: "https://m.media-amazon.com/images/M/MV5BYmUwNzIyYWUtOGEzNi00ZTQzLTg1NjEtY2ViYjAyNzAzNzg5XkEyXkFqcGdeQWthc2hpa2F4._V1_.jpg",
                width: 1378,
              },
              timedTextTracks: [],
            },
          },
        ],
      },
      principalCredits: [
        {
          __typename: "PrincipalCreditsForCategory",
          category: {
            __typename: "CreditCategory",
            id: "director",
            text: "Director",
          },
          credits: [
            {
              __typename: "Crew",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm7992231",
                nameText: {
                  __typename: "NameText",
                  text: "Lokesh Kanagaraj",
                },
              },
            },
          ],
          totalCredits: 1,
        },
        {
          __typename: "PrincipalCreditsForCategory",
          category: {
            __typename: "CreditCategory",
            id: "writer",
            text: "Writers",
          },
          credits: [
            {
              __typename: "Crew",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm7992231",
                nameText: {
                  __typename: "NameText",
                  text: "Lokesh Kanagaraj",
                },
              },
            },
            {
              __typename: "Crew",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm7188712",
                nameText: {
                  __typename: "NameText",
                  text: "Rathna Kumar",
                },
              },
            },
            {
              __typename: "Crew",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm5338753",
                nameText: {
                  __typename: "NameText",
                  text: "Deeraj Vaidy",
                },
              },
            },
          ],
          totalCredits: 3,
        },
        {
          __typename: "PrincipalCreditsForCategory",
          category: {
            __typename: "CreditCategory",
            id: "cast",
            text: "Stars",
          },
          credits: [
            {
              __typename: "Cast",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm0897201",
                nameText: {
                  __typename: "NameText",
                  text: "Joseph Vijay",
                },
              },
            },
            {
              __typename: "Cast",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm0004569",
                nameText: {
                  __typename: "NameText",
                  text: "Sanjay Dutt",
                },
              },
            },
            {
              __typename: "Cast",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm0440604",
                nameText: {
                  __typename: "NameText",
                  text: "Anurag Kashyap",
                },
              },
            },
          ],
          totalCredits: 43,
        },
      ],
      production: {
        __typename: "CompanyCreditConnection",
        edges: [
          {
            __typename: "CompanyCreditEdge",
            node: {
              __typename: "CompanyCredit",
              company: {
                __typename: "Company",
                companyText: {
                  __typename: "CompanyText",
                  text: "Seven Screen Studio",
                },
                id: "co0733661",
              },
            },
          },
          {
            __typename: "CompanyCreditEdge",
            node: {
              __typename: "CompanyCredit",
              company: {
                __typename: "Company",
                companyText: {
                  __typename: "CompanyText",
                  text: "The Route",
                },
                id: "co0946109",
              },
            },
          },
        ],
      },
      productionStatus: {
        __typename: "ProductionStatusDetails",
        currentProductionStage: {
          __typename: "ProductionStage",
          id: "released",
          text: "Released",
        },
        productionStatusHistory: [
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "development_unknown",
              text: "Development Unknown",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "production_unknown",
              text: "Production Unknown",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "production_unknown",
              text: "Production Unknown",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "filming",
              text: "Filming",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "filming",
              text: "Filming",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "filming",
              text: "Filming",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "post_production",
              text: "Post-production",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "completed",
              text: "Completed",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "released",
              text: "Released",
            },
          },
        ],
        restriction: null,
      },
      ratingsSummary: {
        __typename: "RatingsSummary",
        aggregateRating: 7.2,
        voteCount: 56909,
      },
      releaseDate: {
        __typename: "ReleaseDate",
        day: 21,
        month: 11,
        year: 2023,
      },
      releaseYear: {
        __typename: "YearRange",
        endYear: null,
        year: 2023,
      },
      reviews: {
        __typename: "ReviewsConnection",
        total: 414,
      },
      runtime: {
        __typename: "Runtime",
        displayableProperty: {
          __typename: "DisplayableTitleRuntimeProperty",
          value: {
            __typename: "Markdown",
            plainText: "2h 44m",
          },
        },
        seconds: 9840,
      },
      series: null,
      subNavCredits: {
        __typename: "CreditConnection",
        total: 197,
      },
      subNavFaqs: {
        __typename: "FaqConnection",
        total: 0,
      },
      subNavReviews: {
        __typename: "ReviewsConnection",
        total: 414,
      },
      subNavTopQuestions: {
        __typename: "AlexaQuestionConnection",
        total: 14,
      },
      subNavTrivia: {
        __typename: "TriviaConnection",
        total: 10,
      },
      titleGenres: {
        __typename: "TitleGenres",
        genres: [
          {
            __typename: "TitleGenre",
            genre: {
              __typename: "GenreItem",
              text: "Action",
            },
          },
          {
            __typename: "TitleGenre",
            genre: {
              __typename: "GenreItem",
              text: "Crime",
            },
          },
          {
            __typename: "TitleGenre",
            genre: {
              __typename: "GenreItem",
              text: "Drama",
            },
          },
        ],
      },
      titleText: {
        __typename: "TitleText",
        text: "Leo",
      },
      titleType: {
        __typename: "TitleType",
        canHaveEpisodes: false,
        categories: [
          {
            __typename: "TitleTypeCategory",
            value: "movie",
          },
        ],
        displayableProperty: {
          __typename: "DisplayableTitleTypeProperty",
          value: {
            __typename: "Markdown",
            plainText: "",
          },
        },
        id: "movie",
        isEpisode: false,
        isSeries: false,
        text: "Movie",
      },
      triviaTotal: {
        __typename: "TriviaConnection",
        total: 10,
      },
      videos: {
        __typename: "TitleRelatedVideosConnection",
        total: 5,
      },
    },
    mainColumnData: {
      __typename: "Title",
      akas: {
        __typename: "AkaConnection",
        edges: [
          {
            __typename: "AkaEdge",
            node: {
              __typename: "Aka",
              text: "Лео",
            },
          },
        ],
      },
      alternateVersions: {
        __typename: "AlternateVersionConnection",
        edges: [
          {
            __typename: "AlternateVersionEdge",
            node: {
              __typename: "AlternateVersion",
              text: {
                __typename: "Markdown",
                plaidHtml:
                  "The UK release was cut, the distributor chose to make cuts to scenes of strong bloody violence in order to obtain a 15 classification. An uncut 18 classification was available.",
              },
            },
          },
        ],
        total: 2,
      },
      canHaveEpisodes: false,
      canRate: {
        __typename: "CanRate",
        isRatable: true,
      },
      cast: {
        __typename: "CreditConnection",
        edges: [
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Leo Das",
                },
                {
                  __typename: "Character",
                  name: "Parthiban",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm0897201",
                nameText: {
                  __typename: "NameText",
                  text: "Joseph Vijay",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 955,
                  url: "https://m.media-amazon.com/images/M/MV5BZWJlODhlMzctOTU0Yi00MTUwLTkxODYtMDNjNTQxYTI2YTE1XkEyXkFqcGdeQXVyMTEzNzg0Mjkx._V1_.jpg",
                  width: 790,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Antony Das",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm0004569",
                nameText: {
                  __typename: "NameText",
                  text: "Sanjay Dutt",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 1365,
                  url: "https://m.media-amazon.com/images/M/MV5BNzU2NTgwNzY1OF5BMl5BanBnXkFtZTcwMjQxNzcxOA@@._V1_.jpg",
                  width: 2048,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Daniel",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm0440604",
                nameText: {
                  __typename: "NameText",
                  text: "Anurag Kashyap",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 2048,
                  url: "https://m.media-amazon.com/images/M/MV5BMjExOTEyNDcwMl5BMl5BanBnXkFtZTgwMjM3NzM0OTE@._V1_.jpg",
                  width: 1365,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: [
                {
                  __typename: "MiscellaneousCreditAttribute",
                  text: "voice",
                },
              ],
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Agent Vikram",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm0352032",
                nameText: {
                  __typename: "NameText",
                  text: "Kamal Haasan",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 1050,
                  url: "https://m.media-amazon.com/images/M/MV5BYmUxNTY0MWItODQ2My00YWMyLWFmODgtNTY1MTQ2ZjEwYzdlXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  width: 833,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actress",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Sathya",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm1375534",
                nameText: {
                  __typename: "NameText",
                  text: "Trisha Krishnan",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 1495,
                  url: "https://m.media-amazon.com/images/M/MV5BNGZjMGM1MTgtZTAwMy00NmEwLTg5NTMtOGJlYjI3Y2UzMzVlXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  width: 1024,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Siddharth",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm10464357",
                nameText: {
                  __typename: "NameText",
                  text: "Mathew Thomas",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 6000,
                  url: "https://m.media-amazon.com/images/M/MV5BZGViYWRjMTQtNmQxMi00MGVjLWFhYTktYmZjZmMyMzY4MGQzXkEyXkFqcGdeQXVyMTU0MjgwMTUw._V1_.jpg",
                  width: 4500,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Joshy Andrews",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm1069826",
                nameText: {
                  __typename: "NameText",
                  text: "Gautham Vasudev Menon",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 929,
                  url: "https://m.media-amazon.com/images/M/MV5BNzAwNTM3Y2ItZmViZS00NWNiLWI3YmEtZWE1NWFlNWRkNzljXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  width: 575,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actress",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Elisa Das",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm7371790",
                nameText: {
                  __typename: "NameText",
                  text: "Madonna Sebastian",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 740,
                  url: "https://m.media-amazon.com/images/M/MV5BZjM4MzQ1ZjgtNjJkZS00YjkyLTk3YTEtMzRkMmUzMzk1Mjg2XkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_.jpg",
                  width: 500,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Harold Das",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm0035018",
                nameText: {
                  __typename: "NameText",
                  text: "Arjun Sarja",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 750,
                  url: "https://m.media-amazon.com/images/M/MV5BYTFjNjNkYTMtNjQ4My00OGI4LWJjNDMtNTViYzY5ZmYxYzhmXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  width: 536,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actress",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Priya Andrews",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm3591550",
                nameText: {
                  __typename: "NameText",
                  text: "Priya Anand",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 1423,
                  url: "https://m.media-amazon.com/images/M/MV5BOWVhNWJlNGYtYTIzNC00ZDM2LTk3MzktMTMwNjlhNDk0ODMwXkEyXkFqcGdeQXVyMTMxODA4Njgx._V1_.jpg",
                  width: 800,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Shanmugam",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm4199426",
                nameText: {
                  __typename: "NameText",
                  text: "Mysskin",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 1271,
                  url: "https://m.media-amazon.com/images/M/MV5BYmJhZGNkMGItNjc4MS00NzIxLWE0MTktZDcxMzAwZWUzZGFmXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  width: 835,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: [
                {
                  __typename: "CreditedAsCreditAttribute",
                  text: "as Santhi Priya",
                },
              ],
              category: {
                __typename: "CreditCategory",
                id: "actress",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Advocate",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm12304446",
                nameText: {
                  __typename: "NameText",
                  text: "Santhi Mayadevi",
                },
                primaryImage: null,
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Antony's henchman",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm1184326",
                nameText: {
                  __typename: "NameText",
                  text: "Babu Antony",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 4608,
                  url: "https://m.media-amazon.com/images/M/MV5BZmRjZmFhYWItNTE2YS00ZTQ0LWEyYmUtZGViNGUxMWIxNDA1XkEyXkFqcGdeQXVyNTIzODM1MDc@._V1_.jpg",
                  width: 2834,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Judge",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm1336722",
                nameText: {
                  __typename: "NameText",
                  text: "Denzil Smith",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 960,
                  url: "https://m.media-amazon.com/images/M/MV5BMTUyNjUzNzU2N15BMl5BanBnXkFtZTgwNTQ2ODQzMzE@._V1_.jpg",
                  width: 805,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "A robber in Shanmugam's gang",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm8842905",
                nameText: {
                  __typename: "NameText",
                  text: "Sandy Master",
                },
                primaryImage: null,
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actress",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "An escort",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm9306232",
                nameText: {
                  __typename: "NameText",
                  text: "Maya S. Krishnan",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 900,
                  url: "https://m.media-amazon.com/images/M/MV5BMWY3MDg5OTgtZjAzYi00YjZmLTlkMzEtNzk3ODZiNzM0YjRkXkEyXkFqcGdeQXVyMjYwMDk5NjE@._V1_.jpg",
                  width: 720,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Shanmugam's brother-in-law",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm5157126",
                nameText: {
                  __typename: "NameText",
                  text: "Madhusudhan Rao",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 700,
                  url: "https://m.media-amazon.com/images/M/MV5BZDNiY2ZhNjgtNmE4Zi00ZmYyLThjMzAtMzk4NzhjZmRlM2E3XkEyXkFqcGdeQXVyNDc2NzU1MTA@._V1_.jpg",
                  width: 500,
                },
              },
            },
          },
          {
            __typename: "CreditEdge",
            node: {
              __typename: "Cast",
              attributes: null,
              category: {
                __typename: "CreditCategory",
                id: "actor",
              },
              characters: [
                {
                  __typename: "Character",
                  name: "Hridayaraj D'Souza",
                },
              ],
              episodeCredits: {
                __typename: "EpisodeCastConnection",
                total: 0,
                yearRange: null,
              },
              name: {
                __typename: "Name",
                id: "nm1658967",
                nameText: {
                  __typename: "NameText",
                  text: "Mansoor Ali Khan",
                },
                primaryImage: {
                  __typename: "Image",
                  height: 1500,
                  url: "https://m.media-amazon.com/images/M/MV5BZTQ0N2U0NGMtZWY0Yy00YzE4LWIwN2ItZjc4NTYwMDk1MTAwXkEyXkFqcGdeQXVyMzYxOTQ3MDg@._V1_.jpg",
                  width: 1090,
                },
              },
            },
          },
        ],
      },
      companies: {
        __typename: "CompanyCreditConnection",
        total: 14,
      },
      connections: {
        __typename: "TitleConnectionConnection",
        edges: [
          {
            __typename: "TitleConnectionEdge",
            node: {
              __typename: "TitleConnection",
              associatedTitle: {
                __typename: "Title",
                id: "tt1176176",
                originalTitleText: {
                  __typename: "TitleText",
                  text: "Polladhavan",
                },
                releaseYear: {
                  __typename: "YearRange",
                  year: 1980,
                },
                series: null,
                titleText: {
                  __typename: "TitleText",
                  text: "Polladhavan",
                },
              },
              category: {
                __typename: "TitleConnectionCategory",
                text: "Features",
              },
            },
          },
        ],
      },
      contributionQuestions: {
        __typename: "QuestionConnection",
        contributionLink: {
          __typename: "ContributionQuestionsLink",
          url: "https://contribute.imdb.com/answers",
        },
        edges: [
          {
            __typename: "QuestionEdge",
            node: {
              __typename: "Question",
              contributionLink: {
                __typename: "ContributionQuestionsLink",
                url: "https://contribute.imdb.com/answers?pinnedQuestion=tt15654328.certificate.IN",
              },
              entity: {
                __typename: "Title",
                primaryImage: {
                  __typename: "Image",
                  caption: {
                    __typename: "Markdown",
                    plainText: "Joseph Vijay in Leo (2023)",
                  },
                  height: 1633,
                  url: "https://m.media-amazon.com/images/M/MV5BMmFiOGYyZjQtZmZmNC00ZTgzLWI5ZjktMTRiYzc5NjAzODRkXkEyXkFqcGdeQXVyMTYyNDkzNzgz._V1_.jpg",
                  width: 1080,
                },
              },
              questionId: "tt15654328.certificate.IN",
              questionText: {
                __typename: "Markdown",
                plainText:
                  "What was the official certification given to Leo (2023) in India?",
              },
            },
          },
        ],
      },
      countriesOfOrigin: {
        __typename: "CountriesOfOrigin",
        countries: [
          {
            __typename: "CountryOfOrigin",
            id: "IN",
            text: "India",
          },
        ],
      },
      crazyCredits: {
        __typename: "CrazyCreditConnection",
        edges: [],
      },
      creators: [],
      detailsExternalLinks: {
        __typename: "ExternalLinkConnection",
        edges: [],
        total: 0,
      },
      directors: [
        {
          __typename: "PrincipalCreditsForCategory",
          category: {
            __typename: "CreditCategory",
            text: "Director",
          },
          credits: [
            {
              __typename: "Crew",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm7992231",
                nameText: {
                  __typename: "NameText",
                  text: "Lokesh Kanagaraj",
                },
              },
            },
          ],
          totalCredits: 1,
        },
      ],
      episodes: null,
      faqs: {
        __typename: "FaqConnection",
        edges: [],
        total: 0,
      },
      featuredReviews: {
        __typename: "ReviewsConnection",
        edges: [
          {
            __typename: "ReviewEdge",
            node: {
              __typename: "Review",
              author: {
                __typename: "UserProfile",
                nickName: "arungeorge13",
                userId: "ur30872044",
              },
              authorRating: 6,
              helpfulness: {
                __typename: "ReviewHelpfulness",
                downVotes: 40,
                upVotes: 76,
              },
              id: "rw9384546",
              submissionDate: "2023-10-19",
              summary: {
                __typename: "ReviewSummary",
                originalText:
                  "Would've worked fine as a standalone piece, if you ask me! [+62%]",
              },
              text: {
                __typename: "ReviewText",
                originalText: {
                  __typename: "Markdown",
                  plaidHtml:
                    "On the bright side, we get..<br/><br/><ul><li>One of Vijay&#39;s finest performances (not as a star, but as an actor): The first half is replete with moments where Vijay showcases emotions as a doting father, husband, cafe owner, and animal lover.</li></ul><br/><br/><ul><li>The writing in the first half: Superb, even when it&#39;s A History of Violence contextualized for Tamil sensibilities. Every scene carries a decent tempo, and the developments make you sit up. The whole hyena angle is beautifully executed, and its payoff in the climax is wonderful. The title card placement is a nice creative touch on Lokesh&#39;s part.</li></ul><br/><br/><ul><li>Brilliant cinematography: Manoj Paramahamsa&#39;s frames wonderfully capture the Kashmiri locales (even though the film is &quot;set&quot; in Theog, Himachal Pradesh) with Parthipan&#39;s (Vijay) cafe looking remarkably aesthetic in that first fight sequence. When the film gets action-heavy, the use of the mocobot camera is put to fine effect.</li></ul><br/><br/><ul><li>A pretty solid supporting cast: Whether it be Trisha (who looks absolutely dashing), Gautham Menon, Arjun Sarja, Sanjay Dutt, or Mathew Thomas, they deliver what the writing expects them to. It&#39;s just that the antagonists (Dutt, Sarja) lack sufficient fleshing out for us to care about their motives.</li></ul><br/><br/><ul><li>Anirudh&#39;s music: While I feel he overdid the score a bit in the film, the elevation points (particularly a 10-15 minute pre-interval stretch) are fabulous, courtesy of his compositions. Badass Ma is the clear standout, but Naa Ready also worked thanks to the choreography. The English bits in the score were tremendous, and I can&#39;t wait to blast them on Spotify for my workouts once the OST is uploaded.</li></ul><br/><br/>On the not-so-bright side, we get..<br/><br/><ul><li>A lackluster second half: The whole flashback segment suffers from tepid writing. A key character is introduced only to be killed off just a few minutes later. The writing doesn&#39;t give us any time to register this character, let alone connect emotionally. This then becomes the driving force for the protagonist&#39;s subsequent actions. The whole &quot;identity crisis&quot; aspect also wears out, because there&#39;s only so much you can do with it. In totality, this is a 75% Lokesh, 25% Vijay film.</li></ul><br/><br/><ul><li>Some tacky CGI: While this doesn&#39;t hamper the viewing experience overall, you&#39;ll come across not-so-great CG work in certain parts. This is especially the case in a car chase sequence.</li></ul><br/><br/><ul><li>The LCU connect: Felt somewhat inorganic and forced. Given the film takes place geographically far away from the proceedings of the LCU, I felt it stood a better chance as a standalone piece. There are some interesting cameos yes, but nothing that gives you the wowness of Vikram, or even Kaithi for that matter. Lokesh definitely reserved his best for Aandavar.</li></ul><br/><br/>Middle-of-the-road aspect: Anbariv masters are quite well-known for their innovative set pieces. I loved the first set piece (at the cafe) - it felt raw and real, with fantastic cuts and zero slo-mo. There are plenty more in various locations, but only the climactic showdown (which also includes a 1v1 between Vijay and Arjun) lingers in my mind after leaving the cinema hall.<br/><br/>P. S. - I enjoyed Loki&#39;s tribute to Sly Stallone. If you know, you know.",
                },
              },
            },
          },
        ],
      },
      filmingLocations: {
        __typename: "FilmingLocationConnection",
        edges: [
          {
            __typename: "FilmingLocationEdge",
            node: {
              __typename: "FilmingLocation",
              attributes: [
                {
                  __typename: "DisplayableAttribute",
                  text: "Filming City",
                },
              ],
              location: "Kashmir, India",
              text: "Kashmir, India",
            },
          },
        ],
        total: 7,
      },
      goofs: {
        __typename: "GoofConnection",
        edges: [
          {
            __typename: "GoofEdge",
            node: {
              __typename: "Goof",
              text: {
                __typename: "Markdown",
                plaidHtml:
                  "While Parthiban is dropping Siddhu to school, he gets the call from Joshy to tame the hyena, he makes Siddhu promise to not tell his mother he was late and then they both go to tame the hyena, but after taming the hyena Parthiban just goes home and Siddhu just magically teleports to school while also leaving the car behind.",
              },
            },
          },
        ],
      },
      goofsTotal: {
        __typename: "GoofConnection",
        total: 1,
      },
      id: "tt15654328",
      iframeAddReviewLink: {
        __typename: "ContributionLink",
        url: "https://contribute.imdb.com/review/tt15654328/add?bus=imdb&return_url=https%3A%2F%2Fwww.imdb.com%2Fclose_me&site=web",
      },
      imageUploadLink: {
        __typename: "ContributionLink",
        url: "https://contribute.imdb.com/image/tt15654328/add?bus=imdb&return_url=https%3A%2F%2Fwww.imdb.com%2Fclose_me&site=web",
      },
      isAdult: false,
      lifetimeGross: null,
      moreLikeThisTitles: {
        __typename: "MoreLikeThisConnection",
        edges: [
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: {
                __typename: "Certificate",
                rating: "Not Rated",
              },
              id: "tt11663228",
              originalTitleText: {
                __typename: "TitleText",
                text: "Jailer",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText:
                    "Jackie Shroff, Ramya Krishnan, Mohanlal, Rajinikanth, Mirnaa, Tamannaah Bhatia, Vinayakan, Shivarajkumar, and Yogi Babu in Jailer (2023)",
                },
                height: 2048,
                id: "rm353982465",
                url: "https://m.media-amazon.com/images/M/MV5BNzFkNmZkMTctYjRhMS00ODZiLWFlNjQtZmZmN2IzMDJlNmVkXkEyXkFqcGdeQXVyMTY1MzAyNjU4._V1_.jpg",
                width: 1313,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 7.1,
                voteCount: 33575,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2023,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 10080,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Comedy",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Crime",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "Jailer",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: {
                __typename: "Certificate",
                rating: "Not Rated",
              },
              id: "tt15354916",
              originalTitleText: {
                __typename: "TitleText",
                text: "Jawan",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText:
                    "Sanjay Dutt, Priyamani, Nayanthara, and Deepika Padukone in Jawan (2023)",
                },
                height: 1350,
                id: "rm4279328001",
                url: "https://m.media-amazon.com/images/M/MV5BOWI5NmU3NTUtOTZiMS00YzA1LThlYTktNDJjYTU5NDFiMDUxXkEyXkFqcGdeQXVyMTUzNjEwNjM2._V1_.jpg",
                width: 1080,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 7,
                voteCount: 91964,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2023,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 10140,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Drama",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Musical",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "Jawan",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: null,
              id: "tt9179430",
              originalTitleText: {
                __typename: "TitleText",
                text: "Vikram",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText: "Kamal Haasan in Vikram (2022)",
                },
                height: 1920,
                id: "rm1740833281",
                url: "https://m.media-amazon.com/images/M/MV5BMDRiOWNjYjUtMDI0ZC00MDMyLTkwZDItNTU5NWQ1NjEyNGYxXkEyXkFqcGdeQXVyMTIyNzY0NTMx._V1_.jpg",
                width: 1080,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 8.3,
                voteCount: 73468,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2022,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 10500,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Crime",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Thriller",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "Vikram",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: {
                __typename: "Certificate",
                rating: "Not Rated",
              },
              id: "tt10698680",
              originalTitleText: {
                __typename: "TitleText",
                text: "K.G.F: Chapter 2",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText:
                    "Sanjay Dutt, Prakash Raj, Easwari Rao, Raveena Tandon, Rao Ramesh, Yash, Achyuth Kumar, and Srinidhi Shetty in K.G.F: Chapter 2 (2022)",
                },
                height: 1350,
                id: "rm2414604801",
                url: "https://m.media-amazon.com/images/M/MV5BMjI2Njg2Y2EtZjgwMC00ZGVkLWJmMWYtYjVhYjk2ZTkwNWE1XkEyXkFqcGdeQXVyMTMxMjA5NDU1._V1_.jpg",
                width: 1080,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 8.3,
                voteCount: 149169,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2022,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 9960,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Crime",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Drama",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "K.G.F: Chapter 2",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: {
                __typename: "Certificate",
                rating: "Not Rated",
              },
              id: "tt9900782",
              originalTitleText: {
                __typename: "TitleText",
                text: "Kaithi",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText: "Arjun Das, Narain, and Karthi in Kaithi (2019)",
                },
                height: 916,
                id: "rm1211903233",
                url: "https://m.media-amazon.com/images/M/MV5BZTVlNGY2YTEtNTlmYy00NzY0LWE1NWUtOGJiNTgxZGM4ZmMzXkEyXkFqcGdeQXVyMTY1MzAyNjU4._V1_.jpg",
                width: 685,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 8.4,
                voteCount: 41887,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2019,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 8700,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Crime",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Thriller",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "Kaithi",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: {
                __typename: "Certificate",
                rating: "Not Rated",
              },
              id: "tt13751694",
              originalTitleText: {
                __typename: "TitleText",
                text: "Animal",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText:
                    "Bobby Deol, Anil Kapoor, Ranbir Kapoor, Saloni Batra, Rashmika Mandanna, and Anshul Chauhan in Animal (2023)",
                },
                height: 1348,
                id: "rm3809102337",
                url: "https://m.media-amazon.com/images/M/MV5BNGViM2M4NmUtMmNkNy00MTQ5LTk5MDYtNmNhODAzODkwOTJlXkEyXkFqcGdeQXVyMTY1NDY4NTIw._V1_.jpg",
                width: 1078,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 6.3,
                voteCount: 81601,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2023,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 12240,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Crime",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Drama",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "Animal",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: null,
              id: "tt13927994",
              originalTitleText: {
                __typename: "TitleText",
                text: "Salaar: Cease Fire - Part 1",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText: "Prabhas in Salaar (2023)",
                },
                height: 1500,
                id: "rm2712555009",
                url: "https://m.media-amazon.com/images/M/MV5BMmU4ZTM0MTctZTQ3Ny00YjZmLWFhNzEtOGYzMDk0ZjcyNmYzXkEyXkFqcGdeQXVyMTUyNjIwMDEw._V1_.jpg",
                width: 1200,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 6.5,
                voteCount: 60108,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2023,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 10500,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Crime",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Drama",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "Salaar",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: null,
              id: "tt15732324",
              originalTitleText: {
                __typename: "TitleText",
                text: "OMG 2",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText: "Akshay Kumar and Pankaj Tripathi in OMG 2 (2023)",
                },
                height: 1707,
                id: "rm3878836225",
                url: "https://m.media-amazon.com/images/M/MV5BNmQ3MThkOWEtNTA0NC00YzI2LWIxZjEtZjdlZTVmNzQ2ZGViXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg",
                width: 1280,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 7.6,
                voteCount: 39474,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2023,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 9360,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Comedy",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Drama",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "OMG 2",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: {
                __typename: "Certificate",
                rating: "Not Rated",
              },
              id: "tt18411490",
              originalTitleText: {
                __typename: "TitleText",
                text: "Tiger 3",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText:
                    "Salman Khan, Katrina Kaif, and Emraan Hashmi in Tiger 3 (2023)",
                },
                height: 400,
                id: "rm2346995969",
                url: "https://m.media-amazon.com/images/M/MV5BYzQwMGZlYTUtODUwNi00ZjQxLWEzODAtZGU3Zjc0MmNhMzhkXkEyXkFqcGdeQXVyNTkzNDQ4ODc@._V1_.jpg",
                width: 300,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 5.8,
                voteCount: 52060,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2023,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 9300,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Adventure",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Thriller",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "Tiger 3",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: {
                __typename: "Certificate",
                rating: "Not Rated",
              },
              id: "tt8178634",
              originalTitleText: {
                __typename: "TitleText",
                text: "RRR (Rise Roar Revolt)",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText:
                    "Ajay Devgn, Alia Bhatt, Olivia Morris, N.T. Rama Rao Jr., and Ram Charan in RRR: Naatu Naatu (2021)",
                },
                height: 1000,
                id: "rm535173377",
                url: "https://m.media-amazon.com/images/M/MV5BODUwNDNjYzctODUxNy00ZTA2LWIyYTEtMDc5Y2E5ZjBmNTMzXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg",
                width: 750,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 7.8,
                voteCount: 165260,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2022,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 11220,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Drama",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "RRR",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: {
                __typename: "Certificate",
                rating: "Not Rated",
              },
              id: "tt10579952",
              originalTitleText: {
                __typename: "TitleText",
                text: "Master",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText: "Joseph Vijay in Master (2021)",
                },
                height: 1867,
                id: "rm1559593217",
                url: "https://m.media-amazon.com/images/M/MV5BODNiYjExMjgtYTc1ZC00YTlhLWFkZTEtY2JmM2JiMTIwMGRjXkEyXkFqcGdeQXVyOTk3NTc2MzE@._V1_.jpg",
                width: 1400,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 7.4,
                voteCount: 82973,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2021,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 10740,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Crime",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Thriller",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "Master",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
          {
            __typename: "MoreLikeThisEdge",
            node: {
              __typename: "Title",
              canHaveEpisodes: false,
              canRate: {
                __typename: "CanRate",
                isRatable: true,
              },
              certificate: {
                __typename: "Certificate",
                rating: "Not Rated",
              },
              id: "tt9389998",
              originalTitleText: {
                __typename: "TitleText",
                text: "Pushpa: The Rise - Part 1",
              },
              primaryImage: {
                __typename: "Image",
                caption: {
                  __typename: "Markdown",
                  plainText: "Allu Arjun in Pushpa: The Rise - Part 1 (2021)",
                },
                height: 1200,
                id: "rm3160735489",
                url: "https://m.media-amazon.com/images/M/MV5BMmQ4YmM3NjgtNTExNC00ZTZhLWEwZTctYjdhOWI4ZWFlMDk2XkEyXkFqcGdeQXVyMTI1NDEyNTM5._V1_.jpg",
                width: 800,
              },
              ratingsSummary: {
                __typename: "RatingsSummary",
                aggregateRating: 7.6,
                voteCount: 86695,
              },
              releaseYear: {
                __typename: "YearRange",
                endYear: null,
                year: 2021,
              },
              runtime: {
                __typename: "Runtime",
                seconds: 10740,
              },
              titleGenres: {
                __typename: "TitleGenres",
                genres: [
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Action",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Crime",
                    },
                  },
                  {
                    __typename: "TitleGenre",
                    genre: {
                      __typename: "GenreItem",
                      text: "Drama",
                    },
                  },
                ],
              },
              titleText: {
                __typename: "TitleText",
                text: "Pushpa: The Rise - Part 1",
              },
              titleType: {
                __typename: "TitleType",
                canHaveEpisodes: false,
                displayableProperty: {
                  __typename: "DisplayableTitleTypeProperty",
                  value: {
                    __typename: "Markdown",
                    plainText: "",
                  },
                },
                id: "movie",
                text: "Movie",
              },
            },
          },
        ],
      },
      nominations: {
        __typename: "AwardNominationConnection",
        total: 4,
      },
      openingWeekendGross: null,
      originalTitleText: {
        __typename: "TitleText",
        text: "Leo",
      },
      prestigiousAwardSummary: null,
      primaryImage: {
        __typename: "Image",
        id: "rm2551271425",
      },
      production: {
        __typename: "CompanyCreditConnection",
        edges: [
          {
            __typename: "CompanyCreditEdge",
            node: {
              __typename: "CompanyCredit",
              company: {
                __typename: "Company",
                companyText: {
                  __typename: "CompanyText",
                  text: "Seven Screen Studio",
                },
                id: "co0733661",
              },
            },
          },
          {
            __typename: "CompanyCreditEdge",
            node: {
              __typename: "CompanyCredit",
              company: {
                __typename: "Company",
                companyText: {
                  __typename: "CompanyText",
                  text: "The Route",
                },
                id: "co0946109",
              },
            },
          },
        ],
      },
      productionBudget: null,
      productionStatus: {
        __typename: "ProductionStatusDetails",
        currentProductionStage: {
          __typename: "ProductionStage",
          id: "released",
          text: "Released",
        },
        productionStatusHistory: [
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "development_unknown",
              text: "Development Unknown",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "production_unknown",
              text: "Production Unknown",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "production_unknown",
              text: "Production Unknown",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "filming",
              text: "Filming",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "filming",
              text: "Filming",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "filming",
              text: "Filming",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "post_production",
              text: "Post-production",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "completed",
              text: "Completed",
            },
          },
          {
            __typename: "ProductionStatusHistory",
            status: {
              __typename: "ProductionStatus",
              id: "released",
              text: "Released",
            },
          },
        ],
        restriction: null,
      },
      quotes: {
        __typename: "TitleQuoteConnection",
        edges: [],
      },
      quotesTotal: {
        __typename: "TitleQuoteConnection",
        total: 0,
      },
      ratingsSummary: {
        __typename: "RatingsSummary",
        topRanking: {
          __typename: "TopRanking",
          id: "topRated:tt15654328:en_US",
          rank: 2716,
          text: {
            __typename: "LocalizedString",
            value: "Top Rated",
          },
        },
      },
      releaseDate: {
        __typename: "ReleaseDate",
        country: {
          __typename: "LocalizedDisplayableCountry",
          id: "US",
          text: "United States",
        },
        day: 21,
        month: 11,
        year: 2023,
      },
      releaseYear: {
        __typename: "YearRange",
        year: 2023,
      },
      reviews: {
        __typename: "ReviewsConnection",
        total: 414,
      },
      runtime: {
        __typename: "Runtime",
        seconds: 9840,
      },
      series: null,
      soundtrack: {
        __typename: "SoundtrackConnection",
        edges: [
          {
            __typename: "SoundtrackEdge",
            node: {
              __typename: "Track",
              comments: [
                {
                  __typename: "Markdown",
                  plaidHtml:
                    'Music by <a class="ipc-md-link ipc-md-link--entity" href="/name/nm4794064/?ref_=tt_trv_snd">Anirudh Ravichander</a>',
                },
                {
                  __typename: "Markdown",
                  plaidHtml:
                    'Lyrics by <a class="ipc-md-link ipc-md-link--entity" href="/name/nm14530447/?ref_=tt_trv_snd">Heisenberg</a>',
                },
                {
                  __typename: "Markdown",
                  plaidHtml:
                    'Performed by <a class="ipc-md-link ipc-md-link--entity" href="/name/nm4794064/?ref_=tt_trv_snd">Anirudh Ravichander</a>, <a class="ipc-md-link ipc-md-link--entity" href="/name/nm4837111/?ref_=tt_trv_snd">Siddharth Basrur</a>',
                },
              ],
              text: "Bloody Sweet",
            },
          },
        ],
      },
      spokenLanguages: {
        __typename: "SpokenLanguages",
        spokenLanguages: [
          {
            __typename: "SpokenLanguage",
            id: "ta",
            text: "Tamil",
          },
        ],
      },
      technicalSpecifications: {
        __typename: "TechnicalSpecifications",
        aspectRatios: {
          __typename: "AspectRatios",
          items: [
            {
              __typename: "AspectRatio",
              aspectRatio: "2.39 : 1",
              attributes: [],
            },
          ],
        },
        colorations: {
          __typename: "Colorations",
          items: [
            {
              __typename: "Coloration",
              attributes: [],
              conceptId: "color",
              text: "Color",
            },
          ],
        },
        soundMixes: {
          __typename: "SoundMixes",
          items: [],
        },
      },
      titleMainImages: {
        __typename: "ImageConnection",
        edges: [
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText:
                  "Sanjay Dutt, Arjun Sarja, Kamal Haasan, Anurag Kashyap, Joseph Vijay, Mathew Thomas, Gautham Vasudev Menon, Babu Antony, Denzil Smith, Trisha Krishnan, Mansoor Ali Khan, Priya Anand, Mysskin, Anirudh Ravichander, Madhusudhan Rao, George Maryan, Madonna Sebastian, Lokesh Kanagaraj, and Sandy Master in Leo (2023)",
              },
              height: 688,
              id: "rm854806785",
              url: "https://m.media-amazon.com/images/M/MV5BMWQ4MmNmMTAtNmNjMy00M2IwLTlkYzgtNDA0OWRmMTdkNmY2XkEyXkFqcGdeQXVyMTY1MzAyNjU4._V1_.jpg",
              width: 1032,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Joseph Vijay in Leo (2023)",
              },
              height: 829,
              id: "rm121132289",
              url: "https://m.media-amazon.com/images/M/MV5BY2ZiODc1MmMtYTVmMy00YTMwLTk4ZWEtMGQ2ZTI0ZDczMDhjXkEyXkFqcGdeQXVyMTQ3Mzk2MDg4._V1_.jpg",
              width: 660,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText:
                  "Sanjay Dutt, Arjun Sarja, Joseph Vijay, Gautham Vasudev Menon, and Mysskin in Leo (2023)",
              },
              height: 420,
              id: "rm1797083905",
              url: "https://m.media-amazon.com/images/M/MV5BZDQzZjNkODAtOTljYi00OGJkLWIwN2ItYTE4ZmFjYTNlMzZjXkEyXkFqcGdeQXVyMTY3ODkyNDkz._V1_.jpg",
              width: 310,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Joseph Vijay in Leo (2023)",
              },
              height: 1500,
              id: "rm1630098177",
              url: "https://m.media-amazon.com/images/M/MV5BYTAzYzVlYmItMWI1Yi00ZGRjLTkwYWUtYWM3ZDIwOGFiODk4XkEyXkFqcGdeQXVyMTY3ODkyNDkz._V1_.jpg",
              width: 1000,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Leo (2023)",
              },
              height: 420,
              id: "rm1515606785",
              url: "https://m.media-amazon.com/images/M/MV5BMmE5YjEzMTEtMmRmZS00YzVkLThjZmYtNTA2ZjEwYzlmOGM4XkEyXkFqcGdeQXVyMTY3ODkyNDkz._V1_.jpg",
              width: 310,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Sanjay Dutt and Joseph Vijay in Leo (2023)",
              },
              height: 2126,
              id: "rm2849526273",
              url: "https://m.media-amazon.com/images/M/MV5BODcwZDhjNzMtMDA5Mi00OTlkLWI5MTktZWExODA1NDA5ZWE5XkEyXkFqcGdeQXVyMTUyNjIwMDEw._V1_.jpg",
              width: 1400,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Sanjay Dutt and Joseph Vijay in Leo (2023)",
              },
              height: 2126,
              id: "rm2899857921",
              url: "https://m.media-amazon.com/images/M/MV5BM2Y4MzQ3NmUtOWQ5My00YTFjLTkzNDMtNzliODQ5NTFmZjg3XkEyXkFqcGdeQXVyMTUyNjIwMDEw._V1_.jpg",
              width: 1400,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Joseph Vijay in Leo (2023)",
              },
              height: 2048,
              id: "rm2030525697",
              url: "https://m.media-amazon.com/images/M/MV5BMmJjODA4ZTMtNWIxMy00MGU4LThkYTctYTNiNDRlMDFiZDdmXkEyXkFqcGdeQXVyMTUyNjIwMDEw._V1_.jpg",
              width: 1348,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Leo (2023)",
              },
              height: 845,
              id: "rm2897435137",
              url: "https://m.media-amazon.com/images/M/MV5BNDhhMjU3ZTktNWE5OS00NmY1LTlkMGMtYzczMjljNjUzMjdjXkEyXkFqcGdeQXVyMTQ3Mzk2MDg4._V1_.jpg",
              width: 438,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Leo (2023)",
              },
              height: 2048,
              id: "rm3139315201",
              url: "https://m.media-amazon.com/images/M/MV5BYTU0NjZmOGUtZWE2NS00OWQ2LWI2NjgtMDRkZGEwZmFkZTgzXkEyXkFqcGdeQXVyMTU0ODI1NTA2._V1_.jpg",
              width: 1152,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Leo (2023)",
              },
              height: 826,
              id: "rm2420323073",
              url: "https://m.media-amazon.com/images/M/MV5BNWEwYjY1N2ItMzcxOS00YTRmLTk5NDctN2M1MTljYWJkYmMyXkEyXkFqcGdeQXVyMTUzNTgzNzM0._V1_.jpg",
              width: 462,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Joseph Vijay in Leo (2023)",
              },
              height: 1366,
              id: "rm3568453633",
              url: "https://m.media-amazon.com/images/M/MV5BYjk2YWRmYjctMDk3NS00ZDNiLWFiNGItY2IwMzdjMjhhODU0XkEyXkFqcGdeQXVyMTM1OTU1MzQx._V1_.jpg",
              width: 2048,
            },
          },
          {
            __typename: "ImageEdge",
            node: {
              __typename: "Image",
              caption: {
                __typename: "Markdown",
                plainText: "Joseph Vijay in Leo (2023)",
              },
              height: 1367,
              id: "rm3400681473",
              url: "https://m.media-amazon.com/images/M/MV5BMmJjZDkyYTUtM2M4MC00YTUzLTlmZDgtMTk1MWQxMWI5ZTJhXkEyXkFqcGdeQXVyMTM1OTU1MzQx._V1_.jpg",
              width: 2048,
            },
          },
        ],
        total: 95,
      },
      titleText: {
        __typename: "TitleText",
        text: "Leo",
      },
      titleType: {
        __typename: "TitleType",
        canHaveEpisodes: false,
        id: "movie",
      },
      topQuestions: {
        __typename: "AlexaQuestionConnection",
        edges: [
          {
            __typename: "AlexaQuestionEdge",
            node: {
              __typename: "AlexaQuestion",
              attributeId: "run-time",
              question: {
                __typename: "Markdown",
                plainText: "How long is Leo?",
              },
            },
          },
        ],
        total: 14,
      },
      trivia: {
        __typename: "TriviaConnection",
        edges: [
          {
            __typename: "TriviaEdge",
            node: {
              __typename: "TitleTrivia",
              relatedNames: null,
              text: {
                __typename: "Markdown",
                plaidHtml:
                  "This film is heavily inspired by the classic graphic novel &quot;A History of Violence&quot;.",
              },
              trademark: null,
            },
          },
        ],
      },
      triviaTotal: {
        __typename: "TriviaConnection",
        total: 10,
      },
      videoStrip: {
        __typename: "VideoConnection",
        edges: [
          {
            __typename: "VideoEdge",
            node: {
              __typename: "Video",
              contentType: {
                __typename: "VideoContentType",
                displayName: {
                  __typename: "LocalizedString",
                  value: "Trailer",
                },
              },
              id: "vi3073296153",
              name: {
                __typename: "LocalizedString",
                value: "Official Trailer",
              },
              runtime: {
                __typename: "VideoRuntime",
                value: 141,
              },
              thumbnail: {
                __typename: "Thumbnail",
                height: 1080,
                url: "https://m.media-amazon.com/images/M/MV5BYjY1YjliNjQtOTU4NC00M2JlLWEwY2MtMmI2YjlmNThkMmY3XkEyXkFqcGdeQWpvc2FyYw@@._V1_.jpg",
                width: 1920,
              },
            },
          },
          {
            __typename: "VideoEdge",
            node: {
              __typename: "Video",
              contentType: {
                __typename: "VideoContentType",
                displayName: {
                  __typename: "LocalizedString",
                  value: "Trailer",
                },
              },
              id: "vi2111686425",
              name: {
                __typename: "LocalizedString",
                value: "Leo - Official Trailer",
              },
              runtime: {
                __typename: "VideoRuntime",
                value: 162,
              },
              thumbnail: {
                __typename: "Thumbnail",
                height: 775,
                url: "https://m.media-amazon.com/images/M/MV5BYmUwNzIyYWUtOGEzNi00ZTQzLTg1NjEtY2ViYjAyNzAzNzg5XkEyXkFqcGdeQWthc2hpa2F4._V1_.jpg",
                width: 1378,
              },
            },
          },
          {
            __typename: "VideoEdge",
            node: {
              __typename: "Video",
              contentType: {
                __typename: "VideoContentType",
                displayName: {
                  __typename: "LocalizedString",
                  value: "Clip",
                },
              },
              id: "vi2010891545",
              name: {
                __typename: "LocalizedString",
                value: "Most Anticipated Indian Movies of 2023",
              },
              runtime: {
                __typename: "VideoRuntime",
                value: 61,
              },
              thumbnail: {
                __typename: "Thumbnail",
                height: 1080,
                url: "https://m.media-amazon.com/images/M/MV5BNTQ1ZDhmOWMtMWE5Mi00NTc0LWI4YTUtMzM0ZmJmNGMyMzcwXkEyXkFqcGdeQWthc2hpa2F4._V1_.jpg",
                width: 1920,
              },
            },
          },
          {
            __typename: "VideoEdge",
            node: {
              __typename: "Video",
              contentType: {
                __typename: "VideoContentType",
                displayName: {
                  __typename: "LocalizedString",
                  value: "Promo",
                },
              },
              id: "vi2977416473",
              name: {
                __typename: "LocalizedString",
                value: "LEO - Bloody Sweet Promo",
              },
              runtime: {
                __typename: "VideoRuntime",
                value: 169,
              },
              thumbnail: {
                __typename: "Thumbnail",
                height: 720,
                url: "https://m.media-amazon.com/images/M/MV5BM2Y1YjhhZDAtYjliZS00YTJiLWEzYjAtZjNjZDU1ZjQyZjZkXkEyXkFqcGdeQXRyYW5zY29kZS13b3JrZmxvdw@@._V1_.jpg",
                width: 1280,
              },
            },
          },
        ],
      },
      videos: {
        __typename: "TitleRelatedVideosConnection",
        total: 5,
      },
      wins: {
        __typename: "AwardNominationConnection",
        total: 0,
      },
      worldwideGross: {
        __typename: "BoxOfficeGross",
        total: {
          __typename: "Money",
          amount: 6978436,
          currency: "USD",
        },
      },
      writers: [
        {
          __typename: "PrincipalCreditsForCategory",
          category: {
            __typename: "CreditCategory",
            text: "Writers",
          },
          credits: [
            {
              __typename: "Crew",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm7992231",
                nameText: {
                  __typename: "NameText",
                  text: "Lokesh Kanagaraj",
                },
              },
            },
            {
              __typename: "Crew",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm7188712",
                nameText: {
                  __typename: "NameText",
                  text: "Rathna Kumar",
                },
              },
            },
            {
              __typename: "Crew",
              attributes: null,
              name: {
                __typename: "Name",
                id: "nm5338753",
                nameText: {
                  __typename: "NameText",
                  text: "Deeraj Vaidy",
                },
              },
            },
          ],
          totalCredits: 3,
        },
      ],
    },
  },
  message: "Successful",
  status: true,
};
const singleMoViesData = [];

// ________________Casting Data {ID,name}______________________
let TempCastObject = [];
const tempCast = Details.data.aboveTheFoldData.castPageTitle.edges;
tempCast.map((singleTempCast) => {
  let CreateCastObj = {
    id: singleTempCast.node.name.id,
    name: singleTempCast.node.name.nameText.text,
  };
  TempCastObject.push(CreateCastObj);
});

// ________________Moive Country {Country}______________________
let TempCountryObj=[]
const tempCountry = Details.data.aboveTheFoldData.countriesOfOrigin.countries;
tempCountry.map((singlecountry) => {
    let CountryObj={
        name:singlecountry.id,
    }
    TempCountryObj.push(CountryObj);
});

let TempGenreObj=[]
const tempgenre = Details.data.aboveTheFoldData.genres.genres;
tempgenre.map((singlegenre) => {

    let genreObj={
        name:singlegenre.text
    }
    TempGenreObj.push(genreObj)
});


let TempKeywordObj=[]
const tempKeyowrd = Details.data.aboveTheFoldData.keywords.edges;
tempKeyowrd.map((singleKeyword) => {
    let keywordobj={
        name:singleKeyword.node.text,
    }
    TempKeywordObj.push(keywordobj)
});

let TempTitle=Details.data.aboveTheFoldData.originalTitleText.text;
let TempDescription = Details.data.aboveTheFoldData.plot.plotText.plainText;


let TempVideoURLObj=[]

const TempVideo = Details.data.aboveTheFoldData.primaryVideos.edges;
TempVideo.map((singleVideo) => {
  const videoUrl = singleVideo.node.playbackURLs;

  videoUrl.map((singleVideoUrl) => {
    let VideoObj={
    url:singleVideoUrl.url,
    }
    TempVideoURLObj.push(VideoObj)
  });
});

const tempCredits = Details.data.aboveTheFoldData.principalCredits;
const creditsByCategory = {};
tempCredits.forEach((singleCredits) => {
  const categoryText = singleCredits.category.text;
  const MultipleCredit = singleCredits.credits;
  if (!creditsByCategory[categoryText]) {
    creditsByCategory[categoryText] = [];
  }
  MultipleCredit.map((singleActorCredit) => {
    const actorObject = {
      id: singleActorCredit.name.id,
      name: singleActorCredit.name.nameText.text,
    };
    creditsByCategory[categoryText].push(actorObject);
  });
});
const TempProductionObj=[];
const TempProductionCompany = Details.data.aboveTheFoldData.production.edges;
TempProductionCompany.map((singleProdctionCompany) => {
    let productionobj={
        id:singleProdctionCompany.node.company.id,
        name:singleProdctionCompany.node.company.companyText.text,

    }
    TempProductionObj.push(productionobj)
});

const TempRating = Details.data.aboveTheFoldData.ratingsSummary;
let Temprate=TempRating.aggregateRating;
let Tempvote=TempRating.voteCount;

const TempReleaseDate = Details.data.aboveTheFoldData.releaseDate;
const AddReleaseDate = {
  date: {
    day: TempReleaseDate.day,
    month: TempReleaseDate.month,
    year: TempReleaseDate.year,
  },
};


// ________________ Runtime   ______________________
const TempRuntime = Details.data.aboveTheFoldData.runtime;
let Tempruntime=TempRuntime.seconds;

singleMoViesData.Details={
    cast:TempCastObject,
    country:TempCountryObj,
    genre:tempgenre,
    keyword:tempKeyowrd,
    title:TempTitle,
    description:TempDescription,
    video:TempVideoURLObj,
    credits:creditsByCategory,
    production:TempProductionObj,
    rate:Temprate,
    vote:Tempvote,
    releasedata:AddReleaseDate,
    runtime:Tempruntime
}
console.log(singleMoViesData)
