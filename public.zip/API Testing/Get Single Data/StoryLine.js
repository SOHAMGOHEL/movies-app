const Storylines={
    "data": [
      {
        "feedbackDataType": "titleGoof",
        "id": "continuity",
        "name": "Continuity",
        "section": {
          "endCursor": "Z2Y3MTcxOTM4",
          "items": [
            {
              "cardHtml": "While Parthiban is dropping Siddhu to school, he gets the call from Joshy to tame the hyena, he makes Siddhu promise to not tell his mother he was late and then they both go to tame the hyena, but after taming the hyena Parthiban just goes home and Siddhu just magically teleports to school while also leaving the car behind.",
              "id": "gf7171938",
              "refMarker": "ttgf_gf",
              "shareButtonProps": {
                "url": "?item=gf7171938"
              },
              "shouldExpandHtmlContent": true,
              "userVotingProps": {
                "downVotes": 1,
                "itemConst": "gf7171938",
                "itemType": "Goof",
                "pageConst": "tt15654328",
                "refTagPrefix": "ttgf",
                "upVotes": 5
              }
            }
          ],
          "total": 1
        },
        "spoilerSection": {
          "endCursor": null,
          "items": [],
          "total": 0
        }
      }
    ],
    "message": "Successful",
    "status": true
  }

// Iportatn Section and Spolier
  const TempStoryLine=Storylines.data
  TempStoryLine.map((SingleTempStoryLine)=>{
    console.log(SingleTempStoryLine)
  })

  export default Storylines;