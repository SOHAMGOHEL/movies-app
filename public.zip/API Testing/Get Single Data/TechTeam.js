const TechTeam={
    "data": [
      {
        "id": "runtime",
        "listContent": [
          {
            "id": 1,
            "subText": "(164 min)",
            "text": "2h 44m"
          },
          {
            "id": 2,
            "subText": "(163 min) (uncut) (United Kingdom)",
            "text": "2h 43m"
          }
        ],
        "rowTitle": "Runtime"
      },
      {
        "id": "soundmixes",
        "listContent": [
          {
            "href": "/search/title/?sound_mixes=dolby&ref_=ttspec_spec_2",
            "subText": "(Westrex Recording System)",
            "text": "Dolby"
          },
          {
            "href": "/search/title/?sound_mixes=dolby_atmos&ref_=ttspec_spec_2",
            "subText": "(RCA Sound Recording)",
            "text": "Dolby Atmos"
          },
          {
            "href": "/search/title/?sound_mixes=dolby_atmos&ref_=ttspec_spec_2",
            "subText": "(5.1)",
            "text": "Dolby Atmos"
          },
          {
            "href": "/search/title/?sound_mixes=imax_6_track&ref_=ttspec_spec_2",
            "subText": "(5.1)",
            "text": "IMAX 6-Track"
          },
          {
            "href": "/search/title/?sound_mixes=dolby_digital&ref_=ttspec_spec_2",
            "subText": "(5.1)",
            "text": "Dolby Digital"
          },
          {
            "href": "/search/title/?sound_mixes=stereo&ref_=ttspec_spec_2",
            "subText": "(5.1)",
            "text": "Stereo"
          }
        ],
        "rowTitle": "Sound mix"
      },
      {
        "id": "colorations",
        "listContent": [
          {
            "href": "/search/title/?colors=color&ref_=ttspec_spec_3",
            "text": "Color"
          }
        ],
        "rowTitle": "Color"
      },
      {
        "id": "aspectratio",
        "listContent": [
          {
            "text": "2.39 : 1"
          }
        ],
        "rowTitle": "Aspect ratio"
      },
      {
        "id": "cameras",
        "listContent": [
          {
            "subText": "(high-speed shots)",
            "text": "Phantom Flex, Cooke Anamorphic/i Lenses"
          },
          {
            "subText": "(drone shots)",
            "text": "Red Komodo, Cooke Anamorphic/i and Zeiss Supreme Prime Lenses"
          },
          {
            "subText": "(some shots)",
            "text": "Red Komodo-X, Cooke Anamorphic/i and Zeiss Supreme Prime Lenses"
          },
          {
            "text": "Red V-Raptor XL, Cooke Anamorphic/i Lenses"
          },
          {
            "text": "Red V-Raptor, Cooke Anamorphic/i, Zeiss Supreme Prime and Angenieux Optimo Lenses"
          }
        ],
        "rowTitle": "Camera"
      },
      {
        "id": "negativeFormat",
        "listContent": [
          {
            "text": "CineMag"
          },
          {
            "text": "Redcode RAW"
          }
        ],
        "rowTitle": "Negative Format"
      },
      {
        "id": "process",
        "listContent": [
          {
            "subText": "(anamorphic)",
            "text": "/i Scope"
          },
          {
            "subText": "(master format)",
            "text": "Digital Intermediate"
          },
          {
            "subText": "(source format)",
            "text": "Redcode RAW"
          },
          {
            "subText": "(source format)",
            "text": "Spherical"
          }
        ],
        "rowTitle": "Cinematographic Process"
      },
      {
        "id": "printedFormat",
        "listContent": [
          {
            "text": "DCP Digital Cinema Package"
          }
        ],
        "rowTitle": "Printed Film Format"
      }
    ],
    "message": "Successful",
    "status": true
  }


console.log(TechTeam.data)
/*
Runtime
"soundmixes"
"aspectratio"
"cameras"
*/


//   const TempTechTeam=TechTeam.data;

//   TempTechTeam.map((singleTechTeam)=>{
//     console.log(singleTechTeam.id)
//     const TempTechTeamCast=singleTechTeam.listContent;
//     TempTechTeamCast.map((singeltechTeamcast)=>{
//         console.log(singeltechTeamcast)
//         console.log(singeltechTeamcast.subText)
//         console.log(singeltechTeamcast.text)
//     })
// })
